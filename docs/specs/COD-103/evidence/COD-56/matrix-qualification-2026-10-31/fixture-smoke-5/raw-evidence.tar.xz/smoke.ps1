$ErrorActionPreference='Stop'
$r='C:\WINDOWS\TEMP\codebasegraph-cod56-2e9284b8-47f1-472a-9cdc-b6a24cc3d62f\fixture-smoke-880ef0541a174799b8e492a3fa9da6b4';$s='\\Mac\Home\Documents\codebasegraph-cod56-vm-11023706-4804-4438-b044-e9768538a0c8\fixture-smoke-880ef0541a174799b8e492a3fa9da6b4';if(Test-Path $r){throw 'root exists'};[IO.Directory]::CreateDirectory($r)|Out-Null
foreach($n in @('native_probe_fixture.exe','native_probe_fixture.rs','build-report.md')){Copy-Item -LiteralPath "$s\$n" -Destination "$r\$n"}
$hashes=@{};foreach($n in @('native_probe_fixture.exe','native_probe_fixture.rs','build-report.md')){$hashes[$n]=(Get-FileHash "$r\$n").Hash}
if($hashes['native_probe_fixture.exe']-ne'08E9773855C82DED4837968683CFA7895D17FB7D9D3283B9670CE4DC0F1FCA80'-or$hashes['native_probe_fixture.rs']-ne'7BFD7E558803824C5594335C350F317DEF747B338A80D7D3DEE0D59F30B7C314'){throw 'binding'}
Copy-Item "$r\native_probe_fixture.exe" "$r\codebase-graph.exe";Copy-Item "$r\native_probe_fixture.exe" "$r\k-wiki.exe"
$plan=@(@('graph0','codebase-graph.exe','--help','0','0',0,1),@('graph23','codebase-graph.exe','--help','23','0',23,1),@('wiki0','k-wiki.exe','--version','0','0',0,2),@('wiki29','k-wiki.exe','--version','0','29',29,2),@('unexpected','codebase-graph.exe','--unexpected','0','0',64,1))
$cases=@();$failure=$null
foreach($row in $plan){
$id=$row[0];$trace="$r\$id.trace";if(Test-Path $trace){throw 'trace preexists'}
$si=New-Object Diagnostics.ProcessStartInfo;$si.FileName="$r\$($row[1])";$si.Arguments=$row[2];$si.UseShellExecute=$false;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true;$si.WorkingDirectory=$r
$si.EnvironmentVariables['CBG_A09_GRAPH_EXIT']=$row[3];$si.EnvironmentVariables['CBG_A09_WIKI_EXIT']=$row[4];$si.EnvironmentVariables['CBG_A09_TRACE']=$trace
$p=[Diagnostics.Process]::Start($si);$stdout=$p.StandardOutput.ReadToEnd();$stderr=$p.StandardError.ReadToEnd();$p.WaitForExit();$code=$p.ExitCode
[IO.File]::WriteAllText("$s\$id.stdout.txt",$stdout);[IO.File]::WriteAllText("$s\$id.stderr.txt",$stderr)
$decoded=$null;$decodeError=$null
try{$b=[IO.File]::ReadAllBytes($trace);[IO.File]::WriteAllBytes("$s\$id.trace",$b);$ms=New-Object IO.MemoryStream(,$b);$br=New-Object IO.BinaryReader($ms);$version=$br.ReadUInt32();$role=$br.ReadUInt32();$argc=$br.ReadUInt32();if($argc-ne1){throw 'argc'};$len=$br.ReadUInt32();$arg=[Text.Encoding]::Unicode.GetString($br.ReadBytes($len*2));$exit=$br.ReadUInt32();if($ms.Position-ne$ms.Length){throw 'trailing'};$decoded=@{Version=$version;Role=$role;Argc=$argc;Argument=$arg;SelectedExit=$exit;Length=$b.Length}}catch{$decodeError=$_.Exception.Message}
$ok=$code-eq$row[5]-and$null-ne$decoded-and$decoded.Version-eq1-and$decoded.Role-eq$row[6]-and$decoded.Argument-eq$row[2]-and$decoded.SelectedExit-eq$row[5]
$cases+=@{Id=$id;ActualExit=$code;ExpectedExit=$row[5];Decoded=$decoded;DecodeError=$decodeError;Passed=$ok;GraphExit=$row[3];WikiExit=$row[4];Executable=$si.FileName;Argument=$row[2];Trace=$trace;Stdout=$stdout;Stderr=$stderr}
if(-not$ok){$failure=$id;break}
}
$after=@{};foreach($n in @('native_probe_fixture.exe','native_probe_fixture.rs','codebase-graph.exe','k-wiki.exe')){$after[$n]=(Get-FileHash "$r\$n").Hash}
[ordered]@{Root=$r;OS=[Environment]::OSVersion.Version.ToString();OSArchitecture=[Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString();PS=$PSVersionTable.PSVersion.ToString();Before=$hashes;After=$after;Cases=$cases;StoppedAt=$failure}|ConvertTo-Json -Depth 12|Set-Content "$s\result.json" -Encoding UTF8
if($failure){exit 1}
