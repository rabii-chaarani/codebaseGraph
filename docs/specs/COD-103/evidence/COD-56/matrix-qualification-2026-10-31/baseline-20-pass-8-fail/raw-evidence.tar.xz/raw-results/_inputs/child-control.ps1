$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
try {
    $metadata = [ordered]@{
        PSVersion = $PSVersionTable.PSVersion.ToString()
        ShellPath = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        OSVersion = [Environment]::OSVersion.VersionString
        OSArchitecture = [Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
        ProcessArchitecture = [Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString()
        Invocation = 'fresh-child-memory-ScriptBlock-not-File'
    }
    [IO.File]::WriteAllText($env:CBG_A09_METADATA, ($metadata | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
    $body = [IO.File]::ReadAllText($env:CBG_A09_INSTALLER)
    $installer = [ScriptBlock]::Create($body)
    if ($env:CBG_A09_MODE -eq 'DryRun') {
        & $installer -SourceDir $env:CBG_A09_SOURCE -BinDir $env:CBG_A09_BIN -DryRun
    }
    elseif ($env:CBG_A09_MODE -eq 'real') {
        & $installer -SourceDir $env:CBG_A09_SOURCE -BinDir $env:CBG_A09_BIN
    }
    else { throw 'Invalid private case mode' }
    exit 0
}
catch {
    [Console]::Error.WriteLine($_.ToString())
    exit 1
}