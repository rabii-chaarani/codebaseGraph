# COD-110 independent inert-carrier readback

**Status:** PASS for carrier fidelity; final combined checkout/dependency verification pending. Read-only input `/private/tmp/codebasegraph-cod110-20261101` at original committed HEAD `8f8838a06fab1aafc91962f306924a92c7a5b806` plus Production-owned documentation edits. Focused repair ledger `chg-0p9sje`; no ledger writes. Existing approved spec revision0.3 and separate approval unchanged; refer to baseline report `/private/tmp/c110-ev-checkout-20261102T121249Z-c8cebc/payload/report.md`.

## Executed fidelity checks

- Read both plain TARs using Python tarfile without extraction or execution. All200 unique names are safe relative regular-file members; no absolute/traversal/drive/backslash path, links or special members. Every original payload byte, size, SHA256 and0644 mode matches the baseline full Git-blob file inventory AND immutable closed `files.json` AND new map. Zero omitted, duplicate, extra or altered members.
- `run-logs.tar`:178members,13,780,767 payload bytes, zero zero-byte members. Physical13,926,400bytes, SHA256`4d030504502194bf580c3b036d51c16cf72c5d24c35a069ef0d6acf1350cff01`.
- `actual-local-temp-resumed.tar`:22members,940,943payload bytes, exactly10 genuine zero-byte members. Physical962,560bytes, SHA256`8031a9ef05a329afafeda5426a2e4c3e0fa21f60dd3d17f9f7c6108e5e30a2bf`.
- All4 listed new physical files match `carrier-files.json`. Historical logical manifest itself remains unchanged. Resolve all711 original logical payloads:200 via inert TAR members,511 unchanged direct files. All711 match original size/hash/mode; no evidence omissions. New transport files are a separate inventory, not rewritten historical evidence.

Raw checks are `member-checks.json`, `physical-checks.json`, `logical-payload-checks.json`; exact inspected map/physical manifest/transport documentation copies are included. No full new checkout, Git/Cargo/source/API/model writes or build was performed.

## Bounded Windows installed-toolchain discovery

Normal prlctl current-user inline PowerShell probe exit0. Existing explicit tools:
`C:\Users\rabii\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin\cargo.exe` and sibling`rustc.exe`. Exact rustc host`x86_64-pc-windows-msvc`1.99.1(58cf8f9c3); Cargo1.99.1(5f94df478). Default remains ARM64 toolchain; no default/settings/install changes. Actual OS/process host remains Windows11 ARM64, x64 Rust runs emulated, not native-x64 OS qualification. Tool executable hashes/raw output retained. This discovery alone is not compilation or tests. Guest probe is complete, no running process/lease remains.

## Next owner

Engineer supplies final combined frozen source+lock identity. Verifier independently checks complete checkout at identical33-character NTFS root with command-level longpaths=false, all Git file identities/newline conversion, TAR fidelity and newly affected tests with explicit installed x64 tools. No new baseline/source test replay or unsupported platform claim. Parent accepted gpt-6.1-sol/xhigh; exposed runtime metadata unavailable. No reusable-memory write warranted for this bounded evidence.
