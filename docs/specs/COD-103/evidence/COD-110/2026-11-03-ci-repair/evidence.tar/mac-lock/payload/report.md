# COD-110 Mac affected-lock follow-up

**Status:** PASS for these assigned Mac checks only. Windows focused tests remain blocked by the previously recorded LNK1181`ssl.lib` failure; this report does not overwrite that result.

**Source:** original worktree `/private/tmp/codebasegraph-cod110-20261101`, frozen327 Rust/manifest/lock files independently matching private candidate`a3b51c25bbea5e137bdeeac572a138c064834c9a` / tree`01ffaa61cd444f16284319bcc4799ff1865d88e9` before and after all execution. Cargo.lockSHA256`ffc44cf15ff000954c4caf15d017df5c15564e5b7b4fd0dc376b4ce6f2a5e181`. Same approved COD-110/C103 revision0.3 and focused repair ledger`chg-0p9sje`; no source, model or tracking writes. Exclusive original Mac target lease was explicitly transferred before checks.

| Actual command | Result | Evidence |
|---|---|---|
| `cargo fmt --check` | exit0 | `fmt.stdout/stderr/result.json` |
| `cargo clippy --workspace --all-targets --all-features --locked -- -D warnings` | exit0;0 compiler warnings | `clippy.stdout/stderr/result.json` |
| `cargo test --locked -p xtask` | exit0;158 passed,0 failed/ignored/filtered | `xtask-full.stdout/stderr/result.json`; all actual names in `xtask-executed-inventory.json` |

Full xtask replay was applicable: actual `crates/xtask/src/main.rs:3863–3877::release_gate_source_sha_fixture` copies the current repository Cargo.lock into a real Git fixture at runtime. It is not an `include_str!` dependency, but the changed fixture input invalidates the prior matching closure. See`lock-fixture-closure.json`. No repeated k-wiki15 checks were run.

Environment remains native macOS26.6.2 ARM64, rustc/cargo1.96.0 aarch64-apple-darwin, default test profile for xtask and explicit all-features/all-targets strict Clippy. Existing Cargo target/dependency cache reused under one owner; current source root is in compiler output. No genuine JUnit produced and none fabricated; no MSRV1.82 execution. cargo-audit remains unavailable, not a passing scan; hosted security/CI remains due. Compiler warnings0 is distinct from existing allowed security advisories.

All commands are complete (real bash-done exits), source closure unchanged. Mac target lease released; no Windows/VM actions occurred. Parent accepted Evidence Verifier gpt-6.1-sol/xhigh; runtime self metadata unexposed. Next: Engineer uses this narrow Mac result alongside—not instead of—the immutable Windows-blocked report and prerequisite follow-up. No PR/push/qualification/aggregate closure is asserted. No reusable-memory mutation warranted.
