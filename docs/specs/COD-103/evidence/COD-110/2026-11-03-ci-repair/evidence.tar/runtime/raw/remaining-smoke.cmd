@echo off
setlocal DisableDelayedExpansion
set "RUNTIME_BIN=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\bin"
set "EVIDENCE=C:\Mac\Home\Documents\c110-win-ready-direct-20261103"
set "SOURCE=C:\Users\rabii\c110y-b37cb6\repo"
set "CLI=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\codebase-graph.exe"
set "PROFILE=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
set "FIXTURE=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\fixture"
set "DB=%FIXTURE%\remaining-smoke.ldb"
set "MANIFEST=%FIXTURE%\remaining-manifest.json"
set "LEGACY=%FIXTURE%\remaining-legacy-manifest.json"
set "USERPROFILE=%PROFILE%"
set "LOCALAPPDATA=%PROFILE%\AppData\Local"
set "APPDATA=%PROFILE%\AppData\Roaming"
set "TEMP=%PROFILE%"
set "TMP=%PROFILE%"
set "PATH=%RUNTIME_BIN%;%PATH%"
set "CARGO_NET_OFFLINE=true"
set "LBUG_VERSION=0.19.0"
cd /d "%FIXTURE%"
if errorlevel 1 exit /b %errorlevel%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\db-build.start"
"%CLI%" build --repo-root "%FIXTURE%\sample" --db "%DB%" --manifest "%MANIFEST%" --no-git --json >"%EVIDENCE%\db-build.stdout" 2>"%EVIDENCE%\db-build.stderr"
set "INNER_EXIT=%errorlevel%"
>"%EVIDENCE%\db-build.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\db-build.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
if errorlevel 1 exit /b %errorlevel%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\sidecar-search.start"
"%CLI%" codebase-search helper --repo-root "%FIXTURE%\sample" --db "%DB%" --manifest "%MANIFEST%" --no-refresh --json >"%EVIDENCE%\sidecar-search.stdout" 2>"%EVIDENCE%\sidecar-search.stderr"
set "INNER_EXIT=%errorlevel%"
>"%EVIDENCE%\sidecar-search.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\sidecar-search.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
if errorlevel 1 exit /b %errorlevel%
call :helper_assert sidecar-search
if errorlevel 1 exit /b %errorlevel%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';$s=[IO.File]::ReadAllText($env:MANIFEST);$m=ConvertFrom-Json -InputObject $s;if($null -eq $m.search_backend){throw 'Expected sidecar backend before legacy seam'};$m.search_backend=$null;[IO.File]::WriteAllText($env:LEGACY,($m|ConvertTo-Json -Depth 100),(New-Object Text.UTF8Encoding($false)))"
if errorlevel 1 exit /b %errorlevel%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\fts-search.start"
"%CLI%" codebase-search helper --repo-root "%FIXTURE%\sample" --db "%DB%" --manifest "%LEGACY%" --no-refresh --json >"%EVIDENCE%\fts-search.stdout" 2>"%EVIDENCE%\fts-search.stderr"
set "INNER_EXIT=%errorlevel%"
>"%EVIDENCE%\fts-search.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\fts-search.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
if errorlevel 1 exit /b %errorlevel%
call :helper_assert fts-search
if errorlevel 1 exit /b %errorlevel%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\warm-sidecar-search.start"
"%CLI%" codebase-search helper --repo-root "%FIXTURE%\sample" --db "%DB%" --manifest "%MANIFEST%" --no-refresh --json >"%EVIDENCE%\warm-sidecar-search.stdout" 2>"%EVIDENCE%\warm-sidecar-search.stderr"
set "INNER_EXIT=%errorlevel%"
>"%EVIDENCE%\warm-sidecar-search.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\warm-sidecar-search.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
if errorlevel 1 exit /b %errorlevel%
call :helper_assert warm-sidecar-search
if errorlevel 1 exit /b %errorlevel%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\warm-fts-search.start"
"%CLI%" codebase-search helper --repo-root "%FIXTURE%\sample" --db "%DB%" --manifest "%LEGACY%" --no-refresh --json >"%EVIDENCE%\warm-fts-search.stdout" 2>"%EVIDENCE%\warm-fts-search.stderr"
set "INNER_EXIT=%errorlevel%"
>"%EVIDENCE%\warm-fts-search.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"%EVIDENCE%\warm-fts-search.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
if errorlevel 1 exit /b %errorlevel%
call :helper_assert warm-fts-search
if errorlevel 1 exit /b %errorlevel%
exit /b 0

:helper_assert
set "CHECK_FILE=%EVIDENCE%\%~1.stdout"
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';$j=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($env:CHECK_FILE));$hits=@($j.results|Where-Object {$_.label -eq 'helper' -and $_.path -match '(^|[/\\])service\.py$'});if($hits.Count -lt 1){throw 'Expected actual helper/service.py result missing'}"
exit /b %errorlevel%
