@echo off
setlocal DisableDelayedExpansion
set "RUNTIME_MANIFEST=%~dp0windows-runtime.json"
set "RUNTIME_BIN="
for /f "tokens=1,* delims==" %%A in ('powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';$m=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($env:RUNTIME_MANIFEST));foreach($f in $m.files){$i=Get-Item -LiteralPath $f.path;if(($i.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $i.Length -ne $f.bytes -or (Get-FileHash -LiteralPath $f.path -Algorithm SHA256).Hash -ne $f.sha256){throw 'Runtime dependency drift'}};[Console]::WriteLine('RUNTIME_BIN='+$m.bin)"') do if "%%A"=="RUNTIME_BIN" set "RUNTIME_BIN=%%B"
if not defined RUNTIME_BIN exit /b 5
set "PATH=%RUNTIME_BIN%;%PATH%"
call "%~dp0windows-test.cmd" %*
exit /b %errorlevel%
