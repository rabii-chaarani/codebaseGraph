@echo off
setlocal DisableDelayedExpansion
call "C:\Mac\Home\Documents\c110-win-ready-direct-20261103\remaining-smoke.cmd" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\remaining-smoke.stdout" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\remaining-smoke.stderr"
set "INNER_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\remaining-smoke.exit" echo %INNER_EXIT%
exit /b %INNER_EXIT%
