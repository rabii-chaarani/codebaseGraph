@echo off
setlocal DisableDelayedExpansion
set "A=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-static-attempt-01"
set "B=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01"
if exist "%B%" exit /b 10
for %%D in (manifest registries downloads buildtrees packages installed tmp profile appdata-local appdata-roaming) do mkdir "%B%\%%D"
if errorlevel 1 exit /b %errorlevel%
copy /b "C:\Mac\Home\Documents\c110-win-ready-direct-20261103\vcpkg.json" "%B%\manifest\vcpkg.json" >nul
if errorlevel 1 exit /b %errorlevel%
copy /b "%A%\downloads\openssl-openssl-openssl-3.6.0.tar.gz" "%B%\downloads\openssl-openssl-openssl-3.6.0.tar.gz" >nul
if errorlevel 1 exit /b %errorlevel%
robocopy "%A%\registries" "%B%\registries" /E /NFL /NDL /NJH /NJS /NP /R:0 /W:0
if errorlevel 8 exit /b %errorlevel%
copy /b "C:\Mac\Home\Documents\c110-win-ready-direct-20261103\build-runtime.cmd" "%B%\build-runtime.cmd" >nul
if errorlevel 1 exit /b %errorlevel%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Get-FileHash -LiteralPath '%B%\build-runtime.cmd','%B%\downloads\openssl-openssl-openssl-3.6.0.tar.gz' -Algorithm SHA256|ConvertTo-Json"
exit /b %errorlevel%
