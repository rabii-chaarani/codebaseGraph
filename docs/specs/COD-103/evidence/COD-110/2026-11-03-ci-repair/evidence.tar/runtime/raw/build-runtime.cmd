@echo off
setlocal
call "C:\BuildTools\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
if errorlevel 1 exit /b %errorlevel%
set "A=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01"
cd /d "%A%"
set "TMP=%A%\tmp"
set "TEMP=%A%\tmp"
set "LOCALAPPDATA=%A%\appdata-local"
set "APPDATA=%A%\appdata-roaming"
set "USERPROFILE=%A%\profile"
set "HOME=%A%\profile"
set "X_VCPKG_REGISTRIES_CACHE=%A%\registries"
set "VCPKG_DOWNLOADS=%A%\downloads"
set "VCPKG_BINARY_SOURCES=clear"
set "X_VCPKG_ASSET_SOURCES=clear"
set "VCPKG_DISABLE_METRICS=1"
set "VCPKG_FORCE_SYSTEM_BINARIES=1"
set "VCPKG_FORCE_DOWNLOADED_BINARIES="
set "VCPKG_MAX_CONCURRENCY=1"
set "PKG_CONFIG=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-static-attempt-01\downloads\tools\msys2\d4c54642209fbbfd\clangarm64\bin\pkg-config.exe"
set "VCPKG_KEEP_ENV_VARS=PKG_CONFIG;PATH;VCPKG_FORCE_SYSTEM_BINARIES;VCPKG_MAX_CONCURRENCY;VCPKG_DISABLE_METRICS"
set "PATH=;%PATH%;"
set "PATH=%PATH:;C:\Users\rabii\AppData\Local\Microsoft\WindowsApps;=;%"
set "PATH=%PATH:~1,-1%"
set "PERL5LIB="
set "PERLLIB="
set "PERL5OPT="
set "PERL_LOCAL_LIB_ROOT="
set "PERL_MB_OPT="
set "PERL_MM_OPT="
set "PATH=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\strawberry-perl-5.42.0.1-attempt-01\sdk\perl\bin;C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\powershell-7.5.3-attempt-01\sdk;C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\ninja-1.13.1-attempt-01\sdk;C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\nasm-2.16.03-attempt-01\sdk\nasm-2.16.03;C:\Program Files\CMake\bin;C:\Program Files\Git\cmd;%PATH%"
"C:\BuildTools\VC\vcpkg\vcpkg.exe" install --no-downloads --x-manifest-root="%A%\manifest" --triplet=x64-windows --host-triplet=x64-windows --downloads-root="%A%\downloads" --x-buildtrees-root="%A%\buildtrees" --x-packages-root="%A%\packages" --x-install-root="%A%\installed" --x-registries-cache="%A%\registries" --binarysource=clear --x-asset-sources=clear
exit /b %errorlevel%
