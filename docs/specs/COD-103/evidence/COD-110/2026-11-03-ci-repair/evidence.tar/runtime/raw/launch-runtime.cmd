@echo off
setlocal DisableDelayedExpansion
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\runtime-build.start" echo %DATE% %TIME%
call "C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\build-runtime.cmd" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\runtime-build.stdout" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\runtime-build.stderr"
set "INNER_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\runtime-build.exit" echo %INNER_EXIT%
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\runtime-build.end" echo %DATE% %TIME%
exit /b %INNER_EXIT%
