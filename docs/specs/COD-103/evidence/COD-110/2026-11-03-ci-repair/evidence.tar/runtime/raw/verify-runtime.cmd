@echo off
setlocal DisableDelayedExpansion
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';$b='C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\bin';$a=@();foreach($n in @('libssl-3-x64.dll','libcrypto-3-x64.dll')){$p=Join-Path $b $n;$i=Get-Item -LiteralPath $p;$d=[IO.File]::ReadAllBytes($p);$o=[BitConverter]::ToInt32($d,60);if([BitConverter]::ToUInt16($d,$o+4) -ne 34404){throw 'Not AMD64'};$a+=@{path=$p;bytes=$i.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant();machine='AMD64'}};@{version='3.6.0';triplet='x64-windows';bin=$b;files=$a}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath 'C:\Mac\Home\Documents\c110-win-ready-direct-20261103\windows-runtime.json' -Encoding UTF8"
if errorlevel 1 exit /b %errorlevel%
"C:\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x64\dumpbin.exe" /dependents "C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\bin\libssl-3-x64.dll" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\libssl-imports.txt"
if errorlevel 1 exit /b %errorlevel%
"C:\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x64\dumpbin.exe" /dependents "C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\bin\libcrypto-3-x64.dll" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\libcrypto-imports.txt"
if errorlevel 1 exit /b %errorlevel%
copy /b "C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\share\openssl\copyright" "C:\Mac\Home\Documents\c110-win-ready-direct-20261103\openssl-copyright.txt" >nul
if errorlevel 1 exit /b %errorlevel%
copy /b "C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\share\openssl\vcpkg_abi_info.txt" "C:\Mac\Home\Documents\c110-win-ready-direct-20261103\openssl-abi.txt" >nul
exit /b %errorlevel%
