@echo off
setlocal DisableDelayedExpansion
set "PATH=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\bin;%PATH%"
set "USERPROFILE=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
set "LOCALAPPDATA=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile\AppData\Local"
set "APPDATA=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile\AppData\Roaming"
set "TEMP=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
set "TMP=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
cd /d "C:\Users\rabii\c110y-b37cb6\repo"
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-1.start"
"C:\Users\rabii\c110y-b37cb6\target\debug\deps\codebase_graph-119d825a22a27bff.exe" adapters::cli::tests::graph::graph_search_reads_native_fts_indexes --exact --test-threads=1 >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-1.stdout" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-1.stderr"
set "INNER_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-1.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-1.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-2.start"
"C:\Users\rabii\c110y-b37cb6\target\debug\deps\codebase_graph-119d825a22a27bff.exe" api::graph_read::tests::manifest_without_backend_metadata_uses_legacy_ladybug_fts --exact --test-threads=1 >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-2.stdout" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-2.stderr"
set "INNER_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-2.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-first-2.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-1.start"
"C:\Users\rabii\c110y-b37cb6\target\debug\deps\codebase_graph-119d825a22a27bff.exe" adapters::cli::tests::graph::graph_search_reads_native_fts_indexes --exact --test-threads=1 >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-1.stdout" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-1.stderr"
set "INNER_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-1.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-1.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-2.start"
"C:\Users\rabii\c110y-b37cb6\target\debug\deps\codebase_graph-119d825a22a27bff.exe" api::graph_read::tests::manifest_without_backend_metadata_uses_legacy_ladybug_fts --exact --test-threads=1 >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-2.stdout" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-2.stderr"
set "INNER_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-2.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-warm-2.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
exit /b 0
