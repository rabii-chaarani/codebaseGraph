@echo off
setlocal DisableDelayedExpansion
set "PATH=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\bin;%PATH%"
set "USERPROFILE=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
set "LOCALAPPDATA=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile\AppData\Local"
set "APPDATA=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile\AppData\Roaming"
set "TEMP=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
set "TMP=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
cd /d "C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\fixture"
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\warm-sidecar-search.start"
"C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\codebase-graph.exe" codebase-search helper --repo-root "C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\fixture\sample" --db "C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\fixture\remaining-smoke.ldb" --manifest "C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\fixture\remaining-manifest.json" --no-refresh --json >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\warm-sidecar-search.stdout" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\warm-sidecar-search.stderr"
set "INNER_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\warm-sidecar-search.exit" echo %INNER_EXIT%
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "[DateTime]::UtcNow.ToString('o')" >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\warm-sidecar-search.end"
if not "%INNER_EXIT%"=="0" exit /b %INNER_EXIT%
copy /b "C:\Mac\Home\Documents\c110-win-ready-direct-20261103\windows-ready.cmd" "C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\windows-ready.cmd" >nul
if errorlevel 1 exit /b %errorlevel%
copy /b "C:\Mac\Home\Documents\c110-win-ready-direct-20261103\windows-runtime.json" "C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\windows-runtime.json" >nul
if errorlevel 1 exit /b %errorlevel%
call "C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\windows-ready.cmd" --preflight >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\windows-ready-preflight.stdout" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\windows-ready-preflight.stderr"
set "PREFLIGHT_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\windows-ready-preflight.exit" echo %PREFLIGHT_EXIT%
exit /b %PREFLIGHT_EXIT%
