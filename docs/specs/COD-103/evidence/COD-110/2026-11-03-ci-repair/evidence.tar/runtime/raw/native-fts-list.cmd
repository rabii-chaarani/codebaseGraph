@echo off
setlocal DisableDelayedExpansion
set "PATH=C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\openssl-runtime-dynamic-attempt-01\installed\x64-windows\bin;%PATH%"
set "USERPROFILE=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
set "LOCALAPPDATA=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile\AppData\Local"
set "APPDATA=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile\AppData\Roaming"
set "TEMP=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
set "TMP=C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\profile"
cd /d "C:\Users\rabii\c110y-b37cb6\repo"
"C:\Users\rabii\c110y-b37cb6\target\debug\deps\codebase_graph-119d825a22a27bff.exe" fts --list >"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-tests.list" 2>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-tests-list.stderr"
set "INNER_EXIT=%errorlevel%"
>"C:\Mac\Home\Documents\c110-win-ready-direct-20261103\native-fts-tests-list.exit" echo %INNER_EXIT%
exit /b %INNER_EXIT%
