# COD-110 Windows affected tests and environment follow-up

**Status:** affected wiki15 PASS; exact bundled-extension unit1 PASS; native setup smoke **BLOCKED**. No overall READY, final Windows application qualification, PR/push or closure assertion.

## Source and inputs

Same retained source`C:\Users\rabii\c110y-b37cb6\repo`: private transport commit`a3b51c25bbea5e137bdeeac572a138c064834c9a`, tree`01ffaa61cd444f16284319bcc4799ff1865d88e9`; source stayed clean before/after. LocknormalizedLF SHA256`ffc44cf15ff000954c4caf15d017df5c15564e5b7b4fd0dc376b4ce6f2a5e181` (rawWindowsCRLF`2121a60fd92b2bc14044ac38532b044d24876efcacc462db5b3f942e25d6daee`). Existing target`C:\Users\rabii\c110y-b37cb6\target` reused, no clean/coldtarget/profile switch. Existing dual-host3213-file checkout and200-member/711-logical evidence fidelity remains unchanged.

Approved COD-110/C103 spec0.3 at316be4c4bb81d4f6e025016b12374836b4dcc1a8, separate approval0e6008a1f46679a86aba85ac513beb05af94b0c0; focused repairledgerchg-0p9sje. Explicit retained-output authority/userapproval8172ae17-1cbd-4df8-a243-cbbd1ee5990b was handed off by Engineer. Historical MSYS2 acquisition incident is not erased or independently re-approved here. This assignment caused no dependency acquisition/install/source/model/tracking write.

Read-only entry`C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\windows-test.cmd` SHA256`11f9734c3239be666432a08558f015a0f20b7f86d52f24b13f61e14896f77e09`; adjacent descriptorSHA256`ae0c408ca7a48075c0cc8b75ddd1860158baed9a46f821e5884ebc2671718977`. Accepted normal entry preflight0 and source/head/tree/status actualreadback in`preflight-short.*`. Dependency/tool size/time/reparse metadata matched descriptor before/after; this is **not** fresh full1.4GB library integrity verification.

## Actual executed evidence

| Check | Actual command/result | Raw evidence |
|---|---|---|
| Affected wiki behavior | accepted entry `test --offline --locked -p k-wiki --test compilation --test rendering --test projection`, defaultprofile/features, **host0 + innerexitfile0**, all15 expected actual names(5+4+6),0failed/ignored/filtered | `wiki-tests-attempt2.stdout/stderr/result.json`, `guest-wiki-tests-attempt2.exit`, exact caller `.cmd`/env |
| Bundled JSON/FTS decompression | root exact`db_writer::extensions::tests::bundled_extension_archives_decompress_before_cache_seed` list:exact1; run:1passed0failed/ignored,829filtered | `bundle-list.*`, `bundle-run.*`, corresponding guestexitfiles; no zero-selection pass |
| Fresh normal CLI | entry `build --offline --locked -p codebase-graph --bin codebase-graph --message-format=json-render-diagnostics`, host0/inner0. Unique exact source-root Cargo.toml/compiler-artifact/bin/profile.test=false/fresh=false selected. Copied before later Cargo work; source+copy hash equal | `cli-build.*`, `cli-compiler-artifact.json`, `cli-copy.*`, `native-build-binding.json` |
| Real native DB/JSON | capturedCLI`build --repo-root <fixture>\sample --db <fixture>\extension-smoke.ldb --manifest <fixture>\extension-manifest.json --no-git --json`, **host1 + innerCLI1** | `db-build.stdout/stderr/result.json`, `guest-db-build.exit`; failed fixture retained |
| Sidecar search, null-backend native FTS, fullcacheassetchecks, PEimports, warmrepeat | **NOT RUN**: dependent on successful DBbuild, stopped on actual failure | No passing inference from unit/cached files/static source. No warm time or no-download success claim. |
| Actual poststate | source status0 clean, exacthead/tree, heavy_count0; separatedependency_metadata_match1 + capturedCLIhashsame + seededJSONhash | `post-state-short.*`, `post-integrity.*` (both actualexit0) |

Normal CLI captured at`C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017\codebase-graph.exe`, SHA256`03be889f09a87bc87032bcfe7653be71f12b1df916c34efa2c56fcd358ecaab9`. CompilerJSON proves lbugbuild-script selected external frozen SDK directory`C:\Users\rabii\codebaseGraph-COD111-tests\dependencies-20261102\ladybug-sdk`; rebuiltlbug/root/wiki from currentsource. `native-build-binding.json` records exact native linkedpaths/flags. No old failed binary was reused. Actual CLI debug_assertions=true/overflowchecks=true; root default bundled-windows-extensions enabled. No ordinaryrelease/native-tests substitution.

Fixture exactservice.pybytes`def helper():\n    return 1\n` SHA256`b6631639de17fb869c43278f858c465cc5b71c8ec51c8c25d803905361f8a544`. Disposable fixture/profile/evidence only under`C:\Users\rabii\c110y-b37cb6\c110-win-follow-20261102T234408Z-26a017`; normal .cargo/.rustup cache allowed. USERPROFILE/AppData/TEMP isolated; Rusthomes explicit. Caller inheritedflags/wrappers/customcompilers/targetoverrides captured+cleared, offline+LBUG_VERSION0.19.0+serialtests set. CallerHOME is existingownedhome for entryvalidation; Cargo config separately forces source-relative`target/test-home`. No global/persistent settings changed.

## Confirmed runtime failure and limits

`db-build.stderr` states isolated Ladybug schema phase failed to load existing`json/libjson.lbug_extension`; “The extension itself was found, so a library it depends on is the one that could not be located.” Diagnostic names OpenSSL3 DLLs`libssl-3-x64.dll` and`libcrypto-3-x64.dll`, not distributed with the extensions. Static OpenSSL link success did **not** establish runtime extension dependency readiness. No missing-DLL discovery/PEimport check was executed, so exact missing dependent DLL remains diagnostic-indicated, not independently import-resolved. No baseline comparison proves a new regression or pre-existing behavior.

Actual seededJSONSHA256`bdecb5201dd6abccc06ddc1f6cb4fcf0be3adb7aa3ddaac2f383ed129fca2b1f` matches bundled bytes; this confirms payload identity, **not successful load**. FTS/load/search/warmremain pending. No automatic retry/download/SDKfallback/sourcefix was attempted. Existing accepted staticlibrary descriptor/nativepath is unchanged.

## Preserved failed harness actions and correction history

- Initial oversized encoded preflight returnedprlctl255 beforeexecution; ordinarycmdver0 then short trustedentrypreflight0. Both outputs retained. A caller preparation action loaded owned scripttext inline before a later parent prohibition arrived; disclosed immediately. NoExecutionPolicychange/bypass occurred; all later callers use ordinary `.cmd` and fixeddataqueries, no scripttextloading.
- First wiki caller exitedentry3 beforeCargo because configuredHOME directory did not exist. Source/target/profileandownedhome existed; heavy0. Parent approved only newcallerHOME→alreadycreatedownedhome; correctedordinarycaller then ran actual15tests. Original entry3env/logs unchanged. Wrapper label`actual_cargo_exit=3` was misleading: it is entryvalidation3, **not Cargo execution**.
- First longpoststate returned255InvalidArgument/nonstart. A chat message prematurely claimed anticipatedpoststate0/hash/quiescence; immediately retracted. Later **actual** shortpoststate0 and separateintegrity0 support finalstate; failed255 was not counted as success. No critical result is based on launcher0 alone.
- Prior immutable closed Windows linker-blocked report`/private/tmp/c110-ev-final-20261102T204847Z-b37cb6/payload/report.md` and [explicit retraction](/private/tmp/c110-ev-retraction-20261102T210914Z/retraction.json) remain historical. Its Windows0tests/Cargo101 was real then; this new evidence advances **only** the actually executed15+1 checks, not overwriting prior failures.

## Environment, pending owner and stop

Windows11 ARM64 build10.0.26300.9711 with x64-emulated Rust/cargo1.99.1, MSVC14.44.35207 Hostx64/x64. Native x64 OS/MSRV1.82/fullWindowscohorts not claimed. No compilerwarning lines in this follow-up's successful Cargooutputs. No JUnit produced/fabricated. Previous Mac15, fmt/strictClippy0warnings/fullxtask158 remain separately valid. cargo-audit unavailable/notpass; hostedCI/security/finalreview/normalfinalcommitbinding remain due.

Engineer/user owns next bounded runtime-DLL prerequisite decision; no acquisition/override is implied. Stop before dependentnativeFTS/warm readiness. All own Bash/Cargo/CLIprocesses terminal; actual guestheavy0, lease **released**. Required/parentaccepted Evidence Verifiergpt-6.1-sol/xhigh; selfruntime metadata unexposed. No memory/model/claim/tracking writes. This is an honest partial execution, not a setup-ready or whole-issue acceptance report.
