include!(concat!(env!("REVIEW_SNAPSHOT"), "/src/storage/test_harness.rs"));

#[cfg(unix)]
fn review_direct_case(case: &str) {
    use std::os::unix::fs::PermissionsExt;
    use sha2::{Digest, Sha256};
    let root = temp_dir(&format!("review-direct-{case}"));
    let parent = root.join("destination");
    fs::create_dir(&parent).unwrap();
    let layout = DirectLayout::new(parent.join("graph.ldb"), parent.join("manifest.json"));
    fs::write(layout.db_path(), b"previously committed graph").unwrap();
    fs::write(layout.manifest_path(), b"{}").unwrap();
    drop(storage::locks::open_locked(layout.writer_lock_path(), LockMode::Exclusive).unwrap());
    // The shared resource guards already exist and are readable. This isolates
    // registration requirements from the mandatory database-use guard boundary.
    fs::write(parent.join(".database-use-family.lock"), b"").unwrap();
    for name in ["graph.ldb", "manifest.json"] {
        let digest = format!("{:x}", Sha256::digest(name.as_bytes()));
        fs::write(parent.join(format!(".database-use-{digest}.lock")), b"").unwrap();
    }
    let writer_name = layout.writer_lock_path().file_name().unwrap().to_string_lossy().into_owned();
    let key = writer_name.strip_prefix(".direct-publish-").unwrap().strip_suffix(".lock").unwrap();
    let registration = parent.join(format!(".direct-registration-{key}.json"));
    if case == "corrupt-registration" {
        fs::write(&registration, b"interrupted or corrupt metadata").unwrap();
    }
    let previous_permissions = fs::metadata(&parent).unwrap().permissions();
    if case == "readonly-missing-registration" {
        fs::set_permissions(&parent, fs::Permissions::from_mode(0o555)).unwrap();
    }
    let read = DirectStore::new(layout.clone()).unwrap().begin_read();
    let error = read.as_ref().err().map(ToString::to_string);
    drop(read);
    fs::set_permissions(&parent, previous_permissions).unwrap();
    assert_eq!(fs::read(layout.db_path()).unwrap(), b"previously committed graph");
    assert_eq!(fs::read(layout.manifest_path()).unwrap(), b"{}");
    println!("snapshot={} case={case} read_error={error:?}", env!("REVIEW_SNAPSHOT"));
    fs::remove_dir_all(&root).unwrap();
    assert!(error.is_none(), "valid committed Direct pair was unavailable: {error:?}");
}

#[test]
#[cfg(unix)]
fn integrated_probe_direct_first_read_writable_parent() { review_direct_case("writable-missing-registration"); }
#[test]
#[cfg(unix)]
fn integrated_probe_direct_readonly_parent_with_existing_coordination() { review_direct_case("readonly-missing-registration"); }
#[test]
#[cfg(unix)]
fn integrated_probe_direct_corrupt_registration_preserves_committed_read() { review_direct_case("corrupt-registration"); }
