from pathlib import Path
import os, subprocess, sys, hashlib, json, re, shutil
probe=Path(__file__).resolve().parent
label=sys.argv[1]
snapshot=Path(sys.argv[2])
outputs=probe/label
outputs.mkdir(exist_ok=True)
env=os.environ.copy()
env['REVIEW_SNAPSHOT']=str(snapshot)
env['CARGO_TARGET_DIR']='/Users/rabii/Projects/Repositories/codebaseGraph/target'
command=['cargo','test','--offline','--locked','--test','direct_read_metadata','integrated_probe_direct_','--','--nocapture','--test-threads=1']
hashes=lambda:{str(p.relative_to(snapshot)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((snapshot/'src').rglob('*.rs'))}
before=hashes()
result=subprocess.run(command,cwd=probe,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(outputs/'execution.txt').write_text(result.stdout)
print(result.stdout,flush=True)
match=re.search(r'Running probe.rs \(([^\n)]+)\)',result.stdout)
if not match:
    match=re.search(r'Running [^\n]+ \(([^\n)]+direct_read_metadata[^\n)]+)\)',result.stdout)
binary=Path(match.group(1)) if match else None
metadata={'snapshot':str(snapshot),'command':command,'environment':{k:env[k] for k in ['REVIEW_SNAPSHOT','CARGO_TARGET_DIR']},'returncode':result.returncode,'source_hashes_unchanged':before==hashes(),'binary':str(binary) if binary else None,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if binary and binary.is_file() else None}
if binary and binary.is_file():
    shutil.copy2(binary,outputs/'probe-binary')
(outputs/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
(outputs/'source-after.json').write_text(json.dumps(hashes(),indent=2)+'\n')
(outputs/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2),flush=True)
