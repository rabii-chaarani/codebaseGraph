# DC-S2 Direct committed-read registration restoration

Status: source frozen for independent integrated reviewer; worker does not accept its own fix. HEAD16081af63122eea06af3acafedf67f168695c366 (integrated code e968 plus documentation). Owned files only src/storage/direct.rs and src/storage/test_harness.rs. Coordinator docs modifications preserved. No Git/model/wiki writes, no live data operations, no public native-helper changes.

## Change and invariants

Ordinary DirectStore::begin_read no longer calls register_direct_pair. Existing destination writer ownership and both DB/manifest shared resource + physical-parent family guards still cover its entire returned lifetime. All original pair validation and guard errors still propagate. This restores committed read availability when producer-overlap registration is absent, corrupt or uncreatable in a readonly parent. Ordinary reads do not create, decode, repair or adopt that registration.

register_direct_pair remains strict in begin_write and is now explicitly required by recover_with_lock after finding a publication journal, before any replay effects. Required replay cannot be skipped merely to serve an uncertain pair. No epoch, cohort, guard identity or collector policy was weakened.

Registration records are overlap evidence, never proof of inactivity/quiescence. Missing/invalid records remain unchanged by ordinary reads. A read cannot create destination cohort proof. The tests exercise a valid modern artifact-root provenance beside legacy Direct state and assert that any acquired maintenance lease still has cohort_verified=false; unknown/deferred admission likewise supplies no authority. Corrupt registration continues preventing strict producers/replay, and current overlap validators preserve it as unknown. Lifetime exclusion remains writer+DB+manifest family/resource ownership independent of registration. No future collector implementation is added here.

## Patch/source identity

Direct source SHA256 c40e99468c2ab0a465b7a5b5ee2a8e755c872d450da5e88cd212d91365691e25
Harness source SHA256 3d94ecbe47000f8dcc77f0f2dff3a7ec3c0bdc5087b0ab3e01b3d78d1b5cdf58
owned.patch SHA256 c24809e5c8dde1749b717b83347ca81afc6feac1cd6ae487d9324929f62561b6

All137Rust sources were hashed before and after the final run; identical lexicographically sorted relative-path identity b987bc054651cb0cb4fbfd56cff0e33f5c27d92bc27cb4680d79dbcdccb1d2f4. Per-source data is archived in direct-registration-source-before.json and source-after.json. Identity format: relative-path strings sorted lexicographically (Python sorted(mapping)); UTF-8 path + NUL + ASCII lowercase SHA256 + LF, concatenated then SHA256. The prior value 5a16444a8d3bee62a40508f8b9a5d118fbbe2c28c8b55c89df2900005b4405a0 is independently reproducible using tuple-of-path-components ordering, inherited from sorting pathlib.Path objects. The earlier description incorrectly called that string ordering. identity-correction.json records both algorithms and document hashes. Historical source maps, logs, JUnit and outcomes are unchanged. Immutable two-file copies under source/. manifest.json includes exact package cwd, selected inventory and actual binary hashes.

## Executed checks

Local macOS aarch64, Rust installed toolchain, Cargo offline/locked. SharedCargo exclusive window used. Root-package-only codegen override139 forces a visible root rebuild from /private/tmp/codebasegraph-disk-cleanup-7t9af0a6/repo; the root rebuild line is retained in direct-registration-final-test.log. This avoids attributing another checkout's shared-target result to this source.

Final command:
CARGO_TARGET_DIR=/Users/rabii/Projects/Repositories/codebaseGraph/target cargo --config profile.test.package.codebase-graph.codegen-units=139 nextest run --offline --locked --test storage_foundation --lib --config-file /private/tmp/codebasegraph-disk-cleanup-7t9af0a6/nextest.toml --profile cleanup-s2 -E 'binary(storage_foundation) | test(dc_s2) | test(dc_epoch_optional) | test(api::context::tests::resolve_runtime_recovers_direct_pair_before_returning_read_lease)' --test-threads 4

Result172/172 passed in23.437s, run7f63d502-6f75-4283-917e-e0438a3f8667, no leak label.131foundation executions +41LIB executions. Same-command nextest list JSON independently records expected172selected unignored cases; final JUnit contains172actual testcases and no failures/errors. Existing ignored subprocess-only helper remains unchanged; no new ignored tests. Direct registration's initial focused3/3 also passed (log archived).

New tests:
- direct_committed_read_preserves_missing_registration
- direct_committed_read_accepts_readonly_parent_with_existing_guards (normal Unix permission test, cfgunix; no Windows directory-mode claim)
- direct_committed_read_preserves_corrupt_registration
- direct_committed_registered_pair_reads_after_publication

First3 reproduce the independent review counterexamples, assert pair/registration exact bytes and file identities, unchanged missing evidence, current use exclusion and no destination cohort manufactured. Corrupt case additionally asserts producer and required-journal replay rejection and preserved journal/registration. Fourth exercises actual DirectStore begin_write→publish→finish→registered read lifecycle and preserved committed bundle/registration. The harness graph bytes are synthetic: this proves storage publication/read admission, not Ladybug-native query execution. Existing Direct replay-all-renames, forged journals, sidecars, optional epoch faults, family aliases and real runtime resolution tests were included without modifying their assertions. API reachability of the original failure is supported by resolve_runtime→resolve_direct_read source and independent review; no new end-to-end nativequery scenario is claimed.

JUnit original location /private/tmp/codebasegraph-disk-cleanup-7t9af0a6/repo/target/nextest/cleanup-s2/junit.xml; archived direct-registration-final-junit.xml SHA256 c9c023e168fba81f76a0bc8a496b87301d92d0fe5f350b145b3720e6499ff645.
LIB binary SHA256 c3d4e5e7b1f9bb5873df15bcf2f5a4b4f48f14c8b7dab617179a2f2c7d42e144
Foundation binary SHA256 937092b4fce2264d2fcb87dfeb71bd4fab85ffaa9810a731449bf326b15aa55b
Both exact binary paths/cwd/source package IDs in manifest.json and full expected testinventory in direct-registration-test-inventory.json.

cargo --config profile.test.package.codebase-graph.codegen-units=139 check --offline --locked --lib --test storage_foundation passed,4.70s. Explicit owned rustfmt --check and git diff --check passed. Current production library has75existing pending foundation/dead-code warnings; this is not final warning-free acceptance and no suppressions were added.

Original independent baseline/current counterexample evidence remains /private/tmp/codebasegraph-integrated-availability-probe/{reviewed-focused,baseline-focused}/{execution.txt,metadata.json}: prior reviewed1pass/2fail versus originalmain018df35baseline3/3pass. That evidence used synthetic native bytes too; limitation retained.

## Pending/review handoff

No API or other source ownership was expanded. SharedCargo released after freeze. Independent reviewer must verify the narrow fix against this snapshot. Native Windows/Linux qualification, public raw-native boundary and latency/collector amendments remain pending; nothing in this fix authorizes DB retirement or broader collection. Coordinator owns claim/evidence folding, Git operations and memory/wiki recording.

Memory checkpoint: reads need actual use exclusion, not registration production. Keep producer overlap records strict for mutation/replay, while treating registration as evidence rather than a read-admission prerequisite or quiescence proof. This is a reusable refinement of existing availability/unknown-retention intent; coordinator can record after review.
