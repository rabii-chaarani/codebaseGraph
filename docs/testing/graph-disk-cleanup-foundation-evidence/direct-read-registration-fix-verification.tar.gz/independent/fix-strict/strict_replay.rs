include!(concat!(env!("REVIEW_SNAPSHOT"), "/src/storage/test_harness.rs"));

#[test]
fn integrated_probe_strict_registration_blocks_valid_prepared_replay_before_effects() {
    use sha2::{Digest, Sha256};
    use storage::direct::{DirectPublishJournal, DirectPublishPhase};
    use storage::locks::path_identity;
    use storage::maintenance_ownership::register_direct_pair;
    let root = temp_dir("review-valid-replay-registration");
    let layout = DirectLayout::new(root.join("graph.ldb"), root.join("manifest.json"));
    let store = DirectStore::new(layout.clone()).unwrap();
    let mut session = store.begin_write().unwrap();
    fs::write(session.db_candidate_path(), b"old committed graph").unwrap();
    fs::write(session.manifest_candidate_path(), b"{}").unwrap();
    session.publish().unwrap();
    session.finish();
    let next_database = b"new candidate graph";
    let next_manifest = br#"{"revision":"new"}"#;
    fs::write(layout.db_candidate_path(), next_database).unwrap();
    fs::write(layout.manifest_candidate_path(), next_manifest).unwrap();
    let journal = DirectPublishJournal {
        phase: DirectPublishPhase::Prepared,
        db_path: layout.db_path().to_owned(),
        db_candidate_path: layout.db_candidate_path(),
        manifest_path: layout.manifest_path().to_owned(),
        manifest_candidate_path: layout.manifest_candidate_path(),
        db_sha256: format!("{:x}", Sha256::digest(next_database)),
        manifest_sha256: format!("{:x}", Sha256::digest(next_manifest)),
        sidecar_sha256: std::collections::BTreeMap::new(),
    };
    storage::atomic::write_json_atomically(&layout.journal_path(), &journal).unwrap();
    // Validate the negative's journal before installing unrelated corrupt
    // registration, so an expected Err cannot be a journal JSON-parse failure.
    let decoded: DirectPublishJournal = serde_json::from_slice(&fs::read(layout.journal_path()).unwrap()).unwrap();
    assert_eq!(decoded.phase, DirectPublishPhase::Prepared);
    let registration = layout.registration_path();
    fs::write(&registration, b"corrupt registration sentinel").unwrap();
    let paths = [
        layout.db_path().to_owned(), layout.manifest_path().to_owned(),
        layout.db_candidate_path(), layout.manifest_candidate_path(),
        layout.journal_path(), registration.clone(),
    ];
    let before = paths.iter().map(|p| (p.clone(), (path_identity(p).unwrap(), fs::read(p).unwrap()))).collect::<std::collections::BTreeMap<_,_>>();
    let producer_error = store.begin_write().unwrap_err().to_string();
    assert!(producer_error.contains("expected value at line 1 column 1"), "{producer_error}");
    let read_error = store.begin_read().unwrap_err().to_string();
    assert!(read_error.contains("expected value at line 1 column 1"), "{read_error}");
    for (path, (identity, bytes)) in &before {
        assert_eq!(path_identity(path).unwrap(), *identity, "{}", path.display());
        assert_eq!(fs::read(path).unwrap(), *bytes, "{}", path.display());
    }
    // After fixture-only registration repair, this same untouched Prepared
    // journal completes. That proves the negative used a replayable journal.
    fs::remove_file(&registration).unwrap();
    register_direct_pair(&layout).unwrap();
    let reader = store.begin_read().expect("same valid Prepared journal must replay after registration is restored");
    assert_eq!(fs::read(layout.db_path()).unwrap(), next_database);
    assert_eq!(fs::read(layout.manifest_path()).unwrap(), next_manifest);
    assert!(!layout.journal_path().exists());
    drop(reader);
    fs::remove_dir_all(root).unwrap();
}
