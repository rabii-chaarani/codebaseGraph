# S3 FD and lookup successor — focused review and fix verification

**One confirmed P2 was found in snapshot 174 and is independently verified as fixed in the supplied successor. No confirmed P0–P3 defect remains in the reviewed fixed delta.** The FD facts, strict span comparator and lookup successor may proceed to central integration. Accepted snapshot 164 was used as the baseline and was not re-reviewed.

Reviewer: **GPT-6.1 Sol / Max**, same independent S3 review session, separate from the author. Applied the previously loaded adversarial-review-engineer skill. Review and probes were isolated. No author/shared source, tests, Git, model, wiki or tracking state was changed. Shared Cargo remained reserved elsewhere and was never used by this focused review.

## Reviewed identities

Initial artifact: `/private/tmp/dc-s3-fd-lookup-174-035le222/repo`; independent copy: `/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/repo`.

- Source manifest SHA-256: `11b2686fa394d6cc0312f5c8bdca0dc880ca7e5453068a9586429d49b3c06b93`.
- Delta against accepted 164 SHA-256: `ef94f9c8a286bde963e8d1d5679c5b5a2436a1c111c7e55e3efd4122b7e37b89`.
- Original validation source SHA-256: `05a67051275122682a170ec2a9845e1d5d99c209cd8c2eafbd25a94bf2fa4384`.
- Author evidence-summary SHA-256: `a87ff3147ac669e88916790f435140eb83c86c66c69707459cbf4cbff14bb9f6`.

Fixed artifact: `/private/tmp/dc-s3-comparator-fix-vuy0i08d/repo`; independent copy: `/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/fixrepo`.

- Fixed manifest SHA-256: `17d5b95b1e6b70d4b2ddd416a0f3202e0f28ef44578f8e7843bff401bb53c326`.
- Fix delta SHA-256: `1f173df8553f0d6a956bc2108f6330d8693a58ee58c6b1d4bdd2070f080e3042`.
- Fixed validation source SHA-256: `e461687f2d67ca4328e974be95251b619823e969cc8e58daf56fd09d02e690df`.

All **429** initial inputs remain unchanged. All **429** fixed inputs match the supplied fixed manifest plus unchanged 174 inputs; only validation.rs changed between these snapshots. Relative to accepted 164, the other delta is the small test-only redundant-slice cleanup in maintenance_json.rs. No unfinished S2/S4 source was imported.

Memory was recalled for the new FD/span/lookup scope. Configured wiki bundle/search/get and explicit Scryer project `/private/tmp/codebasegraph-disk-cleanup-7t9af0a6/repo`, `chg-6vx5tj` / `node-eje4rb`, were consulted. The graph initially returned Busy, then the sequential retry completed with no new helper hit; indexed validator dependency context and the explicit frozen/Scryer mapping supplied source discovery. No unrelated project state was substituted. Existing revision-0.2 approval and the coordinator-confirmed strict span contract governed the review; no new user decision was needed.

## Resolved P2 — Differing prefixes bypassed complete string validation

Location in original 174: `src/storage/maintenance_validation.rs:337–342`, public compare_decoded_spans.

The standalone comparator accepts untyped spans and is required to validate complete UTF-8 strings and bounds before returning an ordering fact. It returned immediately on a first byte difference or shorter prefix. An invalid suffix therefore produced Ok(Less/Greater) instead of a validation error. This is a bounded facts-validation failure; the current delta provides no deletion/publication capability, so no destructive consequence is claimed.

Independent reproduction against the exact original module returned **Ok(Less)** for every pair below:

```rust
(b"\"a\xff\"",         b"\"b\"") // expected NonProducer
(b"\"a",               b"\"b\"") // expected InvalidSpan
(b"\"a\"trailing",     b"\"b\"") // expected InvalidSpan
(b"\"\"",              b"\"a\xff\"") // expected NonProducer
```

The supplied original tests rejected malformed strings only where comparisons had not already decided their ordering. They therefore did not defeat this counterexample. The coordinator confirmed complete-token validation is part of the approved strict contract, including when historical token provenance exists or source bytes can change.

Author remedy: retain the first lexicographic difference and continue decoding both complete spans before returning it. A common compare_complete helper now serves the public cross-source comparator and internal comparator. It preserves bounded scratch and propagates late errors. No file/identity authority was added.

Independent fix verification passed all original cases, reversed inputs, malformed escape/control/surrogate and invalid UTF-8 tails, and PermissionDenied errors occurring after byte 256 in either source. Valid shorter-prefix and differing-suffix orderings remained correct. The added author regression tests also passed in the exact frozen module. **Status: resolved for fixed source e461687f…**, subject to the ordinary central root/integration checks below.

## Other delta findings and checks

**BorrowedFileSource.** The constructor reserves its fixed Self/Metadata/scratch charge before calling metadata. It borrows an already-open handle without copying a path/payload or opening a file. Non-regular files return Schema; construction/error/drop releases its charge. read_at caps output to the captured length, rejects offsets beyond that length, retries Interrupted and preserves other error kinds. Cached length remains an observation; it proves no source identity or immutability.

The mutable File input borrow excludes ordinary reuse through that binding. The documented dedicated-handle and no-cursor-sharing-clones precondition remains necessary. On Unix, read_at preserves the cursor, verified natively with serial and concurrent positioned reads. On Windows, seek_read changes it to the end of the read, as documented by the [Windows FileExt API](https://doc.rust-lang.org/std/os/windows/fs/trait.FileExt.html); the code and tests describe that behavior. The [Unix API](https://doc.rust-lang.org/std/os/unix/fs/trait.FileExt.html) specifies the distinct unchanged-cursor behavior. Native Windows execution was not performed and no universal positioned-read cursor-preservation claim is made.

**Strict decoder.** Raw UTF-8 sequences are now validated in Decoded even without a prior tokenizer pass. The fixed comparison helper validates both complete inputs after ordering is decided. Bounds, escapes, surrogate handling, complete closing quotes and trailing span data remain checked. Reservations precede construction of both decoder scratch layouts; errors return to the initial account floor.

**Early-empty lookup.** Normal insertion places keys at the first empty probe slot; there is no per-slot deletion. Collision selection replaces arbitrary slots only after the table is full, and all keys in that path share the same full hash. A partially filled collision table retains first-empty insertion order. Consequently early-empty termination cannot skip a retained key in either path. put now always marks an insertion occupied; clear is the only emptying operation. Probe counters use checked arithmetic and report actual total lookup probes.

The previous capacity-sized miss-scan concern is removed in the executed modest normal case: 320 events caused 321 probes at capacity 16,384, with one pass. Independent normal/forced-collision differentials and dense metadata tests retained exact multiplicity, last-row-wins and orphan-key rejection. This establishes lookup work for that fixture, not universal throughput or default-ceiling large-file qualification.

## Executed evidence

Author 174 evidence was verified against preserved source/binary files: visible root compilation in 17.84 s with no test-build warnings; **83 passed, 485 skipped, retries 0**, from 568 total tests. Author JUnit SHA-256: `caf2b80f6a26f137a7b0cc4592d58e5c080b56ce35b495e1017075b3cb213eb8`. Preserved binary `codebase_graph-a2e107271f5ecb09` SHA-256: `d44615cca4e0a41fb586c43da72bfe2b6db00e107f2d8eab34b5b3abee302ef9`; dependency-file SHA-256: `8ea2ca542ca5c25ebe81fa759ae6dab134eef98ba989194946b623f7b41c175f`. These are author executions, not an independently rebuilt fixed root.

Independent execution used direct rustc **1.96.0** on Darwin arm64 and copied runtime dependencies whose fingerprints match the author 174 root unit. No shared Cargo or moving worktree source was used.

- Exact fixed validation module: **16 tests passed**, 17 other compiled-module tests filtered, including both new suffix-validation/late-I/O regressions. Compile and execution logs are retained. The support fixture uses verbatim frozen ManifestEntry/GraphPartition type and actual validator excerpts plus frozen row/hash modules; it is not a full repository link.
- Separate fixed-source probes: **24** strict suffix/error regressions; **23** FD checks; **65** valid cross-source comparison pairs; **654** raw-row normal/forced-collision differentials; **4** dense-metadata cases; sparse lookup 320 events / 321 probes. FD checks cover bounds/EOF, untouched output suffixes, native unchanged cursor, concurrent reads, low-memory-before-directory-validation, non-file rejection, write-only read error, and actual file-backed schema/checksum/join replay.
- Forced collision injection only adds a visibility accessor to a scratch replica of the otherwise verbatim fixed module; no algorithm is changed. The real frozen module also executes its own collision regressions in the 16-test run.
- Fixed source rustfmt check passed. Both direct builds completed without warnings. All initial/fixed source hashes were checked again afterward.

Independent fixed module-test binary SHA-256: `1056bec4890f9c140d1927868bceb792118c84dfa6a31f1c519e2512fb9a6e92`. Independent fixed probe binary SHA-256: `78684e9419bfab0195778a775f3702467388b6989b768875392f2e522856c401`.

## Limits and handoff

The fixed full root suite, full workspace, production warning-free build and combined S2/S4 integration have not run in this review because shared Cargo was reserved elsewhere. Central integration must run its required checks against this exact corrected source; author 174's 83-test result does not qualify the later fixed root. No native Windows/Linux, RSS/allocator-slack, compiler-stack measurement, universal throughput, actual producer publication, live cleanup or deployment qualification is claimed.

No origin, usable-backup or deletion capability exists in this delta. Preserve the approved later policy split: origin proof plus exact byte integrity, strict owned shape and current absence can support eligible GC; restoration additionally requires LoaderUsable. This review imposes no blanket loader-usability condition on all GC.

Reusable-knowledge assessment: the standalone strict-comparison tail rule is now directly covered by focused regression tests; the platform cursor distinction is explicit in the source/API documentation. No additional repository memory beyond these readily rediscovered facts was warranted, and no filler record was created.

Evidence directory: `/private/tmp/cleanup-v2-s3-fd-review-3vw48_es`. Machine-readable status: `verification.json`; artifact hashes: `review-artifact-sha256.json`.
