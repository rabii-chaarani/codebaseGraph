#![allow(dead_code)]
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/fixrepo/src/storage/maintenance_budget.rs"] mod maintenance_budget;
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/fixrepo/src/storage/maintenance_json.rs"] mod maintenance_json;
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/fixrepo/src/storage/maintenance_validation.rs"] mod maintenance_validation;
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/fixrepo/src/storage/maintenance_journal.rs"] mod maintenance_journal;
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/fixrepo/src/syntax_materializer/rows.rs"] mod syntax_materializer;
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/fixrepo/src/hash.rs"] mod hash;
mod protocol { use serde::{Deserialize,Serialize};use std::collections::BTreeMap;include!("probe/manifest_entry.rs"); }
mod partition_builder {use super::protocol::ManifestEntry;use super::syntax_materializer::{GraphNodeRow,GraphEdgeRow};use super::hash;use std::collections::BTreeMap;include!("probe/graph_partition.rs");}
