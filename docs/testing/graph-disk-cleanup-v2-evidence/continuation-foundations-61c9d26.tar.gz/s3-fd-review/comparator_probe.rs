#![allow(dead_code)]
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/repo/src/storage/maintenance_budget.rs"] mod maintenance_budget;
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/repo/src/storage/maintenance_json.rs"] mod maintenance_json;
#[path="/private/tmp/cleanup-v2-s3-fd-review-3vw48_es/repo/src/storage/maintenance_validation.rs"] mod maintenance_validation;
use maintenance_budget::CleanupMemory;use maintenance_validation::*;
fn main(){let memory=CleanupMemory::new(4096).unwrap();let cases:&[(&[u8],&[u8])]=&[(b"\"a\xff\"",b"\"b\""),(b"\"a",b"\"b\""),(b"\"a\"trailing",b"\"b\""),(b"\"\"",b"\"a\xff\"")];for (a,b) in cases{let result=compare_decoded_spans(*a,Span{start:0,end:a.len() as u64},*b,Span{start:0,end:b.len() as u64},&memory);println!("left={a:?} right={b:?} result={result:?}");}}
