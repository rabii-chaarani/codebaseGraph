
use std::{env, ffi::OsString, fs, process::{Command, exit}};
fn hex(value: &str) -> String {
    value.as_bytes().iter().map(|b| format!("{b:02x}")).collect()
}
fn main() {
    let mut args: Vec<OsString> = env::args_os().skip(1).collect();
    let compiler = args.remove(0);
    if args.iter().any(|arg| arg == "--crate-name") {
        args.push("-C".into());
        args.push("debug-assertions=on".into());
    }
    let mut evidence = format!("compiler={}\nmanifest={}\ncwd={}\n",
        hex(compiler.to_str().expect("non-UTF8 compiler path")),
        hex(&env::var("CARGO_MANIFEST_DIR").unwrap_or_default()),
        hex(env::current_dir().unwrap().to_str().expect("non-UTF8 cwd")));
    for arg in &args { evidence.push_str(&format!("arg={}\n", hex(arg.to_str().expect("non-UTF8 compiler arg")))); }
    let status = Command::new(&compiler).args(&args).status().expect("launch rustc");
    let code = status.code().unwrap_or(1);
    evidence.push_str(&format!("exit={code}\n"));
    let dir = env::var_os("CGRAPH_QUALIFICATION_EVENTS").expect("event directory");
    fs::write(std::path::PathBuf::from(dir).join(format!("{}.txt", std::process::id())), evidence).unwrap();
    exit(code);
}
