pub fn assertions_enabled() -> bool { cfg!(debug_assertions) }
