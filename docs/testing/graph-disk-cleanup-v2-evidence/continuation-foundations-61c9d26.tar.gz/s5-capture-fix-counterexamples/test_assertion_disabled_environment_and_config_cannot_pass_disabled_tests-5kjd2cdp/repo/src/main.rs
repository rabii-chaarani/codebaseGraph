fn main() { assert!(cfg!(debug_assertions)); }
