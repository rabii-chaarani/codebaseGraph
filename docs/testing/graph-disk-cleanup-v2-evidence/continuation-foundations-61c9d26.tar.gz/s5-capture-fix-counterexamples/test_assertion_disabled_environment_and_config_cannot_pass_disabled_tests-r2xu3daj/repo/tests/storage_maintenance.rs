#[test]
fn health_preserves_legacy_fields_and_marks_unobserved_maintenance_unknown() { assert!(!cfg!(debug_assertions)); assert!(codebase_graph::assertions_enabled()); assert!(std::process::Command::new(env!("CARGO_BIN_EXE_codebase-graph")).status().unwrap().success()); }
#[test]
fn nonboolean_quiescence_confirmation_is_rejected_before_repository_effects() { assert!(!cfg!(debug_assertions)); assert!(codebase_graph::assertions_enabled()); assert!(std::process::Command::new(env!("CARGO_BIN_EXE_codebase-graph")).status().unwrap().success()); }
#[test]
fn repeated_health_entries_preserve_source_and_foreign_sentinels() { assert!(!cfg!(debug_assertions)); assert!(codebase_graph::assertions_enabled()); assert!(std::process::Command::new(env!("CARGO_BIN_EXE_codebase-graph")).status().unwrap().success()); }
