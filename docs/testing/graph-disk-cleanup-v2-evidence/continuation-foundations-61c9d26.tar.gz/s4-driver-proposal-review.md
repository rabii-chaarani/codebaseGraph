# DC-S4 advisory scheduler proposal review

Recommendation: proceed with the independent driver/coalescing/cancellation/join foundation after the shared budget foundation is independently accepted and the coordinator records the interface conditions below in Scryer. Full storage/API/refresh wiring remains gated. No new product decision is needed.

Fresh read-only reviewer: GPT-6.1 Sol / Max, 2026-10-21. Applied adversarial-proposal-review-engineer. Exact input /private/tmp/dc-s4-advisory-scheduler-proposal-20261021.md, independently verified SHA-256 d039e14d0e94c36be7f67d078b28a59910e3ab29d9d44419edb226ef2bc2524b. Source baseline is 88a369f / last code077, with concurrent storage-wrapper/budget edits outside this assessment. Explicit-project Scryer node-hxxbg1 / resp-76md43 and approved revision0.2 remain governing intent.

## Cleared commitment and boundaries

Clear one unique MaintenanceRuntime owning one dedicated joined maintenance thread, a bounded cloneable control/snapshot Handle, fake-clock coalescing/cooldown, stop/rebind generations, panic/failure publication, and a callback-driven test driver. Use the accepted shared CleanupMemory and MutationGrant API; do not introduce another budget or storage authority type. Construct the controller/driver inside the spawned closure, so it need not be Sync or be unsafely forced Send. PreparedWork need not cross a channel. Existing S2 Send-work tests may remain; S4 does not need an unsafe workaround.

The dedicated thread is a supported improvement over running advisory preparation on the sole request executor. Current coordinator.rs:830–848 calls execution serially until completion; releasing an execution permit would not make a synchronous preparation callback on that same worker concurrent. The separate thread preserves actual request-worker progress.

The foundation may exercise the real dispatcher with an injected fake driver and fixture-owned barriers. It must not wire unfinished S3 collection, mint receipts, restore backups, detach workspaces, classify real Direct retirement, split real recovery errors or claim full runtime acceptance. Shared-budget acceptance and explicit one-writer source ownership are starting conditions, not implied by the reported66 tests.

## S4-01 — Define admission's stop/rebind linearization point

Type: material private-interface condition for the driver.

Checking cancellation only before constructing a grant leaves a race before permit/storage admission. After atomic dispatcher permit acquisition, check stop, desired target generation and the exact work binding under the short mailbox lock; claim/mark the admitted attempt and transfer its bound confirmation there. Release that lock before any S2 call or filesystem operation. A stop/rebind that wins this gate causes no S2 admission or effects; an attempt that already won is the existing admitted mutation and may finish/unwind recoverably. Do not hold the mailbox during storage admission.

Use S2's current callback-only try_with_prepared_mutation / sealed-transition boundary, not the superseded begin_prepared_mutation Ready-returning wording in the S4 artifact. Start the SAME MutationGrant before dispatcher acquisition. Budget expiration or denied commit gate releases the actual permit without storage effects.

Verify barriers before permit, after permit/before gate and after admitted mutation, racing stop/rebind each way. No old-target operation can be relabeled new; no new storage admission follows a winning stop. Every busy/stale/error/panic path releases owned authority and retains caller-owned writer ownership.

## S4-02 — Keep large destruction outside the real permit on every exit

Type: material private-interface gap in the proposed consuming advance_prepared(work, grant) boundary.

An outer dispatcher permit remains live while an inner function consuming Work destroys it on Err or unwind. Merely dropping the permit after that function returns cannot satisfy the stated no-permit disposal contract. This is a concrete ownership gap, not an observed implemented defect.

Keep any bulk PreparedWork/advisory residue owner outside the permitted callback. Strip/drop large input buffers before admission, then pass only an explicitly bounded mutation frame or a borrow into the callback. Return only compact outcomes or nonauthoritative follow-up descriptors. S2-consumed preparation must likewise contain only bounded fixed/projection state, with no slow unbounded Drop. Construct and destroy real storage authority on the same mutation thread. Memory-object disposal cannot perform filesystem writes/unlinks; those need a new grant and actual admission.

Verify deliberately blocked Drop/disposal after success, denied admission, error and panic. Real query/writer requests must progress while that destruction is paused, and the dispatcher must remain busy only while actual mutation is admitted. The driver/controller must stay outside any inner consuming scope that could drop it before permit RAII runs during unwinding.

## S4-03 — Make runtime lifetime and accounting ownership explicit

Type: material private-interface condition for the driver; no second budget.

Prefer a non-Clone Runtime with Option<JoinHandle>, owned only by the coordinator/local scope. The worker captures the mailbox/account/admission handles, never Runtime, CoordinatorOwner, ApiCore, CodebaseGraphApi or Arc<RefreshState>. Handle owns mailbox/control only. This excludes a Runtime -> thread -> Runtime cycle and makes self-join structurally unavailable. Take a join handle out before waiting; no lock is held across join.

Create or pass ONE Runtime-lifetime CleanupMemory account before allocating mailbox, target, cached summaries or spawning the driver. Do not create a fresh account per attempt while prior summary/mailbox allocations survive. Preserve it through rebind, cancellation, results and disposal. A memory-ceiling reconfiguration must drain/cancel old-generation retained work before starting a replacement account/limit; it cannot silently leave two independently capped jobs alive.

The at-most-current-and-next binding claim misses the transient replaced pending binding while it is being dropped outside the mutex. Reserve incoming replacement while current and old pending remain charged, or use an equivalent bounded ownership transfer. Count the real peak; never release a reservation while the corresponding old data still exists. Reserve fixed runtime/thread scratch and bounded summary/diagnostic capacity before allocation.

snapshot(now) must not silently allocate a new uncharged Vec/String DTO. A cheap Arc to an accounted compact snapshot, or a fully fixed-copy snapshot, is suitable for the foundation; actual protocol DTO conversion is a later explicit accounting boundary. Publish/replace old target/summary objects under short locks and destroy displaced objects afterward. ResourceLimit/worker-start failure returns a typed bounded outcome and leaks no thread/account; later production wiring must keep otherwise committed graph operations available.

## S4-04 — Fix coalescing, confirmation and freshness semantics in the state machine

Type: improvement required to make the foundation's behavior testable.

Take pending bits/sequence for an attempt at its start. Requests arriving during that attempt remain pending; completion must not clear them. Repeated enqueues OR bits without moving next_due later, otherwise continuous health requests can postpone maintenance forever. Test a sustained request stream beyond60 seconds, not only a burst. Retain the approved cooldown after idle/pending/busy/error/continuation outcomes and avoid an immediate retry loop.

Only a changed logical/physical target binding increments the rebind generation; re-enqueuing the same binding must not cancel every preparation. Work, cached observations and confirmation carry their observed binding generation. A snapshot while rebind is pending must mark the old observation stale/unbound rather than publish old bytes/reasons as current new-target evidence. Requests and phase changes do not refresh observation timestamps.

Choose a finite confirmation state table in the driver contract: unbound true is rejected/discarded; exact bound demand is taken at the admission gate; busy/preparation failure, failed admission, stale target, panic, cancellation and stop each have a named retain-same-binding-or-discard outcome. No false request creates/widens confirmation. In-flight plus newly pending true demands are both charged and must not become a sticky options flag. Any retained retry demand remains bound to the SAME exact incarnation and is revalidated by S3. S3's durable consumed record, not a scheduler bool, establishes actual consumption.

Tests cover default false, duplicate/coalesced true, false after true, rebind/cancel/stop, admission denial, failed worker and a true demand arriving while another is in flight. Worker panic marks driver liveness failed, so later request returns Failed rather than requested=true; cached prior observations remain correctly dated.

## S4-05 — Full runtime shutdown needs a concrete refresh lifetime handoff

Type: decision-critical integration prerequisite; does not block the independent driver.

Current start_refresh_service (refresh.rs:2186–2211) discards its JoinHandle. refresh_task_should_stop (:2385–2387) uses Arc::strong_count(state)==1, while ApiCore stores Arc<RefreshState> (core.rs:68–71) and coordinator worker closures retain ApiCore clones. Joining refresh before dropping all those owners cannot use the stop rule unchanged.

Before production lifecycle integration, select explicit cancellation plus an owned join handle, or a proved order releasing every owner clone before join. Keep the maintenance Handle free of ApiCore/RefreshState, and do not retain refresh through a callback cycle. Preserve existing refresh supervision/retry semantics while adding only the required ownership/completion hooks.

Current CoordinatorOwner::Drop/stop_and_drain (coordinator.rs:94–124) and drain_owned_operation (:628–636) join while their thread/monitor mutex guards are live. Take handles out, unlock, then join in the new integration. Existing route replacement already drops old_owner outside route locks (:462–486); preserve that safeguard. Test startup failure, executor-spawn failure, maintenance panic, configuration rebind, uninstall and ordinary shutdown with actual producer/resource release before aggregate drain is reported.

Completion hooks need an explicit private dispatch-start/completion outcome: post-return runtime/read/producer handles must be gone, and the worker must release its actual execution slot before it emits success/failure/cancel/noop maintenance completion. Early pre-dispatch validation is not producer completion; caller timeout is not operation completion. Do not infer genuine refresh completion from health polling.

Keep mixed Managed transaction recovery errors primary until storage supplies the typed transaction-versus-janitor handoff. Optional maintenance startup/reporting failures must not block otherwise validated committed reads. Exact Direct retirement/rebuild behavior and generated-path refresh filtering stay dependent on S2/S3 contracts and real integration evidence.

## Verification and limits

The independent foundation should prove one dedicated live thread, no overlap, monotonic cooldown and non-sliding due time, bounded accounting across mailbox/rebind/snapshots, denied future admission after stop/rebind, released permit before paused disposal, no join under locks, no Arc ownership cycle, truthful failed/stopped request disposition, and completed join after cancellation barriers release.

Full runtime still needs real MCP query/writer progress during paused preparation/disposal, actual storage callback integration, all producer completion hooks, typed recovery behavior, confirmation consumption, transient multi-process convergence and native qualification. A fake driver does not establish those outcomes.

Procedure: renewed repository memory recall; semantic graph search/context before source reads; explicit-checkout Scryer orientation. Inspected actual coordinator, core, facade and refresh lifetime paths at graph/Scryer-discovered files. No Cargo, tests, probes, source/wiki/Scryer/Git mutation or live operations. No new memory candidate: this is proposed design, not a verified repository outcome.

