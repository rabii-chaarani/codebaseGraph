---
description: Immutable generation storage, recoverable run workspaces, artifact reuse, legacy policy, and the operator recovery runbook.
resource: repository-architecture
tags:
- architecture
- generations
- graph-storage
- recovery
- runbook
timestamp: 2026-10-15
title: Graph Storage Lifecycle and Recovery
type: architecture
---
# Graph Storage Lifecycle and Recovery

Graph storage format v2 prevents unbounded embedded-database growth by replacing in-place graph mutation with immutable generations. It also makes build cleanup recoverable: every mutation is represented by a journaled run workspace, and publication changes one atomic active-generation pointer.

## Managed layout

A configured `storage_root` owns all mutable graph state:

```text
storage_root/
  active.json
  generations/
    gen-<id>/
      database/
      search sidecar siblings
      manifest.json
      metadata.json
      READY
      lease.lock
  runs/
    run-<id>/
      journal.json
      lease.lock
      staging/
      candidate/
  artifacts/
    <content-addressed raw partitions>
  workers/
    worker-<build-id>-<pid>-<sequence>/
      request.json
      result.json
      stderr.log
      .lifecycle-<id>/
        lease
        launch.json
        ready.json
        proof.json
        writers.fifo (Unix)
        receipt.json
  phases/
    phase-<id>/
      request.json
      request.stderr
      .lifecycle-<id>/
  coordinator.lock
  coordinator.json
  refresh.lock
  worker.lock
  worker.json
  writer.lock
  state.lock
```

`active.json` is the only publication pointer. A generation is eligible for activation only after its database, manifest, metadata, and readiness marker are durable and its reopened read-only database passes schema, count, and artifact validation.

## Storage invariants

1. **Managed updates never mutate the active database.** Every build writes a fresh, self-contained candidate generation.
2. **Publication is atomic.** The publisher holds the exclusive writer lock for the mutation and the exclusive state lock while replacing and fsyncing `active.json`.
3. **Failure preserves the active graph.** The current generation is not modified, retired, or deleted before the candidate is validated and publication succeeds.
4. **Readers lease exactly one generation.** Resolving the active pointer uses the shared state lock; the read operation then holds a shared generation lease until all database access is complete.
5. **Retirement is lease-aware and has no time-based retention.** A superseded generation is deleted as soon as its final reader releases the lease. The last reader, publisher, and later runtime entries all retry retirement. Failure remains visible as `cleanup_pending`.
6. **Only one managed generation remains at idle.** With no readers and no cleanup error, the active generation is the only generation directory.
7. **Paths are confined.** Cleanup accepts only expected descendants of the managed root, rejects symlinks and traversal, and never follows links into user data.
8. **Direct paths remain transactional.** Explicit `--db` and `--manifest` targets use adjacent shadow files plus a checksummed recovery journal so the pair cannot remain half-published after a crash.
9. **MCP database ownership is singular.** One `coordinator.lock` holder owns the API core and Ladybug access; follower MCP processes route over authenticated loopback and never open graph databases.
10. **Worker ownership survives crashes.** The `worker.lock` holder persists version-2 containment state before releasing `START`. An independent guardian owns the full build tree and its lifetime lease. PIDs are diagnostic; persisted PIDs never authorize signalling. Cleanup and new writers require a terminal teardown receipt or verified empty containment.

These rules replace the stale-file write-intent heuristic and all in-place partition deletion or replacement. The compatibility `atomic_rebuild` request field remains accepted but does not re-enable in-place mutation.

## Refresh ownership

`refresh.lock` is independent from `writer.lock` and `state.lock`. Its nonblocking exclusive holder is the only process allowed to create a repository watcher. Followers do not materialize and retry election every second with up to 250 ms of deterministic jitter; operating-system lock release enables takeover without a persisted leader record. On acquisition, the new leader reconciles the active manifest before it begins watching.

Managed storage places the lock under `storage_root`. Direct storage derives a destination-scoped lock from the explicit database and manifest pair. Lock files reject symlinks. Refresh candidates still acquire the ordinary writer lock for the complete mutation, and an unchanged refresh may close its write session without publishing after comparing against the latest active manifest.

## Coordinator and worker recovery

`coordinator.lock` is scoped exactly like the repository runtime: beneath managed `storage_root`, or derived deterministically from a Direct database/manifest pair. The owner publishes a loopback-only endpoint, random capability token, protocol version, and PID in `coordinator.json`; Unix permissions are restricted to mode 0600. A successor removes the state file only when its token still matches, so stale shutdown cannot erase a newer owner.

`worker.lock` is independent from coordinator, refresh, writer, and state locks. A small guardian establishes containment and owner-death monitoring before acknowledging readiness. The coordinator atomically persists the version-2 descriptor, then sends authenticated `START`. A random per-build capability protects the loopback control endpoint; capability-bearing files are private at creation (Unix mode 0600, Windows owner-only ACLs). A separate lifetime lease protects startup workspaces even before `worker.json` exists.

Cancellation, memory failure, owner disconnect, startup failure, and unexpected worker exit use the same teardown path. Each attempt is bounded to five seconds. Verified abandoned guardians receive authenticated cancellation. Unknown containment preserves metadata, candidate files, and pending refresh work, and reports retryable `containment_unknown` instead of admitting another writer. Legacy PID-only records are retired automatically under exclusive worker ownership without signalling or waiting on their PIDs.

On Unix, the guardian occupies its own session and retains the worker group leader unreaped with `waitid(WNOWAIT)` through teardown. Every native worker, loader, and timing wrapper inherits a writer to a private FIFO. The guardian kills the anchored group until FIFO EOF proves all writers have exited, then reaps the leader. Recovery opens the existing FIFO without recreating it and verifies device/inode identity; missing or mismatched proof, access failure, and `EAGAIN` remain unknown.

On Windows, a private stable-Rust `CreateProcessW` adapter assigns the process to an unpredictable owner-protected job at creation through `JOB_LIST`. Restricted handle inheritance excludes the job handle; breakaway is disabled and `KILL_ON_JOB_CLOSE` covers guardian loss. The process stays suspended until `START`. Teardown requires `ActiveProcesses == 0` before resources can be retired.

Standalone isolated database phases use the same guardian. Their requests and containment evidence live in a stable per-storage or per-Direct-destination `phases` registry outside disposable candidates and runs. Nested phases inherit their build's containment. Writer admission, publication replay, promotion, abort, and orphan cleanup consult the registry. Unknown containment blocks writes and destructive cleanup; managed readers keep the previous active generation. Direct readers may retain the prior bundle when there is no interrupted-publication journal; ambiguous replay remains blocked. Run workspaces persist their cleanup-barrier path so crash recovery respects the same constraint.

The public CLI/MCP contracts, graph formats, and memory settings are unchanged. Version-1 internal helper roles fail before database work with an actionable daemon-restart error. New guarantees require the updated daemon and helpers together.

If a worker publishes successfully but dies before writing its result, the supervisor compares the publication marker and active validated manifest, then synthesizes the completed response. A killed or failed worker never causes an incomplete candidate to become active.

## Run workspace lifecycle

Each build owns a `RunWorkspace` whose durable journal advances through:

`created -> staged -> candidate_ready -> publishing -> published`

A failure records `failed`; a cleanup failure records `cleanup_pending`.

Normal completion calls explicit `finish`; error paths call explicit `abort`. Both report cleanup errors without masking the primary build error. `Drop` is only a best-effort fallback.

On later runtime entry, the janitor takes the run lease before acting. It removes unlocked pre-publication and published workspaces, completes or rolls back an interrupted publication deterministically from the journal, and leaves locked live runs untouched. Repeated recovery and cleanup are idempotent.

## Direct publication replay

The Direct journal’s `sidecar_sha256` membership defines the sidecars in the new bundle. During Prepared replay, an expected sidecar with no remaining candidate may already have been renamed into place: retain that destination and require its recorded checksum before advancing the journal. Remove obsolete destinations only for sidecars omitted from the journal; never publish an unlisted candidate. A missing or corrupt expected destination keeps recovery failed and the journal available, without deleting valid already-promoted sidecars.

Recovery resumes the recorded publication under the existing exclusive writer lock. Before Prepared is durable, abandonment preserves the prior bundle; after Prepared is durable, recovery completes the new database/sidecar/manifest bundle. Individual shadow and candidate rename boundaries, phase checkpoints, and repeated recovery interruptions are regression-tested. Destination spelling remains part of the journal and lock identity. This does not change the journal format or promise stronger power-loss durability than the existing filesystem sync behavior.

## Durable partition artifacts

Raw source partitions are stored content-addressably. An artifact key includes repository identity, relative path, content hash, language, parser version, profile version, ontology version, and artifact schema version.

A materialization run revalidates source hashes, reuses valid unchanged artifacts, rebuilds missing or corrupt entries, and reloads each partition only for its current bounded pass. Compact manifest v5 retains path, content hash, language, partition ID, artifact key, row counts, and timestamp; readable v4 generations receive one bounded full rebuild on their next write. Artifact garbage collection retains entries referenced by the active manifest or a live run and removes everything else.

Artifact reuse reduces parsing work. It does not make graph database files incremental or mutable.

## Legacy storage policy

Schema-v1 installations remain readable for search, context, query, and health. Build, watch, refresh, and install return the typed `legacy_storage_requires_reinstall` error.

Reinstall renames the legacy state without copying it, builds and validates storage v2, and restores the legacy state if failure occurs before activation. After successful activation and validation it deletes the renamed legacy state immediately. There is no rollback grace period and no automatic migration during ordinary mutation commands.

## Health and operator signals

Health and materialization output expose:

- storage format and writability;
- active generation;
- reused and rebuilt artifact counts;
- pending run count and cleanup status;
- physical and logical database sizes;
- parsing, staging, search, and database phase high-water marks plus spill bytes;
- configured Rust and worker RSS limits;
- refresh role, coordinator/leader PID, active worker PID, pending state, coalesced and overflow counts, deduplicated refreshes, and the latest no-op reason.

A healthy idle managed store reports format v2, one active generation, zero run directories, and `cleanup_pending = false`.

## Recovery runbook

1. Confirm the reported coordinator PID, refresh role `leader`, and worker PID. Quiesce the repository watcher and long-lived readers before reinstalling or investigating retirement; do not delete coordinator or worker state while their locks are held.
2. Run health and record the storage format, active generation, pending runs, cleanup status, and physical/logical sizes.
3. If a coordinator or worker died, allow a follower to acquire the released control locks. It authenticates an abandoned guardian and terminates its containment, or proves the leftover containment empty, before retiring worker evidence. PID-only legacy records are retired without signalling their recorded PID. If a v2 run or publication was interrupted, health or another repository operation lets the janitor acquire unlocked run journals and recover them before normal work continues.
4. If `cleanup_pending` or `containment_unknown` remains, preserve worker, phase, and run evidence. A later automatic retry can retire verified empty containment. Missing authority with surviving or unverifiable processes fails closed; do not delete its proof or signal a PID copied from metadata. Run and retired-generation leases still govern ordinary cleanup.
5. For a schema-v1 repository, use explicit reinstall. Verify the new active generation and graph queries before restarting the watcher; successful reinstall deletes the renamed legacy state immediately.
6. Confirm the idle store contains exactly one generation and no run directories. On Unix, also confirm no deleted legacy database file remains open.
7. Restart the MCP watcher against the v2 configuration and repeat health plus search/context/query smoke tests.

If cleanup rejects a path or symlink, preserve the reported path and investigate the managed root rather than bypassing confinement. This design intentionally does not depend on a Ladybug fork, truncate patch, or dependency upgrade.

## Verification expectations

Native lifecycle regressions cover legacy metadata naming an unrelated live PID, writer-lock contention, authenticated orphan recovery, paused loaders and workers, owner termination around readiness and `START`, macOS timing wrappers, measured RSS failure, private capability files, and bounded control input. Lost guardian authority preserves candidates and blocks writers until emptiness is proven. Interrupted work keeps the active generation unchanged and a later automatic retry succeeds without another source edit.

Lifecycle regressions cover failure at parsing, staging, search construction, isolated database loading, database validation, and publication; abandoned-run recovery; symlink rejection; lease-delayed retirement; stale-base rejection; schema-v1 write rejection; reinstall restoration and immediate legacy deletion; direct-mode paired recovery; artifact invalidation and corruption; deterministic clean-rebuild equivalence; and artifact garbage collection.

The churn acceptance test performs 10–20 updates. At idle it must leave one managed generation and no run directories, preserve graph results, and keep final physical database size within the greater of 10% or 8 MiB above a clean-control rebuild.

Related: [Graph Runtime](./graph-runtime.md), [Materialization Pipeline](./materialization-pipeline.md), [Public Operations and Runtime Paths](./operation-paths.md), and [Architecture Invariants](./invariants.md).