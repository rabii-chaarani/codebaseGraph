use crate::error::NativeError;
use crate::storage::atomic::{create_new_file, sync_dir, write_json_atomically};
use crate::storage::containment::{collect_registry, ensure_registry_empty, probe_registry};
use crate::storage::layout::{
    direct_bundle_paths, managed_generation_id, validate_generation_id, CandidateGenerationLayout,
    GenerationPaths, ManagedLayout,
};
use crate::storage::locks::{
    open_locked, try_open_locked, try_open_locked_in_existing_parent, LockMode, LockedFile,
    StateLease, WriterLease,
};
use crate::storage::run_workspace::{
    remove_run_root_confined, RunJournal, RunPhase, RunWorkspace, RunWorkspaceRecovery,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::fs;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};

const MANAGED_SCHEMA_VERSION: u64 = 2;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct ActiveGeneration {
    #[serde(default = "managed_schema_version")]
    pub schema_version: u64,
    pub generation_id: String,
    #[serde(default)]
    pub published_at: String,
    #[serde(default)]
    pub activated_at_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct GenerationMetadata {
    #[serde(default = "managed_schema_version")]
    pub schema_version: u64,
    pub generation_id: String,
    #[serde(default)]
    pub created_at_ms: u64,
    #[serde(default)]
    pub published_at_ms: u64,
    #[serde(default)]
    pub base_generation_id: Option<String>,
    #[serde(default)]
    pub logical_size_bytes: u64,
    #[serde(default)]
    pub physical_size_bytes: u64,
    #[serde(default)]
    pub node_count: usize,
    #[serde(default)]
    pub edge_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct GenerationRetirement {
    #[serde(default = "managed_schema_version")]
    pub schema_version: u64,
    pub retired_at_ms: u64,
}

#[derive(Debug, Deserialize)]
struct SearchManifestEnvelope {
    #[serde(default)]
    search_backend: Option<SearchBackendEnvelope>,
}

#[derive(Debug, Deserialize)]
struct SearchBackendEnvelope {
    #[serde(default)]
    files: BTreeMap<String, String>,
}

#[derive(Debug)]
pub(crate) struct GenerationLease {
    lock: Option<LockedFile>,
    store: ManagedStore,
    generation_id: String,
}

impl GenerationLease {
    fn new(lock: LockedFile, store: ManagedStore, generation_id: String) -> Self {
        Self {
            lock: Some(lock),
            store,
            generation_id,
        }
    }
}

impl Drop for GenerationLease {
    fn drop(&mut self) {
        drop(self.lock.take());
        if self.store.layout.storage_root().exists() {
            self.store
                .best_effort_cleanup_generation(&self.generation_id);
        }
    }
}

#[derive(Debug, Clone)]
pub(crate) enum StorageMode {
    Direct,
    LegacyManagedV1,
    ManagedV2,
}

#[derive(Debug, Clone, Default)]
pub(crate) struct ManagedCleanupReport {
    pub run_recovery: RunWorkspaceRecovery,
    pub retired_deleted: usize,
    pub retired_pending: usize,
    pub retired_generations_deleted: usize,
    pub retired_generations_pending: usize,
}

#[derive(Debug)]
pub(crate) struct ManagedReadSnapshot {
    pub generation_id: String,
    pub db_path: PathBuf,
    pub manifest_path: PathBuf,
    pub published_at_ms: u64,
    _lease: Arc<GenerationLease>,
    pub logical_size_bytes: u64,
    pub physical_size_bytes: u64,
}

#[derive(Debug, Clone)]
pub(crate) struct ManagedCandidate {
    pub generation_id: String,
    pub paths: GenerationPaths,
}

impl ManagedCandidate {
    pub(crate) fn paths(&self) -> &GenerationPaths {
        &self.paths
    }
}

#[derive(Debug)]
pub(crate) struct ManagedWriteSession {
    store: ManagedStore,
    workspace: Option<RunWorkspace>,
    writer_lease: Option<WriterLease>,
    pub candidate: ManagedCandidate,
    pub base_generation: Option<ActiveGeneration>,
    ready: bool,
    finished: bool,
}

impl ManagedWriteSession {
    pub(crate) fn writer_lease(&self) -> Result<&WriterLease, NativeError> {
        self.writer_lease
            .as_ref()
            .ok_or_else(|| NativeError::InvalidInput("write session is finished".into()))
    }

    pub(crate) fn phase_workspace_root(&self) -> PathBuf {
        self.store.layout.phase_workspace_root()
    }
    pub(crate) fn staging_root(&self) -> Option<PathBuf> {
        self.workspace.as_ref().map(RunWorkspace::staging_root)
    }

    pub(crate) fn candidate_db_path(&self) -> PathBuf {
        self.candidate.paths.db_path()
    }

    pub(crate) fn candidate_manifest_path(&self) -> PathBuf {
        self.candidate.paths.manifest_path()
    }

    pub(crate) fn base_manifest_path(&self) -> Result<Option<PathBuf>, NativeError> {
        self.base_generation
            .as_ref()
            .map(|generation| {
                self.store
                    .layout
                    .generation(&generation.generation_id)
                    .map(|paths| paths.manifest_path())
            })
            .transpose()
    }

    pub(crate) fn mark_ready_with_stats<S: GenerationStats>(
        &mut self,
        graph_summary: &S,
    ) -> Result<(), NativeError> {
        self.store.prepare_candidate(
            self.workspace.as_ref().ok_or_else(|| {
                NativeError::InvalidInput("managed write session already finished".to_string())
            })?,
            &self.candidate,
            graph_summary,
        )?;
        self.ready = true;
        Ok(())
    }

    pub(crate) fn abort(mut self, error: Option<String>) -> Result<(), NativeError> {
        self.finished = true;
        let result = match self.workspace.take() {
            Some(workspace) => workspace.abort(error),
            None => Ok(()),
        };
        drop(self.writer_lease.take());
        result
    }

    pub(crate) fn publish_with_stats<S: GenerationStats>(
        &mut self,
        graph_summary: &S,
    ) -> Result<String, NativeError> {
        if !self.ready {
            if let Err(error) = self.mark_ready_with_stats(graph_summary) {
                return Err(self.abort_after_error(error));
            }
        }
        let workspace = self.take_workspace()?;
        if let Err(error) = workspace.mark_phase(RunPhase::Publishing, None, None) {
            self.finished = true;
            let error = abort_workspace_after_error(workspace, error);
            drop(self.writer_lease.take());
            return Err(error);
        }
        match self
            .store
            .publish_candidate_inner(&workspace, &self.candidate)
        {
            Ok(generation_id) => {
                finish_committed_workspace(workspace, &generation_id);
                Ok(generation_id)
            }
            Err(error) => {
                let generation_id = self.candidate.generation_id.clone();
                if self
                    .store
                    .publication_is_committed(&generation_id)
                    .unwrap_or(false)
                {
                    finish_committed_workspace(workspace, &generation_id);
                    return Ok(generation_id);
                }
                self.finished = true;
                let error = abort_workspace_after_error(workspace, error);
                drop(self.writer_lease.take());
                Err(error)
            }
        }
    }

    pub(crate) fn recover_and_gc(&self) -> Result<ManagedCleanupReport, NativeError> {
        if self.writer_lease.is_none() {
            return Err(NativeError::InvalidInput(
                "managed cleanup requires this session's writer lease".into(),
            ));
        }
        self.store.cleanup_with_owned_writer()
    }

    pub(crate) fn finish(mut self) {
        self.finished = true;
        drop(self.writer_lease.take());
        // A final old-generation reader may have released its lease while this
        // writer still held publication ownership. Retry once after releasing it.
        let _ = self.store.cleanup();
    }

    fn abort_after_error(&mut self, error: NativeError) -> NativeError {
        self.finished = true;
        let error = match self.workspace.take() {
            Some(workspace) => abort_workspace_after_error(workspace, error),
            None => error,
        };
        drop(self.writer_lease.take());
        error
    }

    fn take_workspace(&mut self) -> Result<RunWorkspace, NativeError> {
        self.workspace.take().ok_or_else(|| {
            NativeError::InvalidInput("managed write session has already been finished".to_string())
        })
    }
}

impl Drop for ManagedWriteSession {
    fn drop(&mut self) {
        if self.finished {
            return;
        }
        if let Some(workspace) = self.workspace.take() {
            let _ = workspace.abort(Some(
                "managed write session dropped without publish".to_string(),
            ));
        }
    }
}

#[derive(Debug, Clone)]
pub(crate) struct ManagedStore {
    layout: ManagedLayout,
}

#[derive(Debug)]
pub(crate) enum ManagedValidationError {
    MissingReady(PathBuf),
    StaleBaseGeneration {
        expected: Option<String>,
        found: Option<String>,
    },
}

impl std::fmt::Display for ManagedValidationError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::MissingReady(path) => {
                write!(
                    formatter,
                    "candidate generation is not ready: {}",
                    path.display()
                )
            }
            Self::StaleBaseGeneration { expected, found } => write!(
                formatter,
                "stale generation base; expected active {:?}, found {:?}",
                expected, found
            ),
        }
    }
}

pub(crate) trait GenerationStats {
    fn node_count(&self) -> usize;
    fn edge_count(&self) -> usize;
}

impl GenerationStats for crate::protocol::GraphSummary {
    fn node_count(&self) -> usize {
        self.node_count
    }

    fn edge_count(&self) -> usize {
        self.edge_count
    }
}

impl ManagedStore {
    pub(crate) fn new(layout: ManagedLayout) -> Self {
        Self { layout }
    }

    pub(crate) fn layout(&self) -> &ManagedLayout {
        &self.layout
    }

    pub(crate) fn ensure_layout(&self) -> Result<(), NativeError> {
        self.layout.ensure_roots()
    }

    pub(crate) fn begin_write(&self) -> Result<ManagedWriteSession, NativeError> {
        let fresh = super::layout::create_fresh_reference_root(self.layout.storage_root())?;
        self.ensure_layout()?;
        let mut writer_lease = self.open_writer_lock()?;
        let reference_domain =
            super::maintenance_ownership::ReferenceDomain::managed(&self.layout)?;
        if let Some(fresh) = &fresh {
            super::maintenance_ownership::initialize_fresh_reference_domain(
                &reference_domain,
                fresh,
                &writer_lease,
            )?;
        }
        // Legacy roots may acquire their first ordinary use lock here. Observe
        // the real scope again after that producer-only coordination step, so
        // upgraded run associations never retain a stale missing-lock stamp.
        let mut artifact_use = super::maintenance_ownership::ArtifactUseLease::acquire_shared(
            &self.layout.artifacts_root(),
        )?;
        let reference_domain =
            super::maintenance_ownership::ReferenceDomain::managed(&self.layout)?;
        artifact_use.bind_reference_domain(&reference_domain)?;
        writer_lease.retain(artifact_use.into_lock());
        ensure_registry_empty(&self.layout.phase_workspace_root())
            .map_err(NativeError::InvalidInput)?;
        collect_registry(&self.layout.phase_workspace_root()).map_err(NativeError::InvalidInput)?;
        let base_generation = self.read_active_with_shared_lock()?;
        let mut workspace = RunWorkspace::create_scoped(
            self.layout.runs_root(),
            &reference_domain,
            base_generation
                .as_ref()
                .map(|value| value.generation_id.clone()),
        )?;

        workspace.set_cleanup_barrier(self.layout.phase_workspace_root())?;
        let generation_id = managed_generation_id();
        let candidate_layout =
            CandidateGenerationLayout::new(workspace.candidate_root(), generation_id.clone());
        let paths = candidate_layout.generation_paths();
        paths.ensure_root()?;
        workspace.register_candidate(generation_id.clone())?;

        Ok(ManagedWriteSession {
            store: self.clone(),
            workspace: Some(workspace),
            writer_lease: Some(writer_lease),
            candidate: ManagedCandidate {
                generation_id,
                paths,
            },
            base_generation,
            ready: false,
            finished: false,
        })
    }

    pub(crate) fn open_read(&self) -> Result<ManagedReadSnapshot, NativeError> {
        self.resolve_active_read()?.ok_or_else(|| {
            NativeError::InvalidInput(
                "managed storage does not have an active generation".to_string(),
            )
        })
    }

    pub(crate) fn resolve_active_read(&self) -> Result<Option<ManagedReadSnapshot>, NativeError> {
        let _state_lease = self.open_state_lock(LockMode::Shared)?;
        let Some(active) = self.read_active_generation()? else {
            return Ok(None);
        };
        let generation = self.layout.generation(&active.generation_id)?;
        validate_ready_generation(&generation)?;
        let metadata = read_generation_metadata(&generation)?;
        let lock = open_locked(generation.lease_path(), LockMode::Shared)?;
        let lease = Arc::new(GenerationLease::new(
            lock,
            self.clone(),
            active.generation_id.clone(),
        ));
        Ok(Some(ManagedReadSnapshot {
            generation_id: active.generation_id,
            db_path: generation.db_path(),
            manifest_path: generation.manifest_path(),
            published_at_ms: metadata.published_at_ms,
            _lease: lease,
            logical_size_bytes: metadata.logical_size_bytes,
            physical_size_bytes: metadata.physical_size_bytes,
        }))
    }

    pub(crate) fn cleanup(&self) -> Result<ManagedCleanupReport, NativeError> {
        self.ensure_layout()?;
        // Cleanup is opportunistic for readers. Never replay or collect while
        // a writer or an unproven native phase still owns candidate files.
        let Some(_writer_lease) =
            try_open_locked(self.layout.writer_lock_path(), LockMode::Exclusive)?
        else {
            return self.pending_cleanup_report();
        };
        self.cleanup_with_owned_writer()
    }

    fn cleanup_with_owned_writer(&self) -> Result<ManagedCleanupReport, NativeError> {
        if !matches!(
            probe_registry(&self.layout.phase_workspace_root()),
            Ok(true)
        ) {
            return self.pending_cleanup_report();
        }
        if !self.has_reference_cleanup_work()? {
            return self.pending_cleanup_report();
        }
        // This maintenance is optional for an already committed reader. An
        // unverifiable invalidation control preserves residue, not an outage.
        let domain = match super::maintenance_ownership::ReferenceDomain::managed(&self.layout) {
            Ok(domain) => domain,
            Err(_) => return self.pending_cleanup_report(),
        };
        let _mutation =
            match super::maintenance_ownership::ReferenceMutation::try_begin_in_domain(&domain) {
                Ok(Some(mutation)) => mutation,
                Ok(None) | Err(_) => return self.pending_cleanup_report(),
            };
        let _state_lease = self.open_state_lock(LockMode::Exclusive)?;
        let mut report = ManagedCleanupReport::default();
        let mut active = self.read_active_generation()?;
        report.run_recovery = self.recover_runs_locked(&mut active)?;
        self.collect_retired_generations_locked(
            active.as_ref().map(|value| value.generation_id.as_str()),
            &mut report,
        )?;
        report.retired_generations_deleted = report.retired_deleted;
        report.retired_generations_pending = report.retired_pending;
        Ok(report)
    }

    fn has_reference_cleanup_work(&self) -> Result<bool, NativeError> {
        for entry in fs::read_dir(self.layout.runs_root())? {
            let entry = entry?;
            if entry.file_type()?.is_dir()
                && entry.file_name().to_string_lossy().starts_with("run-")
                && matches!(RunWorkspace::reference_domain(&entry.path()), Ok(Some(_)))
            {
                return Ok(true);
            }
        }
        let active = self
            .read_active_generation()?
            .map(|active| format!("gen-{}", active.generation_id));
        for entry in fs::read_dir(self.layout.generations_root())? {
            let entry = entry?;
            if !entry.file_type()?.is_dir() || active.as_deref() == entry.file_name().to_str() {
                continue;
            }
            if entry.path().join("retired.json").exists() || !entry.path().join("READY").exists() {
                return Ok(true);
            }
        }
        Ok(false)
    }

    fn pending_cleanup_report(&self) -> Result<ManagedCleanupReport, NativeError> {
        // This report is observational: never acquire another writer's locks,
        // replay journals, or remove retained work merely to report pending GC.
        let mut report = ManagedCleanupReport::default();
        report.run_recovery.skipped_locked =
            existing_directories_with_prefix(&self.layout.runs_root(), "run-")?.len();
        let active = match self.read_active_generation() {
            Ok(active) => active,
            Err(e) if is_not_found_error(&e) => None,
            Err(e) => return Err(e),
        };
        for generation in existing_directories_with_prefix(&self.layout.generations_root(), "gen-")?
        {
            if active.as_ref().is_some_and(|a| {
                generation
                    .file_name()
                    .is_some_and(|n| n == format!("gen-{}", a.generation_id).as_str())
            }) {
                continue;
            }
            match fs::symlink_metadata(generation.join("retired.json")) {
                Ok(metadata) if metadata.is_file() => report.retired_pending += 1,
                Ok(_) => {}
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                Err(e) => return Err(e.into()),
            }
        }
        report.retired_generations_pending = report.retired_pending;
        Ok(report)
    }

    pub(crate) fn read_active_generation(&self) -> Result<Option<ActiveGeneration>, NativeError> {
        let path = self.layout.active_pointer_path();
        if !path.exists() {
            return Ok(None);
        }
        let text = fs::read_to_string(path)?;
        let active: ActiveGeneration = serde_json::from_str(&text)?;
        if active.schema_version != MANAGED_SCHEMA_VERSION {
            return Err(NativeError::InvalidInput(format!(
                "active generation pointer has schema_version {}, expected {}",
                active.schema_version, MANAGED_SCHEMA_VERSION
            )));
        }
        validate_generation_id(&active.generation_id)?;
        Ok(Some(active))
    }

    pub(crate) fn prepare_candidate<S: GenerationStats>(
        &self,
        workspace: &RunWorkspace,
        candidate: &ManagedCandidate,
        graph_summary: &S,
    ) -> Result<(), NativeError> {
        ensure_registry_empty(&self.layout.phase_workspace_root())
            .map_err(NativeError::InvalidInput)?;
        validate_candidate_generation(&candidate.paths)?;
        write_generation_metadata_with_stats(
            &candidate.paths,
            workspace.journal()?.base_generation_id,
            graph_summary.node_count(),
            graph_summary.edge_count(),
        )?;
        let mut ready = create_new_file(&candidate.paths.ready_path())?;
        ready.write_all(b"prepared\n")?;
        ready.sync_all()?;
        sync_dir(candidate.paths.root())?;
        workspace.mark_candidate_ready()
    }

    fn publish_candidate_inner(
        &self,
        workspace: &RunWorkspace,
        candidate: &ManagedCandidate,
    ) -> Result<String, NativeError> {
        ensure_registry_empty(&self.layout.phase_workspace_root())
            .map_err(NativeError::InvalidInput)?;
        let _state_lease = self.open_state_lock(LockMode::Exclusive)?;
        let mut active = self.read_active_generation()?;
        self.finish_run_locked(workspace.root(), &workspace.journal()?, &mut active, false)?;
        Ok(candidate.generation_id.clone())
    }

    fn recover_runs_locked(
        &self,
        active: &mut Option<ActiveGeneration>,
    ) -> Result<RunWorkspaceRecovery, NativeError> {
        let runs_root = self.layout.runs_root();
        if !runs_root.exists() {
            return Ok(RunWorkspaceRecovery::default());
        }
        let mut report = RunWorkspaceRecovery::default();
        for entry in fs::read_dir(&runs_root)? {
            // A worker can finish and remove its run workspace after the
            // directory iterator yields an entry. Windows reports that
            // observation as ERROR_PATH_NOT_FOUND; only that race is benign.
            let entry = match entry {
                Ok(entry) => entry,
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
                Err(error) => return Err(error.into()),
            };
            let path = entry.path();
            let is_directory = match entry.file_type() {
                Ok(file_type) => file_type.is_dir(),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
                Err(error) => return Err(error.into()),
            };
            if !is_directory {
                continue;
            }
            let Some(name) = path.file_name().and_then(|value| value.to_str()) else {
                continue;
            };
            if !name.starts_with("run-") {
                continue;
            }

            // A cleanup reader must not recreate a workspace that disappeared
            // after read_dir observed it.
            let lease = match try_open_locked_in_existing_parent(
                path.join("lease.lock"),
                LockMode::Exclusive,
            ) {
                Ok(Some(lease)) => lease,
                Ok(None) => {
                    report.skipped_locked += 1;
                    continue;
                }
                Err(error) if is_not_found_error(&error) => continue,
                Err(error) => return Err(error),
            };
            let expected_domain =
                super::maintenance_ownership::ReferenceDomain::managed(&self.layout)?;
            if !matches!(RunWorkspace::reference_domain(&path), Ok(Some(domain)) if domain.same_scope(&expected_domain))
            {
                report.skipped_locked += 1;
                continue;
            }
            let journal = match read_run_journal_or_default(&path, name) {
                Ok(journal) => journal,
                Err(error) if is_not_found_error(&error) => {
                    drop(lease);
                    continue;
                }
                Err(error) => return Err(error),
            };
            let recovered = match journal.phase {
                RunPhase::Publishing | RunPhase::Published => {
                    self.finish_run_locked(&path, &journal, active, true)?;
                    report.publishing_recovered += 1;
                    true
                }
                _ => false,
            };
            drop(lease);
            if !recovered {
                remove_run_root_confined(&path, &runs_root)?;
                report.deleted += 1;
            }
        }
        Ok(report)
    }

    fn finish_run_locked(
        &self,
        run_root: &Path,
        journal: &RunJournal,
        active: &mut Option<ActiveGeneration>,
        cleanup_run_root: bool,
    ) -> Result<(), NativeError> {
        ensure_registry_empty(&self.layout.phase_workspace_root())
            .map_err(NativeError::InvalidInput)?;
        let Some(candidate_id) = journal.candidate_generation_id.as_ref() else {
            if cleanup_run_root {
                remove_run_root_confined(run_root, &self.layout.runs_root())?;
            }
            return Ok(());
        };
        validate_generation_id(candidate_id)?;
        if let Some(base_generation_id) = journal.base_generation_id.as_deref() {
            validate_generation_id(base_generation_id)?;
        }
        let staged =
            CandidateGenerationLayout::new(run_root.join("candidate"), candidate_id.clone())
                .generation_paths();
        let published = self.layout.generation(candidate_id)?;
        let active_id = active.as_ref().map(|value| value.generation_id.clone());
        let base_matches = active_id == journal.base_generation_id;
        let published_valid = is_ready_generation_valid(&published);
        let staged_valid = is_ready_generation_valid(&staged);

        if active_id.as_deref() == Some(candidate_id.as_str()) && published_valid {
            self.finalize_previous_retirement(journal.base_generation_id.as_deref())?;
            if cleanup_run_root {
                remove_run_root_confined(run_root, &self.layout.runs_root())?;
            }
            return Ok(());
        }

        if !base_matches {
            if published.root().exists() {
                write_json_atomically(
                    &published.retired_path(),
                    &GenerationRetirement {
                        schema_version: MANAGED_SCHEMA_VERSION,
                        retired_at_ms: unix_time_ms(),
                    },
                )?;
                self.retire_or_delete_generation_locked(
                    &published,
                    active.as_ref().map(|value| value.generation_id.as_str()),
                )?;
            }
            if cleanup_run_root {
                remove_run_root_confined(run_root, &self.layout.runs_root())?;
                return Ok(());
            }
            return Err(NativeError::InvalidInput(
                ManagedValidationError::StaleBaseGeneration {
                    expected: journal.base_generation_id.clone(),
                    found: active_id,
                }
                .to_string(),
            ));
        }

        if published_valid && base_matches {
            let activated = self.activate_published_generation_locked(
                &published,
                journal.base_generation_id.as_deref(),
            )?;
            *active = Some(activated);
            if cleanup_run_root {
                remove_run_root_confined(run_root, &self.layout.runs_root())?;
            }
            return Ok(());
        }

        if staged_valid && base_matches {
            self.promote_candidate_generation_locked(&staged, &published)?;
            let activated = self.activate_published_generation_locked(
                &published,
                journal.base_generation_id.as_deref(),
            )?;
            *active = Some(activated);
            if cleanup_run_root {
                remove_run_root_confined(run_root, &self.layout.runs_root())?;
            }
            return Ok(());
        }

        if published.root().exists() {
            self.retire_or_delete_generation_locked(
                &published,
                active.as_ref().map(|value| value.generation_id.as_str()),
            )?;
        }
        if cleanup_run_root {
            remove_run_root_confined(run_root, &self.layout.runs_root())?;
        }
        Ok(())
    }

    fn promote_candidate_generation_locked(
        &self,
        staged: &GenerationPaths,
        published: &GenerationPaths,
    ) -> Result<(), NativeError> {
        validate_ready_generation(staged)?;
        if published.root().exists() {
            return Err(NativeError::InvalidInput(format!(
                "generation destination already exists: {}",
                published.root().display()
            )));
        }
        if let Some(parent) = published.root().parent() {
            fs::create_dir_all(parent)?;
        }
        fs::rename(staged.root(), published.root())?;
        sync_parent_dir(published.root())?;
        Ok(())
    }

    fn activate_published_generation_locked(
        &self,
        published: &GenerationPaths,
        previous_active_id: Option<&str>,
    ) -> Result<ActiveGeneration, NativeError> {
        validate_ready_generation(published)?;
        let mut metadata = read_generation_metadata(published)?;
        let now_ms = unix_time_ms();
        metadata.published_at_ms = now_ms;
        write_json_atomically(&published.metadata_path(), &metadata)?;
        fs::write(published.ready_path(), format!("{now_ms}\n"))?;
        sync_dir(published.root())?;

        let active = ActiveGeneration {
            schema_version: MANAGED_SCHEMA_VERSION,
            generation_id: published.generation_id().to_string(),
            published_at: format!("unix:{now_ms}"),
            activated_at_ms: now_ms,
        };
        if let Err(error) = write_json_atomically(&self.layout.active_pointer_path(), &active) {
            let _ = write_json_atomically(
                &published.retired_path(),
                &GenerationRetirement {
                    schema_version: MANAGED_SCHEMA_VERSION,
                    retired_at_ms: unix_time_ms(),
                },
            );
            return Err(error);
        }
        sync_dir(self.layout.storage_root())?;
        self.finalize_previous_retirement(previous_active_id)?;
        Ok(active)
    }

    fn finalize_previous_retirement(
        &self,
        previous_active_id: Option<&str>,
    ) -> Result<(), NativeError> {
        if let Some(previous_id) = previous_active_id {
            let retired = self.layout.generation(previous_id)?;
            if retired.root().exists() {
                write_json_atomically(
                    &retired.retired_path(),
                    &GenerationRetirement {
                        schema_version: MANAGED_SCHEMA_VERSION,
                        retired_at_ms: unix_time_ms(),
                    },
                )?;
                sync_dir(retired.root())?;
            }
        }
        Ok(())
    }

    fn collect_retired_generations_locked(
        &self,
        active_id: Option<&str>,
        report: &mut ManagedCleanupReport,
    ) -> Result<(), NativeError> {
        let generations_root = self.layout.generations_root();
        if !generations_root.exists() {
            return Ok(());
        }
        for entry in fs::read_dir(generations_root)? {
            let entry = entry?;
            if !entry.file_type()?.is_dir() {
                continue;
            }
            let path = entry.path();
            let Some(name) = path.file_name().and_then(|value| value.to_str()) else {
                continue;
            };
            if !name.starts_with("gen-") {
                continue;
            }
            let generation_id = name.trim_start_matches("gen-");
            if active_id == Some(generation_id) {
                continue;
            }
            let generation = self.layout.generation(generation_id)?;
            self.retire_or_delete_generation_locked(&generation, active_id)?;
            if generation.root().exists() {
                report.retired_pending += 1;
            } else {
                report.retired_deleted += 1;
            }
        }
        Ok(())
    }

    fn retire_or_delete_generation_locked(
        &self,
        generation: &GenerationPaths,
        active_id: Option<&str>,
    ) -> Result<(), NativeError> {
        if active_id == Some(generation.generation_id()) || !generation.root().exists() {
            return Ok(());
        }
        let should_collect =
            generation.retired_path().exists() || !generation.ready_path().exists();
        if !should_collect {
            return Ok(());
        }
        if let Some(lease) = try_open_locked(generation.lease_path(), LockMode::Exclusive)? {
            drop(lease);
            ensure_directory_without_symlinks(generation.root())?;
            let removal = remove_path_without_symlinks(generation.root());
            // Windows can report ACCESS_DENIED (5) or SHARING_VIOLATION (32)
            // while a reader still has a database file open after releasing
            // its generation lease. Retry collection on the next cleanup.
            #[cfg(windows)]
            if matches!(&removal, Err(NativeError::Io(io)) if matches!(io.raw_os_error(), Some(5 | 32)))
            {
                // The recursive delete may already have removed the
                // retirement marker. Restore it so a later cleanup will
                // retry even if the ready marker survived.
                write_json_atomically(
                    &generation.retired_path(),
                    &GenerationRetirement {
                        schema_version: MANAGED_SCHEMA_VERSION,
                        retired_at_ms: unix_time_ms(),
                    },
                )?;
                return Ok(());
            }
            removal?;
        }
        Ok(())
    }

    fn best_effort_cleanup_generation(&self, generation_id: &str) {
        let Ok(Some(_writer_lease)) =
            try_open_locked(self.layout.writer_lock_path(), LockMode::Exclusive)
        else {
            return;
        };
        if !matches!(
            probe_registry(&self.layout.phase_workspace_root()),
            Ok(true)
        ) {
            return;
        }
        if self
            .read_active_generation()
            .ok()
            .flatten()
            .as_ref()
            .is_some_and(|active| active.generation_id == generation_id)
        {
            return;
        }
        let Ok(domain) = super::maintenance_ownership::ReferenceDomain::managed(&self.layout)
        else {
            return;
        };
        let Ok(Some(_mutation)) =
            super::maintenance_ownership::ReferenceMutation::try_begin_in_domain(&domain)
        else {
            return;
        };
        let Ok(Some(_state_lock)) =
            try_open_locked(self.layout.state_lock_path(), LockMode::Exclusive)
        else {
            return;
        };
        let Ok(active) = self.read_active_generation() else {
            return;
        };
        if active.as_ref().map(|value| value.generation_id.as_str()) == Some(generation_id) {
            return;
        }
        let Ok(generation) = self.layout.generation(generation_id) else {
            return;
        };
        let _ = self.retire_or_delete_generation_locked(
            &generation,
            active.as_ref().map(|value| value.generation_id.as_str()),
        );
    }

    fn open_state_lock(&self, mode: LockMode) -> Result<StateLease, NativeError> {
        open_locked(self.layout.state_lock_path(), mode)
    }

    fn open_writer_lock(&self) -> Result<WriterLease, NativeError> {
        open_locked(self.layout.writer_lock_path(), LockMode::Exclusive)
    }

    fn read_active_with_shared_lock(&self) -> Result<Option<ActiveGeneration>, NativeError> {
        let _lease = self.open_state_lock(LockMode::Shared)?;
        self.read_active_generation()
    }

    fn publication_is_committed(&self, generation_id: &str) -> Result<bool, NativeError> {
        let _lease = self.open_state_lock(LockMode::Shared)?;
        let Some(active) = self.read_active_generation()? else {
            return Ok(false);
        };
        if active.generation_id != generation_id {
            return Ok(false);
        }
        validate_ready_generation(&self.layout.generation(generation_id)?)?;
        Ok(true)
    }
}

pub(crate) struct GraphStorage;

impl GraphStorage {
    pub(crate) fn managed(storage_root: impl Into<PathBuf>) -> ManagedStore {
        ManagedStore::new(ManagedLayout::new(storage_root))
    }
}

fn write_generation_metadata_with_stats(
    paths: &GenerationPaths,
    base_generation_id: Option<String>,
    node_count: usize,
    edge_count: usize,
) -> Result<GenerationMetadata, NativeError> {
    validate_candidate_generation(paths)?;
    let sizes = generation_sizes(paths)?;
    let metadata = GenerationMetadata {
        schema_version: MANAGED_SCHEMA_VERSION,
        generation_id: paths.generation_id().to_string(),
        created_at_ms: unix_time_ms(),
        published_at_ms: 0,
        base_generation_id,
        logical_size_bytes: sizes.logical_size_bytes,
        physical_size_bytes: sizes.physical_size_bytes,
        node_count,
        edge_count,
    };
    write_json_atomically(&paths.metadata_path(), &metadata)?;
    sync_dir(paths.root())?;
    Ok(metadata)
}

fn read_generation_metadata(paths: &GenerationPaths) -> Result<GenerationMetadata, NativeError> {
    let text = fs::read_to_string(paths.metadata_path())?;
    let metadata: GenerationMetadata = serde_json::from_str(&text)?;
    if metadata.schema_version != MANAGED_SCHEMA_VERSION
        || metadata.generation_id != paths.generation_id()
    {
        return Err(NativeError::InvalidInput(format!(
            "generation metadata does not match {}",
            paths.root().display()
        )));
    }
    Ok(metadata)
}

fn validate_candidate_generation(paths: &GenerationPaths) -> Result<(), NativeError> {
    ensure_regular_file(&paths.db_path())?;
    ensure_regular_file(&paths.manifest_path())?;
    ensure_directory_without_symlinks(paths.root())?;
    let manifest: SearchManifestEnvelope =
        serde_json::from_str(&fs::read_to_string(paths.manifest_path())?)?;
    if let Some(search_backend) = manifest.search_backend.as_ref() {
        validate_search_sidecar_checksums(&paths.db_path(), &search_backend.files)?;
    }
    Ok(())
}

fn validate_search_sidecar_checksums(
    db_path: &Path,
    expected: &BTreeMap<String, String>,
) -> Result<(), NativeError> {
    let search_suffixes = crate::storage::layout::DIRECT_DB_SIDECAR_SUFFIXES
        .iter()
        .copied()
        .filter(|suffix| suffix.starts_with("search."))
        .collect::<Vec<_>>();
    if expected.len() != search_suffixes.len()
        || search_suffixes
            .iter()
            .any(|suffix| !expected.contains_key(*suffix))
    {
        return Err(NativeError::InvalidInput(
            "managed search sidecar metadata has an incomplete file set".to_string(),
        ));
    }
    for suffix in search_suffixes {
        let path = PathBuf::from(format!("{}.{}", db_path.display(), suffix));
        ensure_regular_file(&path)?;
        if sha256_path(&path)? != expected[suffix] {
            return Err(NativeError::InvalidInput(format!(
                "managed search sidecar checksum mismatch: {}",
                path.display()
            )));
        }
    }
    Ok(())
}

fn sha256_path(path: &Path) -> Result<String, NativeError> {
    let mut file = fs::File::open(path)?;
    let mut digest = Sha256::new();
    let mut buffer = [0_u8; 64 * 1024];
    loop {
        let read = file.read(&mut buffer)?;
        if read == 0 {
            break;
        }
        digest.update(&buffer[..read]);
    }
    Ok(format!("{:x}", digest.finalize()))
}

fn validate_ready_generation(paths: &GenerationPaths) -> Result<(), NativeError> {
    validate_candidate_generation(paths)?;
    if !paths.ready_path().exists() {
        return Err(NativeError::InvalidInput(
            ManagedValidationError::MissingReady(paths.ready_path()).to_string(),
        ));
    }
    ensure_regular_file(&paths.ready_path())?;
    read_generation_metadata(paths)?;
    Ok(())
}

fn is_ready_generation_valid(paths: &GenerationPaths) -> bool {
    validate_ready_generation(paths).is_ok()
}

fn generation_sizes(paths: &GenerationPaths) -> Result<FileSizeSummary, NativeError> {
    let mut logical = 0_u64;
    let mut physical = 0_u64;
    for path in direct_bundle_paths(&paths.db_path()) {
        if path.exists() {
            let metadata = fs::metadata(&path)?;
            logical += metadata.len();
            physical += allocated_size(&metadata);
        }
    }
    let manifest = paths.manifest_path();
    if manifest.exists() {
        let metadata = fs::metadata(&manifest)?;
        logical += metadata.len();
        physical += allocated_size(&metadata);
    }
    Ok(FileSizeSummary {
        logical_size_bytes: logical,
        physical_size_bytes: physical,
    })
}

fn ensure_regular_file(path: &Path) -> Result<(), NativeError> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() {
        return Err(NativeError::InvalidInput(format!(
            "refusing to use symlinked file {}",
            path.display()
        )));
    }
    if metadata.is_file() {
        Ok(())
    } else {
        Err(NativeError::InvalidInput(format!(
            "expected regular file {}",
            path.display()
        )))
    }
}

fn ensure_directory_without_symlinks(path: &Path) -> Result<(), NativeError> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() {
        return Err(NativeError::InvalidInput(format!(
            "refusing to use symlinked path {}",
            path.display()
        )));
    }
    if metadata.is_dir() {
        for entry in fs::read_dir(path)? {
            let entry = entry?;
            let child = entry.path();
            let child_metadata = fs::symlink_metadata(&child)?;
            if child_metadata.file_type().is_symlink() {
                return Err(NativeError::InvalidInput(format!(
                    "refusing to use symlinked path {}",
                    child.display()
                )));
            }
            if child_metadata.is_dir() {
                ensure_directory_without_symlinks(&child)?;
            }
        }
    }
    Ok(())
}

fn remove_path_without_symlinks(path: &Path) -> Result<(), NativeError> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() {
        return Err(NativeError::InvalidInput(format!(
            "refusing to remove symlinked path {}",
            path.display()
        )));
    }
    if metadata.is_dir() {
        for entry in fs::read_dir(path)? {
            remove_path_without_symlinks(&entry?.path())?;
        }
        fs::remove_dir(path)?;
    } else {
        fs::remove_file(path)?;
    }
    Ok(())
}

fn existing_directories_with_prefix(
    root: &Path,
    prefix: &str,
) -> Result<Vec<PathBuf>, NativeError> {
    let entries = match fs::read_dir(root) {
        Ok(entries) => entries,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(e) => return Err(e.into()),
    };
    let mut paths = Vec::new();
    for entry in entries {
        let entry = match entry {
            Ok(entry) => entry,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => continue,
            Err(e) => return Err(e.into()),
        };
        if !entry
            .file_name()
            .to_str()
            .is_some_and(|name| name.starts_with(prefix))
        {
            continue;
        }
        match entry.file_type() {
            Ok(kind) if kind.is_dir() => paths.push(entry.path()),
            Ok(_) => {}
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(e) => return Err(e.into()),
        }
    }
    Ok(paths)
}

fn read_run_journal_or_default(path: &Path, name: &str) -> Result<RunJournal, NativeError> {
    let journal_path = path.join("journal.json");
    let text = match fs::read_to_string(&journal_path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return Ok(RunJournal {
                run_id: name.trim_start_matches("run-").to_string(),
                phase: RunPhase::CleanupPending,
                base_generation_id: None,
                candidate_generation_id: None,
                active_generation_id: None,
                last_error: Some("missing journal".to_string()),
            });
        }
        Err(error) => return Err(error.into()),
    };
    Ok(serde_json::from_str(&text)?)
}

fn is_not_found_error(error: &NativeError) -> bool {
    matches!(error, NativeError::Io(error) if error.kind() == std::io::ErrorKind::NotFound)
}

fn sync_parent_dir(path: &Path) -> Result<(), NativeError> {
    let parent = path.parent().ok_or_else(|| {
        NativeError::InvalidInput(format!("path {} has no parent", path.display()))
    })?;
    sync_dir(path)?;
    sync_dir(parent)?;
    Ok(())
}

#[derive(Debug, Clone, Copy)]
struct FileSizeSummary {
    logical_size_bytes: u64,
    physical_size_bytes: u64,
}

#[cfg(unix)]
fn allocated_size(metadata: &fs::Metadata) -> u64 {
    use std::os::unix::fs::MetadataExt;
    metadata.blocks().saturating_mul(512)
}

#[cfg(not(unix))]
fn allocated_size(metadata: &fs::Metadata) -> u64 {
    metadata.len()
}

fn managed_schema_version() -> u64 {
    MANAGED_SCHEMA_VERSION
}

fn unix_time_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64
}

fn abort_workspace_after_error(workspace: RunWorkspace, primary: NativeError) -> NativeError {
    match workspace.abort(Some(primary.to_string())) {
        Ok(()) => primary,
        Err(cleanup) => NativeError::InvalidInput(format!("{primary}; cleanup failed: {cleanup}")),
    }
}

fn finish_committed_workspace(workspace: RunWorkspace, generation_id: &str) {
    // The active pointer is the transaction commit. Journal finalization and
    // workspace removal remain recoverable cleanup after that boundary.
    let _ = workspace.mark_phase(RunPhase::Published, Some(generation_id.to_string()), None);
    let _ = workspace.finish();
}
