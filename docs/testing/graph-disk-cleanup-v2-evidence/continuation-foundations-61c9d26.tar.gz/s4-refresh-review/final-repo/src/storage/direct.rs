use crate::error::NativeError;
use crate::storage::atomic::{sync_dir, write_json_atomically};
use crate::storage::containment::{collect_registry, ensure_registry_empty, probe_registry};
use crate::storage::layout::{direct_bundle_paths, DirectLayout, DIRECT_DB_SIDECAR_SUFFIXES};
use crate::storage::locks::{open_locked, LockMode, WriterLease};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::fs::{self, OpenOptions};
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub(crate) enum DirectPublishPhase {
    Prepared,
    DatabasePromoted,
    ManifestPromoted,
    Committed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct DirectPublishJournal {
    pub phase: DirectPublishPhase,
    pub db_path: PathBuf,
    pub db_candidate_path: PathBuf,
    pub manifest_path: PathBuf,
    pub manifest_candidate_path: PathBuf,
    pub db_sha256: String,
    pub manifest_sha256: String,
    #[serde(default)]
    pub sidecar_sha256: BTreeMap<String, String>,
}

#[derive(Debug, Clone)]
pub(crate) struct DirectPublishRequest {
    pub db_candidate_path: PathBuf,
    pub manifest_candidate_path: PathBuf,
}

#[derive(Debug)]
pub(crate) struct DirectWriteSession {
    layout: DirectLayout,
    writer_lease: Option<WriterLease>,
    finished: bool,
}

impl DirectWriteSession {
    pub(crate) fn writer_lease(&self) -> Result<&WriterLease, NativeError> {
        self.writer_lease
            .as_ref()
            .ok_or_else(|| NativeError::InvalidInput("write session is finished".into()))
    }

    pub(crate) fn phase_workspace_root(&self) -> PathBuf {
        self.layout.phase_workspace_root()
    }
    pub(crate) fn db_candidate_path(&self) -> PathBuf {
        self.layout.db_candidate_path()
    }

    pub(crate) fn manifest_candidate_path(&self) -> PathBuf {
        self.layout.manifest_candidate_path()
    }

    pub(crate) fn publish(&mut self) -> Result<(), NativeError> {
        let store = DirectStore::new(self.layout.clone())?;
        let request = DirectPublishRequest {
            db_candidate_path: self.db_candidate_path(),
            manifest_candidate_path: self.manifest_candidate_path(),
        };
        let result = store.publish_candidate_with_lock(&request);
        if result.is_ok() || self.layout.journal_path().exists() {
            self.finished = true;
        }
        result
    }

    pub(crate) fn finish(mut self) {
        self.finished = true;
        drop(self.writer_lease.take());
    }
}

impl Drop for DirectWriteSession {
    fn drop(&mut self) {
        if self.finished {
            return;
        }
        let _ = cleanup_candidate_set(&self.layout);
        drop(self.writer_lease.take());
    }
}

#[derive(Debug, Clone)]
pub(crate) struct DirectStore {
    layout: DirectLayout,
}

impl DirectStore {
    pub(crate) fn new(layout: DirectLayout) -> Result<Self, NativeError> {
        layout.validate()?;
        Ok(Self { layout })
    }

    pub(crate) fn begin_write(&self) -> Result<DirectWriteSession, NativeError> {
        let parent = self
            .layout
            .db_path()
            .parent()
            .ok_or_else(|| NativeError::InvalidInput("direct parent missing".into()))?;
        let fresh = super::layout::create_fresh_reference_root(parent)?;
        self.ensure_parents()?;
        let mut writer_lease = self.open_writer_lock()?;
        super::maintenance_ownership::register_direct_pair(&self.layout)?;
        for resource in [self.layout.db_path(), self.layout.manifest_path()] {
            writer_lease.retain(
                super::maintenance_ownership::DatabaseUseLease::acquire_shared(resource)?
                    .into_lock()?,
            );
        }
        super::maintenance_ownership::ArtifactUseLease::ensure_root(
            &self.layout.artifact_root_path(),
        )?;
        let domain = super::maintenance_ownership::ReferenceDomain::direct(&self.layout)?;
        if let Some(fresh) = &fresh {
            // A fresh DB parent cannot bless an existing external manifest.
            if self
                .layout
                .manifest_path()
                .parent()
                .is_some_and(|manifest_parent| {
                    super::inventory::same_physical_path(parent, manifest_parent)
                })
            {
                super::maintenance_ownership::initialize_fresh_reference_domain(
                    &domain,
                    fresh,
                    &writer_lease,
                )?;
            }
        }
        writer_lease.retain(
            super::maintenance_ownership::ArtifactUseLease::acquire_in_domain(&domain)?.into_lock(),
        );
        collect_registry(&self.layout.phase_workspace_root()).map_err(NativeError::InvalidInput)?;
        self.recover_with_lock()?;
        cleanup_candidate_set(&self.layout)?;
        Ok(DirectWriteSession {
            layout: self.layout.clone(),
            writer_lease: Some(writer_lease),
            finished: false,
        })
    }

    pub(crate) fn begin_read(&self) -> Result<WriterLease, NativeError> {
        let mut writer_lease = self.open_writer_lock()?;
        // A committed reader only needs its lifetime guards. Registration is
        // producer overlap evidence; creating or repairing it is not required
        // to serve an existing pair and cannot establish cleanup eligibility.
        for resource in [self.layout.db_path(), self.layout.manifest_path()] {
            writer_lease.retain(
                super::maintenance_ownership::DatabaseUseLease::acquire_shared(resource)?
                    .into_lock()?,
            );
        }
        if !matches!(
            probe_registry(&self.layout.phase_workspace_root()),
            Ok(true)
        ) {
            if self.layout.journal_path().exists() {
                return Err(NativeError::InvalidInput(
                    "containment_unknown: direct publish replay blocked by protected phase".into(),
                ));
            }
            return writer_lease.relock_shared();
        }
        // Journal replay is required to identify the committed pair and must
        // still fail closed. Removing unrelated unpublished residue is optional.
        self.recover_with_lock()?;
        cleanup_candidate_set_with_policy(&self.layout, true)?;
        writer_lease.relock_shared()
    }

    /// Noncreating residue diagnostic; uncertainty keeps optional cleanup pending.
    pub(crate) fn candidate_cleanup_pending(&self) -> bool {
        let mut paths = direct_bundle_paths(&self.layout.db_candidate_path());
        paths.push(self.layout.manifest_candidate_path());
        paths.iter().any(|path| match fs::symlink_metadata(path) {
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => false,
            _ => true,
        })
    }

    fn publish_candidate_with_lock(
        &self,
        request: &DirectPublishRequest,
    ) -> Result<(), NativeError> {
        self.ensure_expected_candidate_paths(request)?;
        self.ensure_parents()?;
        self.recover_with_lock()?;
        ensure_regular_file(&request.db_candidate_path)?;
        ensure_regular_file(&request.manifest_candidate_path)?;

        let journal = DirectPublishJournal {
            phase: DirectPublishPhase::Prepared,
            db_path: self.layout.db_path().to_path_buf(),
            db_candidate_path: request.db_candidate_path.clone(),
            manifest_path: self.layout.manifest_path().to_path_buf(),
            manifest_candidate_path: request.manifest_candidate_path.clone(),
            db_sha256: sha256_path(&request.db_candidate_path)?,
            manifest_sha256: sha256_path(&request.manifest_candidate_path)?,
            sidecar_sha256: sidecar_checksums(&request.db_candidate_path)?,
        };
        self.write_journal(&journal)?;
        self.resume_publish(journal)?;
        self.remove_journal_and_shadows()?;
        cleanup_candidate_set(&self.layout)?;
        Ok(())
    }

    fn recover_with_lock(&self) -> Result<(), NativeError> {
        ensure_registry_empty(&self.layout.phase_workspace_root())
            .map_err(NativeError::InvalidInput)?;
        let journal_path = self.layout.journal_path();
        if !journal_path.exists() {
            return Ok(());
        }
        // Unlike an ordinary committed read, replay mutates the destination.
        // Preserve strict producer registration before any recovery effects.
        super::maintenance_ownership::register_direct_pair(&self.layout)?;
        let domain = super::maintenance_ownership::ReferenceDomain::direct(&self.layout)?;
        let _mutation = super::maintenance_ownership::ReferenceMutation::begin_in_domain(&domain)?;
        let journal = self.read_journal()?;
        self.validate_journal_destinations(&journal)?;
        self.validate_journal_sources(&journal)?;
        self.resume_publish(journal)?;
        self.remove_journal_and_shadows()?;
        cleanup_candidate_set(&self.layout)?;
        Ok(())
    }

    fn resume_publish(&self, mut journal: DirectPublishJournal) -> Result<(), NativeError> {
        ensure_registry_empty(&self.layout.phase_workspace_root())
            .map_err(NativeError::InvalidInput)?;
        if journal.phase == DirectPublishPhase::Prepared {
            promote_database_bundle(&journal)?;
            validate_checksum(&journal.db_path, &journal.db_sha256, "database")?;
            validate_sidecar_checksums(
                &journal.db_candidate_path,
                &journal.db_path,
                &journal.sidecar_sha256,
            )?;
            journal.phase = DirectPublishPhase::DatabasePromoted;
            self.write_journal(&journal)?;
        }

        if matches!(
            journal.phase,
            DirectPublishPhase::DatabasePromoted
                | DirectPublishPhase::ManifestPromoted
                | DirectPublishPhase::Committed
        ) {
            validate_checksum(&journal.db_path, &journal.db_sha256, "database")?;
            validate_sidecar_checksums(
                &journal.db_candidate_path,
                &journal.db_path,
                &journal.sidecar_sha256,
            )?;
        }

        if journal.phase == DirectPublishPhase::DatabasePromoted {
            replace_with_shadow(&journal.manifest_candidate_path, &journal.manifest_path)?;
            validate_checksum(&journal.manifest_path, &journal.manifest_sha256, "manifest")?;
            journal.phase = DirectPublishPhase::ManifestPromoted;
            self.write_journal(&journal)?;
        }

        if matches!(
            journal.phase,
            DirectPublishPhase::ManifestPromoted | DirectPublishPhase::Committed
        ) {
            validate_checksum(&journal.manifest_path, &journal.manifest_sha256, "manifest")?;
        }

        if journal.phase == DirectPublishPhase::ManifestPromoted {
            journal.phase = DirectPublishPhase::Committed;
            self.write_journal(&journal)?;
        }

        Ok(())
    }

    fn ensure_parents(&self) -> Result<(), NativeError> {
        if let Some(parent) = self.layout.db_path().parent() {
            fs::create_dir_all(parent)?;
        }
        if let Some(parent) = self.layout.manifest_path().parent() {
            fs::create_dir_all(parent)?;
        }
        Ok(())
    }

    fn ensure_expected_candidate_paths(
        &self,
        request: &DirectPublishRequest,
    ) -> Result<(), NativeError> {
        if request.db_candidate_path != self.layout.db_candidate_path()
            || request.manifest_candidate_path != self.layout.manifest_candidate_path()
        {
            return Err(NativeError::InvalidInput(
                "direct candidates must be the deterministic sibling candidate paths".to_string(),
            ));
        }
        Ok(())
    }

    fn validate_journal_destinations(
        &self,
        journal: &DirectPublishJournal,
    ) -> Result<(), NativeError> {
        if journal.db_path != self.layout.db_path()
            || journal.manifest_path != self.layout.manifest_path()
        {
            return Err(NativeError::InvalidInput(
                "direct publish journal does not match this store's configured destinations"
                    .to_string(),
            ));
        }
        Ok(())
    }

    fn validate_journal_sources(&self, journal: &DirectPublishJournal) -> Result<(), NativeError> {
        if journal.db_candidate_path != self.layout.db_candidate_path()
            || journal.manifest_candidate_path != self.layout.manifest_candidate_path()
            || journal
                .sidecar_sha256
                .keys()
                .any(|suffix| !DIRECT_DB_SIDECAR_SUFFIXES.contains(&suffix.as_str()))
        {
            return Err(NativeError::InvalidInput(
                "direct publish journal contains unexpected candidate paths or sidecars"
                    .to_string(),
            ));
        }
        Ok(())
    }

    fn write_journal(&self, journal: &DirectPublishJournal) -> Result<(), NativeError> {
        #[cfg(test)]
        faults::check(&faults::Point::BeforeCheckpoint(journal.phase.clone()))?;
        write_json_atomically(&self.layout.journal_path(), journal)
    }

    fn read_journal(&self) -> Result<DirectPublishJournal, NativeError> {
        let journal_path = self.layout.journal_path();
        ensure_regular_file(&journal_path)?;
        let text = fs::read_to_string(journal_path)?;
        Ok(serde_json::from_str(&text)?)
    }

    fn remove_journal_and_shadows(&self) -> Result<(), NativeError> {
        ensure_registry_empty(&self.layout.phase_workspace_root())
            .map_err(NativeError::InvalidInput)?;
        let journal_path = self.layout.journal_path();
        if journal_path.exists() {
            fs::remove_file(&journal_path)?;
            sync_parent(&journal_path)?;
        }
        cleanup_shadow_set(self.layout.db_path())?;
        cleanup_shadow_set(self.layout.manifest_path())?;
        Ok(())
    }

    fn open_writer_lock(&self) -> Result<WriterLease, NativeError> {
        open_locked(self.layout.writer_lock_path(), LockMode::Exclusive)
    }
}

fn promote_database_bundle(journal: &DirectPublishJournal) -> Result<(), NativeError> {
    replace_with_shadow(&journal.db_candidate_path, &journal.db_path)?;

    for suffix in DIRECT_DB_SIDECAR_SUFFIXES {
        let from = PathBuf::from(format!(
            "{}.{}",
            journal.db_candidate_path.display(),
            suffix
        ));
        let to = PathBuf::from(format!("{}.{}", journal.db_path.display(), suffix));
        // A missing candidate can mean its rename already completed. Only the
        // journal determines whether this sidecar belongs to the new bundle.
        if journal.sidecar_sha256.contains_key(*suffix) {
            replace_with_shadow(&from, &to)?;
            ensure_regular_file(&to)?;
        } else if to.exists() {
            remove_if_safe(&to)?;
        }
    }
    Ok(())
}

fn replace_with_shadow(from: &Path, to: &Path) -> Result<(), NativeError> {
    if !from.exists() {
        if to.exists() {
            return Ok(());
        }
        return Err(NativeError::InvalidInput(format!(
            "publish source does not exist: {}",
            from.display()
        )));
    }
    ensure_regular_file(from)?;
    if let Some(parent) = to.parent() {
        fs::create_dir_all(parent)?;
    }
    let shadow = shadow_path(to);
    if shadow.exists() {
        remove_if_safe(&shadow)?;
    }
    if to.exists() {
        ensure_not_symlink(to)?;
        fs::rename(to, &shadow)?;
        #[cfg(test)]
        faults::check(&faults::Point::AfterShadowRename(to.to_path_buf()))?;
        sync_parent(&shadow)?;
    }
    fs::rename(from, to)?;
    #[cfg(test)]
    faults::check(&faults::Point::AfterCandidateRename(to.to_path_buf()))?;
    sync_parent(to)?;
    Ok(())
}

fn cleanup_candidate_set(layout: &DirectLayout) -> Result<(), NativeError> {
    cleanup_candidate_set_with_policy(layout, false)
}

fn cleanup_candidate_set_with_policy(
    layout: &DirectLayout,
    optional: bool,
) -> Result<(), NativeError> {
    let mut candidates = direct_bundle_paths(&layout.db_candidate_path());
    candidates.push(layout.manifest_candidate_path());
    if !candidates
        .iter()
        .any(|path| fs::symlink_metadata(path).is_ok())
    {
        return Ok(());
    }
    let admission =
        super::maintenance_ownership::ReferenceDomain::direct(layout).and_then(|domain| {
            if optional {
                super::maintenance_ownership::ReferenceMutation::try_begin_in_domain(&domain)
            } else {
                super::maintenance_ownership::ReferenceMutation::begin_in_domain(&domain).map(Some)
            }
        });
    let _mutation = match admission {
        Ok(Some(mutation)) => mutation,
        Ok(None) => return Ok(()),
        Err(_) if optional => return Ok(()),
        Err(error) => return Err(error),
    };
    ensure_registry_empty(&layout.phase_workspace_root()).map_err(NativeError::InvalidInput)?;
    for path in direct_bundle_paths(&layout.db_candidate_path()) {
        remove_if_safe_if_present(&path)?;
    }
    remove_if_safe_if_present(&layout.manifest_candidate_path())?;
    Ok(())
}

fn cleanup_shadow_set(path: &Path) -> Result<(), NativeError> {
    remove_if_safe_if_present(&shadow_path(path))
}

fn sidecar_checksums(db_candidate_path: &Path) -> Result<BTreeMap<String, String>, NativeError> {
    let mut checksums = BTreeMap::new();
    for suffix in DIRECT_DB_SIDECAR_SUFFIXES {
        let path = PathBuf::from(format!("{}.{}", db_candidate_path.display(), suffix));
        if path.exists() {
            checksums.insert((*suffix).to_string(), sha256_path(&path)?);
        }
    }
    Ok(checksums)
}

fn validate_sidecar_checksums(
    candidate_db_path: &Path,
    db_path: &Path,
    checksums: &BTreeMap<String, String>,
) -> Result<(), NativeError> {
    for (suffix, expected) in checksums {
        let _candidate_path = PathBuf::from(format!("{}.{}", candidate_db_path.display(), suffix));
        let promoted_path = PathBuf::from(format!("{}.{}", db_path.display(), suffix));
        validate_checksum(
            &promoted_path,
            expected,
            &format!("database sidecar .{suffix}"),
        )?;
    }
    Ok(())
}

fn shadow_path(path: &Path) -> PathBuf {
    PathBuf::from(format!("{}.shadow", path.display()))
}

fn remove_if_safe_if_present(path: &Path) -> Result<(), NativeError> {
    if path.exists() {
        remove_if_safe(path)?;
    }
    Ok(())
}

fn remove_if_safe(path: &Path) -> Result<(), NativeError> {
    ensure_not_symlink(path)?;
    fs::remove_file(path)?;
    sync_parent(path)
}

fn ensure_regular_file(path: &Path) -> Result<(), NativeError> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() {
        return Err(NativeError::InvalidInput(format!(
            "refusing to publish symlinked file {}",
            path.display()
        )));
    }
    if metadata.is_file() {
        Ok(())
    } else {
        Err(NativeError::InvalidInput(format!(
            "direct publish candidate is not a file: {}",
            path.display()
        )))
    }
}

fn ensure_not_symlink(path: &Path) -> Result<(), NativeError> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() {
        return Err(NativeError::InvalidInput(format!(
            "refusing to replace symlinked path {}",
            path.display()
        )));
    }
    Ok(())
}

fn sync_parent(path: &Path) -> Result<(), NativeError> {
    let parent = path.parent().ok_or_else(|| {
        NativeError::InvalidInput(format!("path {} has no parent", path.display()))
    })?;
    sync_dir(parent)?;
    if path.exists() {
        OpenOptions::new()
            .read(true)
            .write(true)
            .open(path)?
            .sync_all()?;
    }
    Ok(())
}

fn sha256_path(path: &Path) -> Result<String, NativeError> {
    let bytes = fs::read(path)?;
    let mut digest = Sha256::new();
    digest.update(bytes);
    Ok(digest
        .finalize()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect())
}

fn validate_checksum(path: &Path, expected: &str, label: &str) -> Result<(), NativeError> {
    let actual = sha256_path(path)?;
    if actual == expected {
        Ok(())
    } else {
        Err(NativeError::InvalidInput(format!(
            "{label} checksum mismatch for {}",
            path.display()
        )))
    }
}

/// Thread-scoped, one-shot interruptions of the real publication path.
#[cfg(test)]
pub(crate) mod faults {
    use super::{DirectPublishPhase, NativeError, PathBuf};
    use std::cell::RefCell;

    #[derive(Debug, Clone, PartialEq, Eq)]
    pub(crate) enum Point {
        AfterShadowRename(PathBuf),
        AfterCandidateRename(PathBuf),
        BeforeCheckpoint(DirectPublishPhase),
    }

    thread_local! {
        static ARMED: RefCell<Option<Point>> = const { RefCell::new(None) };
    }

    pub(crate) struct Guard;

    pub(crate) fn arm(point: Point) -> Guard {
        ARMED.with(|armed| {
            assert!(armed.borrow().is_none(), "a Direct fault is already armed");
            *armed.borrow_mut() = Some(point);
        });
        Guard
    }

    impl Drop for Guard {
        fn drop(&mut self) {
            ARMED.with(|armed| *armed.borrow_mut() = None);
        }
    }

    pub(super) fn check(point: &Point) -> Result<(), NativeError> {
        ARMED.with(|armed| {
            if armed.borrow().as_ref() == Some(point) {
                *armed.borrow_mut() = None;
                Err(NativeError::Io(std::io::Error::other(format!(
                    "injected Direct publication interruption: {point:?}"
                ))))
            } else {
                Ok(())
            }
        })
    }
}
