pub(crate) fn serialize_schema_block(payload: &serde_json::Value) -> String {
    let node_types = value_array(payload, "node_types");
    let relation_types = value_array(payload, "relation_types");
    let parser_mappings = value_array(payload, "parser_node_mappings");
    let search_indexes = value_array(payload, "search_indexes");
    let profiles = payload
        .get("context_profiles")
        .and_then(serde_json::Value::as_object)
        .map(serde_json::Map::len)
        .unwrap_or_default();
    let query_helpers = value_array(payload, "query_helpers");
    let mut lines = vec![format!(
        "schema {} version={} nodes={} relations={} parser_mappings={} indexes={} profiles={} helpers={}",
        block_value(value_str(payload, "ontology")),
        block_value(value_str(payload, "version")),
        node_types.len(),
        relation_types.len(),
        parser_mappings.len(),
        search_indexes.len(),
        profiles,
        query_helpers.len()
    )];
    if !node_types.is_empty() {
        lines.push(format!("node_types {}", csv_names(node_types)));
    }
    if !relation_types.is_empty() {
        lines.push(format!("relation_types {}", csv_names(relation_types)));
    }
    for index in search_indexes {
        lines.push(format!(
            "index {} layer={} node_types={} fields={}",
            block_value(value_str(index, "name")),
            block_value(value_str(index, "layer")),
            csv_values(index.get("node_types")),
            csv_values(index.get("fields"))
        ));
    }
    if let Some(context_profiles) = payload
        .get("context_profiles")
        .and_then(serde_json::Value::as_object)
    {
        for (name, profile) in context_profiles {
            let relations = csv_values(profile.get("relations"));
            if relations.is_empty() {
                lines.push(format!("profile {}", block_value(name)));
            } else {
                lines.push(format!(
                    "profile {} relations={relations}",
                    block_value(name)
                ));
            }
        }
    }
    format!("{}\n", lines.join("\n"))
}

pub(crate) fn serialize_query_helpers_block(payload: &serde_json::Value) -> String {
    let helpers = value_array(payload, "query_helpers");
    let mut lines = vec![format!("query_helpers count={}", helpers.len())];
    for helper in helpers {
        append_query_spec_lines(&mut lines, helper, "");
    }
    format!("{}\n", lines.join("\n"))
}

pub(crate) fn serialize_architecture_queries_block(payload: &serde_json::Value) -> String {
    let groups = value_array(payload, "groups");
    let mut lines = vec![format!(
        "architecture_queries workflow={} execution_tool={} groups={}",
        block_value(value_str(payload, "workflow")),
        block_value(value_str(payload, "execution_tool")),
        groups.len()
    )];
    let recommended_order = csv_values(payload.get("recommended_order"));
    if !recommended_order.is_empty() {
        lines.push(format!("recommended_order {recommended_order}"));
    }
    for group in groups {
        lines.push(format!(
            "group {} goal={}",
            block_value(value_str(group, "name")),
            block_value(value_str(group, "goal"))
        ));
        for query in value_array(group, "queries") {
            append_query_spec_lines(&mut lines, query, "  ");
        }
    }
    format!("{}\n", lines.join("\n"))
}

pub(crate) fn serialize_syntax_block(payload: &serde_json::Value) -> String {
    let node_types = value_array(payload, "node_types");
    let capture_mappings = value_array(payload, "capture_mappings");
    let mut lines = vec![format!(
        "syntax language={} grammar_version={} nodes={} capture_mappings={}",
        block_value(value_str(payload, "language")),
        block_value(value_str(payload, "grammar_version")),
        node_types.len(),
        capture_mappings.len()
    )];
    let roots = csv_values(payload.get("root_node_types"));
    if !roots.is_empty() {
        lines.push(format!("root_node_types {roots}"));
    }
    for node in node_types {
        let fields = node
            .get("fields")
            .and_then(serde_json::Value::as_object)
            .map(|fields| fields.keys().cloned().collect::<Vec<_>>().join(","))
            .unwrap_or_default();
        if fields.is_empty() {
            lines.push(format!("node {}", block_value(value_str(node, "type"))));
        } else {
            lines.push(format!(
                "node {} fields={fields}",
                block_value(value_str(node, "type"))
            ));
        }
    }
    format!("{}\n", lines.join("\n"))
}

pub(crate) fn serialize_health_block(payload: &serde_json::Value) -> String {
    let mut lines = vec![format!(
        "health ok={} database_exists={} manifest_exists={} graph_readable={} total_nodes={} storage_format={} writable={} active_generation={} active_generation_published_at_unix_ms={} pending_runs={} cleanup_pending={} physical_database_bytes={} logical_database_bytes={}",
        value_bool(payload, "ok"),
        value_bool(payload, "database_exists"),
        value_bool(payload, "manifest_exists"),
        value_bool(payload, "graph_readable"),
        payload
            .get("total_nodes")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or_default(),
        block_value(value_str(payload, "storage_format")),
        value_bool(payload, "writable"),
        block_value(value_str(payload, "active_generation")),
        block_optional_payload_scalar(payload, "active_generation_published_at_unix_ms"),
        payload
            .get("pending_runs")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or_default(),
        value_bool(payload, "cleanup_pending"),
        payload
            .get("physical_database_bytes")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or_default(),
        payload
            .get("logical_database_bytes")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or_default()
    )];
    for key in [
        "repo_root",
        "database_path",
        "manifest_path",
        "storage_root",
    ] {
        lines.push(format!("{key} {}", block_value(value_str(payload, key))));
    }
    if let Some(remediation) = payload
        .get("remediation")
        .and_then(serde_json::Value::as_str)
    {
        lines.push(format!("remediation {}", block_value(remediation)));
    }
    if let Some(error) = payload.get("error").and_then(serde_json::Value::as_str) {
        lines.push(format!("error {}", block_value(error)));
    }
    append_refresh_health_lines(&mut lines, payload);
    append_maintenance_health_lines(&mut lines, payload);
    format!("{}\n", lines.join("\n"))
}

fn append_maintenance_health_lines(lines: &mut Vec<String>, payload: &serde_json::Value) {
    let Some(summary) = payload.get("maintenance").filter(|value| value.is_object()) else {
        return;
    };
    let fields = [
        "requested",
        "running",
        "pending",
        "observed_at_unix_ms",
        "observation_age_ms",
        "inventory_status",
        "measurement_complete",
        "observation_complete",
    ];
    lines.push(format!(
        "maintenance {}",
        fields
            .into_iter()
            .map(|key| format!("{key}={}", block_optional_payload_scalar(summary, key)))
            .collect::<Vec<_>>()
            .join(" ")
    ));
    if let Some(bytes) = summary.get("bytes") {
        for name in [
            "total",
            "retained",
            "potential_reclamation",
            "deferred",
            "unknown",
        ] {
            append_maintenance_bucket(lines, name, &bytes[name]);
        }
        for name in [
            "active_graph",
            "active_cache",
            "leased_generation",
            "live_run",
            "recovery_evidence",
            "artifact_temporary",
            "legacy_staging",
            "retired_direct",
            "coordination",
            "unknown",
        ] {
            append_maintenance_bucket(
                lines,
                &format!("by_category.{name}"),
                &bytes["by_category"][name],
            );
        }
    }
    for key in ["reasons", "errors"] {
        if let Some(values) = summary.get(key).and_then(serde_json::Value::as_array) {
            for value in values.iter().filter_map(serde_json::Value::as_str) {
                lines.push(format!("maintenance.{key} {}", block_value(value)));
            }
        }
    }
    if let Some(attempt) = summary
        .get("last_attempt")
        .filter(|value| value.is_object())
    {
        let fields = [
            "started_at_unix_ms",
            "finished_at_unix_ms",
            "status",
            "attempted_entries",
            "deleted_entries",
            "reclaimed_allocated_bytes",
            "continuation_phase",
        ];
        lines.push(format!(
            "maintenance.last_attempt {}",
            fields
                .into_iter()
                .map(|key| format!("{key}={}", block_optional_payload_scalar(attempt, key)))
                .collect::<Vec<_>>()
                .join(" ")
        ));
    }
}

fn append_maintenance_bucket(lines: &mut Vec<String>, name: &str, bucket: &serde_json::Value) {
    lines.push(format!(
        "maintenance.bytes.{name} logical_bytes={} allocated_bytes={}",
        block_optional_payload_scalar(bucket, "logical_bytes"),
        block_optional_payload_scalar(bucket, "allocated_bytes")
    ));
}

fn append_refresh_health_lines(lines: &mut Vec<String>, payload: &serde_json::Value) {
    let Some(refresh) = payload
        .get("refresh_health")
        .and_then(serde_json::Value::as_object)
        .or_else(|| {
            payload
                .get("refresh")
                .and_then(serde_json::Value::as_object)
        })
    else {
        return;
    };

    let freshness = payload
        .get("freshness")
        .and_then(serde_json::Value::as_str)
        .or_else(|| refresh.get("freshness").and_then(serde_json::Value::as_str))
        .unwrap_or("unknown");
    let readiness = payload
        .get("refresh_readiness")
        .and_then(serde_json::Value::as_str)
        .or_else(|| refresh.get("readiness").and_then(serde_json::Value::as_str))
        .unwrap_or("unknown");
    lines.push(format!(
        "refresh_freshness={} refresh_readiness={}",
        block_value(freshness),
        block_value(readiness)
    ));
    lines.push(format!(
        "refresh state={} task_alive={} root={} last_success={} pending={} retry={}",
        block_value(value_str_map(refresh, "state")),
        value_bool_or_unknown(refresh, "task_alive"),
        block_value(refresh_root(refresh, payload)),
        block_optional_scalar(refresh, "last_successful_reconciliation_unix_ms"),
        value_bool_or_unknown(refresh, "pending"),
        block_optional_scalar(refresh, "next_retry_unix_ms")
    ));
    if let Some(error) = refresh
        .get("last_error")
        .and_then(serde_json::Value::as_str)
    {
        if !error.is_empty() {
            lines.push(format!("last_error {}", block_value(error)));
        }
    }
}

fn refresh_root<'a>(
    refresh: &'a serde_json::Map<String, serde_json::Value>,
    payload: &'a serde_json::Value,
) -> &'a str {
    let root = value_str_map(refresh, "effective_root");
    if root.is_empty() {
        value_str(payload, "repo_root")
    } else {
        root
    }
}

fn value_str_map<'a>(value: &'a serde_json::Map<String, serde_json::Value>, key: &str) -> &'a str {
    value
        .get(key)
        .and_then(serde_json::Value::as_str)
        .unwrap_or("")
}

fn value_bool_or_unknown(
    value: &serde_json::Map<String, serde_json::Value>,
    key: &str,
) -> &'static str {
    value
        .get(key)
        .and_then(serde_json::Value::as_bool)
        .map(|value| if value { "true" } else { "false" })
        .unwrap_or("unknown")
}

fn block_optional_scalar(value: &serde_json::Map<String, serde_json::Value>, key: &str) -> String {
    match value.get(key) {
        None | Some(serde_json::Value::Null) => "null".to_string(),
        Some(serde_json::Value::String(value)) => block_value(value),
        Some(value) => value.to_string(),
    }
}

fn block_optional_payload_scalar(payload: &serde_json::Value, key: &str) -> String {
    match payload.get(key) {
        None | Some(serde_json::Value::Null) => "null".to_string(),
        Some(serde_json::Value::String(value)) => block_value(value),
        Some(value) => value.to_string(),
    }
}

pub(crate) fn serialize_search_block(payload: &serde_json::Value) -> String {
    let results = value_array(payload, "results");
    let mut lines = vec![format!(
        "q {} layer={}",
        block_value(value_str(payload, "query")),
        block_value(value_str(payload, "layer"))
    )];
    let mut current_path: Option<String> = None;
    for result in results {
        let result_path = value_str(result, "path").to_string();
        if current_path.as_deref() != Some(result_path.as_str()) {
            if lines.len() > 1 {
                lines.push(String::new());
            }
            lines.push(format!("file path {}", block_value(&result_path)));
            current_path = Some(result_path);
        }
        let mut result_parts = vec![
            format!("- {}", value_str(result, "type")),
            block_value(value_str(result, "label")),
            block_span(result.get("span")),
        ];
        if let Some(rank_score) = result.get("rank_score").and_then(serde_json::Value::as_f64) {
            result_parts.push(format!("rank_score={rank_score:.2}"));
        }
        if let Some(id) = result.get("id").and_then(serde_json::Value::as_str) {
            result_parts.push(format!("id={}", block_value(id)));
        }
        let layer = value_str(result, "layer");
        if !layer.is_empty() {
            result_parts.push(format!("layer={}", block_value(layer)));
        }
        let summary = value_str(result, "summary");
        if !summary.is_empty() && summary != value_str(result, "label") {
            result_parts.push(format!("summary={}", block_value(summary)));
        }
        lines.push(result_parts.join(" "));
    }
    format!("{}\n", lines.join("\n"))
}

pub(crate) fn serialize_query_block(payload: &serde_json::Value) -> String {
    let rows = value_array(payload, "rows");
    let columns = query_columns(value_str(payload, "statement"));
    let mut lines = vec![format!(
        "query rows={} truncated={}",
        payload
            .get("row_count")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or(rows.len() as u64),
        value_bool(payload, "truncated")
    )];
    lines.push(format!(
        "statement {}",
        block_value(value_str(payload, "statement"))
    ));
    if !columns.is_empty() {
        lines.push(format!("columns {}", columns.join(",")));
    }
    for (index, row) in rows.iter().enumerate() {
        let values = row
            .as_array()
            .cloned()
            .unwrap_or_else(|| vec![(*row).clone()]);
        let row_text = if !columns.is_empty() && columns.len() == values.len() {
            columns
                .iter()
                .zip(values.iter())
                .map(|(column, value)| format!("{column}={}", block_json_value(value)))
                .collect::<Vec<_>>()
                .join(" ")
        } else {
            values
                .iter()
                .map(block_json_value)
                .collect::<Vec<_>>()
                .join(" ")
        };
        lines.push(
            format!("row {} {}", index + 1, row_text)
                .trim_end()
                .to_string(),
        );
    }
    format!("{}\n", lines.join("\n"))
}

pub(crate) fn serialize_context_block(payload: &serde_json::Value) -> String {
    let mut lines = vec![format!(
        "context {} id={} layer={} profile={}",
        value_str(payload, "node_type"),
        block_value(value_str(payload, "node_id")),
        block_value(value_str(payload, "layer")),
        block_value(value_str(payload, "profile"))
    )];
    let mut current_path: Option<String> = None;
    for context in value_array(payload, "context") {
        let context_path = value_str(context, "path").to_string();
        if current_path.as_deref() != Some(context_path.as_str()) {
            if lines.len() > 1 {
                lines.push(String::new());
            }
            lines.push(format!("file path {}", block_value(&context_path)));
            current_path = Some(context_path);
        }
        let mut parts = vec![
            value_str(context, "direction").to_string(),
            value_str(context, "relation").to_string(),
            value_str(context, "type").to_string(),
            block_value(value_str(context, "label")),
            block_span(context.get("span")),
        ];
        let summary = value_str(context, "summary");
        if !summary.is_empty() && summary != value_str(context, "label") {
            parts.push(format!("summary={}", block_value(summary)));
        }
        if let Some(field_name) = context
            .get("field_name")
            .and_then(serde_json::Value::as_str)
        {
            parts.push(format!("field_name={}", block_value(field_name)));
        }
        if let Some(child_index) = context
            .get("child_index")
            .and_then(serde_json::Value::as_i64)
        {
            parts.push(format!("child_index={child_index}"));
        }
        lines.push(parts.join(" ").trim_end().to_string());
    }
    format!("{}\n", lines.join("\n"))
}

pub(crate) fn serialize_plan_block(payload: &serde_json::Value) -> String {
    let mut lines = vec![format!(
        "plan mode={} scanned={} rebuild={} delete={} skip={} ignored={}",
        block_value(value_str(payload, "mode")),
        payload
            .get("scanned")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or(0),
        payload
            .get("rebuilt")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or(0),
        payload
            .get("deleted")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or(0),
        payload
            .get("skipped")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or(0),
        payload
            .get("ignored")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or(0),
    )];
    append_plan_path_lines(&mut lines, "rebuild", value_array(payload, "would_rebuild"));
    append_plan_path_lines(&mut lines, "delete", value_array(payload, "would_delete"));
    append_plan_path_lines(&mut lines, "skip", value_array(payload, "would_skip"));
    append_plan_path_lines(&mut lines, "ignore", value_array(payload, "ignored_paths"));
    format!("{}\n", lines.join("\n"))
}

pub(crate) fn serialize_uninstall_block(output: &serde_json::Value) -> String {
    let mut lines = vec![format!(
        "uninstall ok={} server_name={}",
        output["ok"].as_bool().unwrap_or(false),
        output["server_name"].as_str().unwrap_or_default()
    )];
    if let Some(state) = output["state"].as_object() {
        lines.push(format!(
            "state action={} path={}",
            state
                .get("action")
                .and_then(serde_json::Value::as_str)
                .unwrap_or("unknown"),
            state
                .get("path")
                .and_then(serde_json::Value::as_str)
                .unwrap_or_default()
        ));
    }
    for item in output["instructions"].as_array().into_iter().flatten() {
        lines.push(format!(
            "instructions action={} path={}",
            item["action"].as_str().unwrap_or("unknown"),
            item["path"].as_str().unwrap_or_default()
        ));
    }
    for item in output["mcp_clients"].as_array().into_iter().flatten() {
        lines.push(format!(
            "mcp client={} action={} path={}",
            item["client"].as_str().unwrap_or("unknown"),
            item["action"].as_str().unwrap_or("unknown"),
            item["path"].as_str().unwrap_or_default()
        ));
    }
    lines.join("\n") + "\n"
}

fn block_span(value: Option<&serde_json::Value>) -> String {
    let Some(span) = value.and_then(serde_json::Value::as_object) else {
        return String::new();
    };
    let start = span
        .get("line_start")
        .and_then(serde_json::Value::as_i64)
        .unwrap_or_default();
    let end = span
        .get("line_end")
        .and_then(serde_json::Value::as_i64)
        .unwrap_or(start);
    if start <= 0 && end <= 0 {
        String::new()
    } else {
        format!("L{start}-L{end}")
    }
}

fn append_query_spec_lines(lines: &mut Vec<String>, query: &serde_json::Value, indent: &str) {
    lines.push(format!(
        "{indent}query {} description={}",
        block_value(value_str(query, "name")),
        block_value(value_str(query, "description"))
    ));
    let parameters = csv_values(query.get("parameters"));
    if !parameters.is_empty() {
        lines.push(format!("{indent}parameters {parameters}"));
    }
    let returns = csv_values(query.get("returns"));
    if !returns.is_empty() {
        lines.push(format!("{indent}returns {returns}"));
    }
    if let Some(statement) = query
        .get("statement")
        .or_else(|| query.get("query"))
        .and_then(serde_json::Value::as_str)
    {
        lines.push(format!("{indent}statement {}", block_value(statement)));
    }
}

fn query_columns(statement: &str) -> Vec<String> {
    let upper = statement.to_ascii_uppercase();
    let Some(return_index) = upper.find("RETURN") else {
        return Vec::new();
    };
    let after_return = return_index + "RETURN".len();
    let end = ["ORDER BY", "LIMIT"]
        .iter()
        .filter_map(|marker| {
            upper[after_return..]
                .find(marker)
                .map(|index| after_return + index)
        })
        .min()
        .unwrap_or(statement.len());
    split_return_expressions(&statement[after_return..end])
        .into_iter()
        .filter_map(|expression| query_column_label(&expression))
        .collect()
}

fn split_return_expressions(text: &str) -> Vec<String> {
    let mut expressions = Vec::new();
    let mut current = String::new();
    let mut depth = 0_i32;
    for character in text.chars() {
        match character {
            '(' => {
                depth += 1;
                current.push(character);
            }
            ')' => {
                depth = (depth - 1).max(0);
                current.push(character);
            }
            ',' if depth == 0 => {
                let trimmed = current.trim();
                if !trimmed.is_empty() {
                    expressions.push(trimmed.to_string());
                }
                current.clear();
            }
            _ => current.push(character),
        }
    }
    let trimmed = current.trim();
    if !trimmed.is_empty() {
        expressions.push(trimmed.to_string());
    }
    expressions
}

fn query_column_label(expression: &str) -> Option<String> {
    let parts = expression.split_whitespace().collect::<Vec<_>>();
    for index in 0..parts.len().saturating_sub(1) {
        if parts[index].eq_ignore_ascii_case("AS") && is_identifier(parts[index + 1]) {
            return Some(parts[index + 1].to_string());
        }
    }
    let label = expression.rsplit('.').next()?.trim();
    if is_identifier(label) {
        Some(label.to_string())
    } else {
        None
    }
}

fn is_identifier(value: &str) -> bool {
    let mut chars = value.chars();
    let Some(first) = chars.next() else {
        return false;
    };
    (first == '_' || first.is_ascii_alphabetic())
        && chars.all(|character| character == '_' || character.is_ascii_alphanumeric())
}

fn block_json_value(value: &serde_json::Value) -> String {
    match value {
        serde_json::Value::Null => "null".to_string(),
        serde_json::Value::Bool(value) => value.to_string(),
        serde_json::Value::Number(value) => value.to_string(),
        serde_json::Value::String(value) => block_value(value),
        other => serde_json::to_string(other).unwrap_or_else(|_| "{}".to_string()),
    }
}

fn value_array<'a>(payload: &'a serde_json::Value, key: &str) -> &'a [serde_json::Value] {
    payload
        .get(key)
        .and_then(serde_json::Value::as_array)
        .map(Vec::as_slice)
        .unwrap_or(&[])
}

fn value_str<'a>(payload: &'a serde_json::Value, key: &str) -> &'a str {
    payload
        .get(key)
        .and_then(serde_json::Value::as_str)
        .unwrap_or("")
}

fn value_bool(payload: &serde_json::Value, key: &str) -> bool {
    payload
        .get(key)
        .and_then(serde_json::Value::as_bool)
        .unwrap_or(false)
}

fn csv_names(values: &[serde_json::Value]) -> String {
    values
        .iter()
        .filter_map(|value| value.get("name").and_then(serde_json::Value::as_str))
        .map(block_value)
        .collect::<Vec<_>>()
        .join(",")
}

fn csv_values(value: Option<&serde_json::Value>) -> String {
    value
        .and_then(serde_json::Value::as_array)
        .map(|values| {
            values
                .iter()
                .filter_map(serde_json::Value::as_str)
                .map(block_value)
                .collect::<Vec<_>>()
                .join(",")
        })
        .unwrap_or_default()
}

fn append_plan_path_lines(lines: &mut Vec<String>, label: &str, paths: &[serde_json::Value]) {
    for path in paths {
        if let Some(path) = path.as_str() {
            lines.push(format!("{label} {}", block_value(path)));
        }
    }
}

fn block_value(value: &str) -> String {
    if value.is_empty() {
        "\"\"".to_string()
    } else if value.chars().all(|character| {
        character.is_ascii_alphanumeric() || matches!(character, '_' | '-' | '.' | '/' | ':')
    }) {
        value.to_string()
    } else {
        serde_json::to_string(value).unwrap_or_else(|_| "\"\"".to_string())
    }
}
