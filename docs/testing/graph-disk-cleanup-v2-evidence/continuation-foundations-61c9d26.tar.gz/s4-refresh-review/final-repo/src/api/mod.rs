//! Stable, transport-neutral entry point for codebase graph operations.
//!
//! Embedded clients construct an [`OperationRequest`] and submit it through
//! [`CodebaseGraphApi::execute_operation`]. The same facade is used by the CLI
//! and MCP adapters, so validation, runtime selection, errors, and presentation
//! remain consistent across surfaces.

pub mod catalog;
pub mod context;
pub mod contracts;
pub mod core;
mod execution_context;
pub mod facade;
pub(crate) mod graph_read;
pub mod lifecycle;
mod materialization;
mod normalization;
pub mod presenter;
mod refresh;

pub use contracts::{
    ApiError, ContextRequest, HealthRequest, MaterializationRequest, McpInstallRequest,
    McpTransport, OperationInvocation, OperationRequest, OperationResponse, OutputFormat,
    QueryRequest, RefreshBackend, RefreshLoopConfig, RefreshRequest, RefreshWatchConfig,
    RefreshWatchObserver, RefreshWatchSummary, RepoSelector, RepositoryLifecycleRequest,
    SearchRequest,
};
pub use core::OperationDescriptor;
pub(crate) use execution_context::{
    ExecutionContext, HOOK_TIMEOUT_HEADER, MAX_CONNECTIONS, MAX_HOOK_TIMEOUT, POLL_INTERVAL,
};
pub(crate) use facade::CoordinatorCodebaseGraphApi;
pub use facade::{CodebaseGraphApi, OperationExecutor};
pub use lifecycle::{
    inspect_mcp_server, install_mcp_endpoint, install_mcp_server, mcp_harness_capabilities,
    remove_mcp_server, rename_mcp_server, resolve_mcp_target, supported_mcp_clients,
    McpClientInstallOptions, McpClientRemovalOptions, McpClientRenameOptions,
    McpEndpointDescriptor, McpExistingEntryPolicy, McpHarnessCapabilities, McpInstallMode,
    McpServerDescriptor, McpServerRegistration, McpTargetLocality, ResolvedMcpTarget,
};
pub(crate) use materialization::{
    execute_candidate_materialization, execute_materialization, read_manifest, MaterializeOptions,
};
pub(crate) use refresh::{
    RefreshCancellation, RefreshConfigOverrides, RefreshRuntime, RefreshServiceConfig, RefreshState,
};

#[cfg(test)]
pub(crate) use refresh::{
    apply_watch_message, collect_poll_batch, collect_watch_batch, probe_native_watcher,
    watch_file_snapshot, watch_snapshot_diff, WatchChangeBatch, WatchEventFilter, WatchMessage,
};

#[cfg(test)]
mod boundary_tests;
