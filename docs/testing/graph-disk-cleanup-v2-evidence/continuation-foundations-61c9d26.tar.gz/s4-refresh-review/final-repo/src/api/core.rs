use crate::api::catalog::{filter_catalog, load_catalog, supported_syntax_languages};
use crate::api::context::{resolve_runtime, RepoRuntime};
use crate::api::contracts::{
    ApiError, ContextRequest, HealthRequest, MaterializationRequest, OperationInvocation,
    OperationRequest, OperationResponse, OutputFormat, QueryRequest, SearchRequest,
};
use crate::api::graph_read::{
    count_graph_nodes, execute_graph_context, execute_graph_search, execute_read_only_query,
    validate_read_only_statement, GraphSearchRequest,
};
use crate::api::lifecycle::{
    install_mcp_client, refresh_repository, reinstall_repository, setup_repository,
    uninstall_repository,
};
use crate::api::materialization::{
    build_request, execute_materialization_request, plan_materialization_payload, read_request,
    MaterializeOptions,
};
use crate::api::normalization::{
    normalize_request, prepare_operation_request, validate_request, DEFAULT_CONTEXT_LIMIT,
    DEFAULT_DETAIL, DEFAULT_LAYER, DEFAULT_PROFILE, DEFAULT_QUERY_LIMIT, DEFAULT_SEARCH_BUDGET,
    DEFAULT_SEARCH_LIMIT,
};
use crate::api::presenter::present_operation_response;
use crate::api::refresh::RefreshState;
use crate::error::NativeError;
use crate::materialization_worker::execute_explicit_worker;
use crate::protocol::{NativeSyntaxMaterializationRequest, NativeSyntaxMaterializationResponse};
use crate::storage::layout::direct_bundle_paths;
use serde_json::json;
use std::{
    collections::BTreeMap,
    fs,
    path::Path,
    sync::Arc,
    time::{SystemTime, UNIX_EPOCH},
};

#[derive(Debug, Clone, Copy)]
pub struct OperationDescriptor {
    pub id: &'static str,
    pub summary: &'static str,
    pub request_schema: fn() -> serde_json::Value,
    pub surfaces: &'static [&'static str],
    pub supported_outputs: &'static [OutputFormat],
    pub mcp_tool_name: Option<&'static str>,
}

impl OperationDescriptor {
    pub fn required_fields(&self) -> &'static [&'static str] {
        crate::api::normalization::required_fields(self.id)
    }
}

#[derive(Debug, Clone)]
pub(crate) struct OperationRegistry {
    pub(crate) operations: BTreeMap<&'static str, RegisteredOperation>,
}

type OperationHandler =
    fn(&OperationRequest, Option<&RepoRuntime>) -> Result<OperationResponse, ApiError>;

#[derive(Debug, Clone, Copy)]
pub(crate) struct RegisteredOperation {
    descriptor: OperationDescriptor,
    handler: OperationHandler,
}

#[derive(Debug, Clone, Default)]
pub struct ApiCore {
    refresh: Option<Arc<RefreshState>>,
    isolate_materialization: bool,
}

impl ApiCore {
    pub fn new() -> Self {
        Self::default()
    }

    pub(crate) fn for_coordinator(refresh: Option<Arc<RefreshState>>) -> Self {
        Self {
            refresh,
            isolate_materialization: true,
        }
    }

    pub(crate) fn register_operations(&self) -> OperationRegistry {
        let descriptors = [
            OperationDescriptor {
                id: "health",
                summary: "Check codebase graph and manifest availability",
                request_schema: health_request_schema,
                surfaces: &["api", "cli", "mcp"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: Some("graph_health"),
            },
            OperationDescriptor {
                id: "search",
                summary: "Search for code graph entities",
                request_schema: search_request_schema,
                surfaces: &["api", "cli", "mcp"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: Some("graph_search"),
            },
            OperationDescriptor {
                id: "context",
                summary: "Return graph context for matches or explicit nodes",
                request_schema: context_request_schema,
                surfaces: &["api", "cli", "mcp"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: Some("graph_context"),
            },
            OperationDescriptor {
                id: "query",
                summary: "Execute read-only graph query",
                request_schema: query_request_schema,
                surfaces: &["api", "cli", "mcp"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: Some("graph_query"),
            },
            OperationDescriptor {
                id: "materialize",
                summary: "Scan and build full graph materialization",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: None,
            },
            OperationDescriptor {
                id: "plan",
                summary: "Plan materialization without database write",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: None,
            },
            OperationDescriptor {
                id: "schema",
                summary: "Return graph schema catalog",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli", "mcp"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: Some("graph_schema"),
            },
            OperationDescriptor {
                id: "syntax",
                summary: "Return a language syntax catalog",
                request_schema: syntax_request_schema,
                surfaces: &["api", "cli", "mcp"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: Some("graph_syntax"),
            },
            OperationDescriptor {
                id: "query-helpers",
                summary: "Return query helper catalog",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli", "mcp"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: Some("graph_query_helpers"),
            },
            OperationDescriptor {
                id: "architecture-queries",
                summary: "Return architecture query catalog",
                request_schema: architecture_queries_request_schema,
                surfaces: &["api", "cli", "mcp"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: Some("graph_architecture_queries"),
            },
            OperationDescriptor {
                id: "setup",
                summary: "Install graph state and optional MCP configuration",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: None,
            },
            OperationDescriptor {
                id: "reinstall",
                summary: "Rebuild graph state after backup/restore choreography",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: None,
            },
            OperationDescriptor {
                id: "uninstall",
                summary: "Remove graph state and related MCP configuration",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: None,
            },
            OperationDescriptor {
                id: "mcp-install",
                summary: "Register the graph tool with a supported client",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: None,
            },
            OperationDescriptor {
                id: "refresh",
                summary: "Refresh changed paths via incremental materialization",
                request_schema: empty_request_schema,
                surfaces: &["api", "cli"],
                supported_outputs: &[OutputFormat::Typed, OutputFormat::Block],
                mcp_tool_name: None,
            },
        ];

        build_registry(descriptors)
    }

    pub(crate) fn resolve_operation(&self, id: &str) -> Option<RegisteredOperation> {
        self.register_operations().operations.get(id).copied()
    }

    pub(crate) fn resolve_mcp_operation(&self, tool_name: &str) -> Option<OperationDescriptor> {
        self.operations()
            .into_iter()
            .find(|operation| operation.mcp_tool_name == Some(tool_name))
    }

    pub fn execute(&self, request: &OperationRequest) -> Result<OperationResponse, ApiError> {
        let mut request = normalize_request(request);
        if let (Some(refresh), OperationRequest::Health(health)) = (&self.refresh, &mut request) {
            if health.refresh_status.is_none() {
                health.refresh_status = Some(refresh.as_json());
            }
        }
        validate_request(&request)?;
        let operation = self
            .resolve_operation(request.operation_name())
            .ok_or_else(|| {
                ApiError::new(
                    "unsupported_operation",
                    format!("unsupported operation: {}", request.operation_name()),
                )
            })?;
        let mut runtime = request
            .repo_selector()
            .map(resolve_runtime)
            .transpose()
            .map_err(|error| ApiError::new("runtime_resolution_failed", error))?;
        if operation_requires_graph_write(&request) {
            if let Some(runtime) = runtime.as_mut() {
                runtime.require_graph_write().map_err(|message| {
                    ApiError::new("legacy_storage_requires_reinstall", message)
                        .with_details(serde_json::json!({
                            "schema_version": 1,
                            "remediation": format!(
                                "codebase-graph reinstall --repo-root {}",
                                runtime.repo_root.display()
                            ),
                        }))
                        .retryable(false)
                })?;
            }
        }
        if operation_may_replace_graph_state(&request) {
            if let Some(runtime) = runtime.as_mut() {
                runtime.active_read = None;
                runtime.direct_read = None;
            }
        }
        let response = if self.isolate_materialization {
            match (&request, runtime.as_ref()) {
                (OperationRequest::Materialize(request), Some(runtime)) => {
                    execute_isolated_materialization(request, runtime, self.refresh.as_deref())?
                }
                _ => dispatch_operation(&request, &operation, runtime.as_ref())?,
            }
        } else {
            dispatch_operation(&request, &operation, runtime.as_ref())?
        };
        Ok(present_operation_response(
            response,
            request.output_format(),
        ))
    }

    pub(crate) fn execute_invocation(
        &self,
        operation_id: &str,
        invocation: &OperationInvocation,
    ) -> Result<OperationResponse, ApiError> {
        let request = prepare_operation_request(operation_id, invocation)?;
        self.execute(&request)
    }

    pub(crate) fn operations(&self) -> Vec<OperationDescriptor> {
        let mut items: Vec<_> = self
            .register_operations()
            .operations
            .values()
            .map(|operation| operation.descriptor)
            .collect();
        items.sort_by_key(|descriptor| descriptor.id);
        items
    }
}

fn build_registry(descriptors: impl IntoIterator<Item = OperationDescriptor>) -> OperationRegistry {
    let mut by_id = BTreeMap::new();
    for descriptor in descriptors {
        let handler: OperationHandler = match descriptor.id {
            "health" => handle_health,
            "search" => handle_search,
            "context" => handle_context,
            "query" => handle_query,
            "materialize" => handle_materialize,
            "plan" => handle_plan,
            "schema" | "syntax" | "query-helpers" | "architecture-queries" => handle_catalog,
            "setup" => handle_setup,
            "reinstall" => handle_reinstall,
            "uninstall" => handle_uninstall,
            "mcp-install" => handle_mcp_install,
            "refresh" => handle_refresh,
            id => panic!("operation {id} does not have a handler registration"),
        };
        assert!(
            !descriptor.supported_outputs.is_empty(),
            "operation {} must expose at least one output format",
            descriptor.id
        );
        assert_eq!(
            descriptor.surfaces.contains(&"mcp"),
            descriptor.mcp_tool_name.is_some(),
            "operation {} has inconsistent MCP exposure",
            descriptor.id
        );
        if by_id
            .insert(
                descriptor.id,
                RegisteredOperation {
                    descriptor,
                    handler,
                },
            )
            .is_some()
        {
            panic!("duplicate operation registration: {}", descriptor.id);
        }
    }
    OperationRegistry { operations: by_id }
}

fn health_request_schema() -> serde_json::Value {
    json!({
        "confirm_legacy_quiescence": {
            "type": "boolean",
            "default": false,
            "description": "Confirm all old daemons/helpers have been stopped and upgraded before this maintenance request. This operator precondition does not replace destination ownership checks."
        }
    })
}

fn empty_request_schema() -> serde_json::Value {
    json!({})
}

fn search_request_schema() -> serde_json::Value {
    json!({
        "query": {"type": "string"},
        "layer": {"type": "string", "enum": ["semantic", "syntax", "hybrid"], "default": DEFAULT_LAYER},
        "limit": {"type": "integer", "minimum": 1, "default": DEFAULT_SEARCH_LIMIT},
        "profile": {"type": "string", "default": DEFAULT_PROFILE},
        "budget": {"type": "integer", "minimum": 0, "default": DEFAULT_SEARCH_BUDGET},
        "context_limit": {"type": "integer", "minimum": 0, "default": DEFAULT_CONTEXT_LIMIT},
        "max_depth": {"type": "integer", "minimum": 0},
        "detail": {"type": "string", "enum": ["standard", "slim"], "default": DEFAULT_DETAIL},
    })
}

fn context_request_schema() -> serde_json::Value {
    json!({
        "query": {"type": "string"},
        "node_id": {"type": "string"},
        "node_type": {"type": "string"},
        "layer": {"type": "string", "enum": ["semantic", "syntax", "hybrid"], "default": DEFAULT_LAYER},
        "limit": {"type": "integer", "minimum": 1, "default": DEFAULT_SEARCH_LIMIT},
        "profile": {"type": "string", "default": DEFAULT_PROFILE},
        "budget": {"type": "integer", "minimum": 0, "default": DEFAULT_SEARCH_BUDGET},
        "context_limit": {"type": "integer", "minimum": 0, "default": DEFAULT_CONTEXT_LIMIT},
        "max_depth": {"type": "integer", "minimum": 0},
        "detail": {"type": "string", "enum": ["standard", "slim"], "default": DEFAULT_DETAIL},
    })
}

fn query_request_schema() -> serde_json::Value {
    json!({
        "statement": {"type": "string"},
        "parameters": {"type": "object"},
        "query": {"type": "string"},
        "limit": {"type": "integer", "minimum": 1, "maximum": 1000, "default": DEFAULT_QUERY_LIMIT},
    })
}

fn architecture_queries_request_schema() -> serde_json::Value {
    json!({
        "group": {"type": "string"},
    })
}

fn syntax_request_schema() -> serde_json::Value {
    json!({
        "language": {"type": "string", "enum": supported_syntax_languages()},
    })
}

fn dispatch_operation(
    request: &OperationRequest,
    operation: &RegisteredOperation,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    (operation.handler)(request, runtime)
}

fn operation_requires_graph_write(request: &OperationRequest) -> bool {
    matches!(
        request,
        OperationRequest::Materialize(_)
            | OperationRequest::Setup(_)
            | OperationRequest::Refresh(_)
    )
}

fn operation_may_replace_graph_state(request: &OperationRequest) -> bool {
    operation_requires_graph_write(request)
        || matches!(
            request,
            OperationRequest::Reinstall(_) | OperationRequest::Uninstall(_)
        )
}

fn required_runtime<'a>(
    operation: &str,
    runtime: Option<&'a RepoRuntime>,
) -> Result<&'a RepoRuntime, ApiError> {
    runtime.ok_or_else(|| {
        ApiError::new(
            "runtime_resolution_failed",
            format!("{operation} operation requires a repository selector"),
        )
    })
}

fn invalid_request(expected: &str, request: &OperationRequest) -> ApiError {
    ApiError::new(
        "invalid_operation_request",
        format!(
            "operation handler expected {expected}, received {}",
            request.operation_name()
        ),
    )
}

fn handle_health(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Health(request) = request else {
        return Err(invalid_request("health", request));
    };
    execute_health(request, required_runtime("health", runtime)?)
}

fn handle_search(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Search(request) = request else {
        return Err(invalid_request("search", request));
    };
    execute_search(request, required_runtime("search", runtime)?)
}

fn handle_context(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Context(request) = request else {
        return Err(invalid_request("context", request));
    };
    execute_context(request, required_runtime("context", runtime)?)
}

fn handle_query(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Query(request) = request else {
        return Err(invalid_request("query", request));
    };
    execute_query(request, required_runtime("query", runtime)?)
}

fn handle_materialize(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Materialize(request) = request else {
        return Err(invalid_request("materialize", request));
    };
    execute_materialization(request, required_runtime("materialize", runtime)?, false)
}

fn handle_plan(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Plan(request) = request else {
        return Err(invalid_request("plan", request));
    };
    execute_materialization(request, required_runtime("plan", runtime)?, true)
}

fn handle_catalog(
    request: &OperationRequest,
    _runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Catalog { kind, group, .. } = request else {
        return Err(invalid_request("catalog", request));
    };
    let mut payload =
        load_catalog(kind).map_err(|error| ApiError::new("invalid_catalog_kind", error))?;
    filter_catalog(kind, &mut payload, group.as_deref())
        .map_err(|error| ApiError::new("invalid_catalog_group", error))?;
    Ok(OperationResponse::from_payload(
        kind,
        OutputFormat::Typed,
        payload,
    ))
}

fn handle_setup(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Setup(request) = request else {
        return Err(invalid_request("setup", request));
    };
    let runtime = required_runtime("setup", runtime)?;
    reject_legacy_write_operation(runtime)?;
    Ok(OperationResponse::from_payload(
        "setup",
        OutputFormat::Typed,
        setup_repository(request, runtime)?,
    ))
}

fn handle_reinstall(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Reinstall(request) = request else {
        return Err(invalid_request("reinstall", request));
    };
    Ok(OperationResponse::from_payload(
        "reinstall",
        OutputFormat::Typed,
        reinstall_repository(request, required_runtime("reinstall", runtime)?)?,
    ))
}

fn handle_uninstall(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Uninstall(request) = request else {
        return Err(invalid_request("uninstall", request));
    };
    Ok(OperationResponse::from_payload(
        "uninstall",
        OutputFormat::Typed,
        uninstall_repository(request, required_runtime("uninstall", runtime)?)?,
    ))
}

fn handle_mcp_install(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::InstallMcp(request) = request else {
        return Err(invalid_request("mcp-install", request));
    };
    Ok(OperationResponse::from_payload(
        "mcp-install",
        OutputFormat::Typed,
        install_mcp_client(request, required_runtime("mcp-install", runtime)?)?,
    ))
}

fn handle_refresh(
    request: &OperationRequest,
    runtime: Option<&RepoRuntime>,
) -> Result<OperationResponse, ApiError> {
    let OperationRequest::Refresh(request) = request else {
        return Err(invalid_request("refresh", request));
    };
    let runtime = required_runtime("refresh", runtime)?;
    reject_legacy_write_operation(runtime)?;
    Ok(OperationResponse::from_payload(
        "refresh",
        OutputFormat::Typed,
        refresh_repository(request, runtime)?,
    ))
}

fn execute_health(
    request: &HealthRequest,
    runtime: &RepoRuntime,
) -> Result<OperationResponse, ApiError> {
    let output_format = request.output_format;

    let mut graph_readable = false;
    let mut total_nodes = 0_u64;
    let mut error_message = None;
    let database_exists = runtime.db_path.exists();
    let manifest_exists = runtime.manifest_path.exists();
    let physical_database_bytes = physical_database_bytes(runtime);
    let logical_database_bytes = logical_database_bytes(runtime);

    if database_exists {
        match count_graph_nodes(&runtime.db_path) {
            Ok(count) => {
                graph_readable = true;
                total_nodes = count;
            }
            Err(error) => {
                error_message = Some(error);
            }
        }
    } else {
        error_message = Some(format!(
            "database file does not exist: {}",
            runtime.db_path.display()
        ));
    }

    let refresh_health = refresh_health_payload(
        request.refresh_status.as_ref(),
        graph_readable,
        unix_time_millis(),
    );
    let active_generation_published_at_unix_ms = runtime
        .active_read
        .as_ref()
        .and_then(|snapshot| (snapshot.published_at_ms > 0).then_some(snapshot.published_at_ms));

    let payload = json!({
        "ok": graph_readable,
        "repo_root": runtime.repo_root,
        "database_path": runtime.db_path,
        "manifest_path": runtime.manifest_path,
        "storage_root": runtime.storage_root,
        "database_exists": database_exists,
        "manifest_exists": manifest_exists,
        "graph_readable": graph_readable,
        "total_nodes": total_nodes,
        "storage_format": runtime.storage_format(),
        "writable": runtime.writable,
        "active_generation": runtime.active_generation,
        "active_generation_published_at_unix_ms": active_generation_published_at_unix_ms,
        "pending_runs": runtime.pending_runs,
        "cleanup_pending": runtime.cleanup_pending,
        "physical_database_bytes": physical_database_bytes,
        "logical_database_bytes": logical_database_bytes,
        "remediation": runtime.remediation(),
        "error": error_message,
        "refresh": request.refresh_status,
        "freshness": refresh_health["freshness"].clone(),
        "refresh_readiness": refresh_health["readiness"].clone(),
        "refresh_health": refresh_health,
        "maintenance": maintenance_health_payload(&crate::protocol::MaintenanceSummary::default()),
    });
    Ok(OperationResponse::from_payload(
        "health",
        output_format,
        payload,
    ))
}

// Only compact cached summaries belong on this path; never scan an inventory.
fn maintenance_health_payload(summary: &crate::protocol::MaintenanceSummary) -> serde_json::Value {
    serde_json::to_value(summary).expect("maintenance summary contains only serializable values")
}

fn unix_time_millis() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_millis())
        .unwrap_or_default()
}

fn refresh_health_payload(
    refresh_status: Option<&serde_json::Value>,
    graph_readable: bool,
    now_unix_ms: u128,
) -> serde_json::Value {
    let Some(status) = refresh_status.and_then(serde_json::Value::as_object) else {
        return json!({
            "freshness": "unknown",
            "readiness": "unknown",
            "state": "unknown",
            "task_alive": null,
            "effective_root": null,
            "last_successful_reconciliation_unix_ms": null,
            "oldest_pending_unix_ms": null,
            "next_retry_unix_ms": null,
            "pending": null,
            "dirty_epoch": null,
            "reconciled_epoch": null,
            "last_error": null,
        });
    };

    let state = status
        .get("state")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("unknown");
    let task_alive = status
        .get("task_alive")
        .and_then(serde_json::Value::as_bool);
    let enabled = status.get("enabled").and_then(serde_json::Value::as_bool);
    let pending = status.get("pending").and_then(serde_json::Value::as_bool);
    let dirty_epoch = value_u128(status.get("dirty_epoch"));
    let reconciled_epoch = value_u128(status.get("reconciled_epoch"));
    let last_success = value_u128(status.get("last_successful_reconciliation_unix_ms"));
    let has_pending_epoch = dirty_epoch
        .zip(reconciled_epoch)
        .is_some_and(|(dirty, reconciled)| dirty > reconciled);
    let pending_work = pending.unwrap_or(false) || has_pending_epoch;
    let last_error = status
        .get("last_error")
        .and_then(serde_json::Value::as_str)
        .filter(|error| !error.is_empty());

    let readiness = refresh_readiness(state, enabled, task_alive);
    let freshness = refresh_freshness(
        &RefreshHealthFacts {
            graph_readable,
            state,
            enabled,
            task_alive,
            pending: pending_work,
            dirty_epoch,
            reconciled_epoch,
            last_success,
            has_error: last_error.is_some(),
            interval_unix_ms: refresh_interval_unix_ms(status),
        },
        now_unix_ms,
    );

    json!({
        "freshness": freshness,
        "readiness": readiness,
        "state": state,
        "task_alive": task_alive,
        "effective_root": status.get("effective_root").cloned().unwrap_or(serde_json::Value::Null),
        "last_successful_reconciliation_unix_ms": status
            .get("last_successful_reconciliation_unix_ms")
            .cloned()
            .unwrap_or(serde_json::Value::Null),
        "oldest_pending_unix_ms": status
            .get("oldest_pending_unix_ms")
            .cloned()
            .unwrap_or(serde_json::Value::Null),
        "next_retry_unix_ms": status
            .get("next_retry_unix_ms")
            .cloned()
            .unwrap_or(serde_json::Value::Null),
        "pending": pending_work,
        "dirty_epoch": status.get("dirty_epoch").cloned().unwrap_or(serde_json::Value::Null),
        "reconciled_epoch": status
            .get("reconciled_epoch")
            .cloned()
            .unwrap_or(serde_json::Value::Null),
        "last_error": status.get("last_error").cloned().unwrap_or(serde_json::Value::Null),
    })
}

fn refresh_readiness(state: &str, enabled: Option<bool>, task_alive: Option<bool>) -> &'static str {
    if enabled == Some(false) || matches!(state, "disabled" | "off") {
        return "disabled";
    }
    match state {
        "running" => match task_alive {
            Some(true) => "ready",
            Some(false) => "stopped",
            None => "unknown",
        },
        "starting" => "starting",
        "retrying" => "retrying",
        "blocked" => "blocked",
        "standby" => "standby",
        "stopped" => "stopped",
        _ => "unknown",
    }
}

struct RefreshHealthFacts<'a> {
    graph_readable: bool,
    state: &'a str,
    enabled: Option<bool>,
    task_alive: Option<bool>,
    pending: bool,
    dirty_epoch: Option<u128>,
    reconciled_epoch: Option<u128>,
    last_success: Option<u128>,
    has_error: bool,
    interval_unix_ms: Option<u128>,
}

fn refresh_freshness(facts: &RefreshHealthFacts<'_>, now_unix_ms: u128) -> &'static str {
    if !facts.graph_readable
        || facts.enabled == Some(false)
        || !matches!(facts.state, "running")
        || facts.task_alive != Some(true)
        || facts.has_error
    {
        return "unknown";
    }
    if facts.pending {
        return "pending";
    }
    let (Some(dirty), Some(reconciled), Some(last_success)) = (
        facts.dirty_epoch,
        facts.reconciled_epoch,
        facts.last_success,
    ) else {
        return "unknown";
    };
    if reconciled < dirty {
        return "pending";
    }
    if last_success > now_unix_ms {
        return "unknown";
    }
    if let Some(interval) = facts.interval_unix_ms {
        if now_unix_ms > last_success.saturating_add(interval) {
            return "overdue";
        }
    }
    "current"
}

fn refresh_interval_unix_ms(status: &serde_json::Map<String, serde_json::Value>) -> Option<u128> {
    value_u128(status.get("reconcile_interval_ms"))
}

fn value_u128(value: Option<&serde_json::Value>) -> Option<u128> {
    match value {
        Some(serde_json::Value::Number(value)) => value.as_u64().map(u128::from),
        Some(serde_json::Value::String(value)) => value.parse().ok(),
        _ => None,
    }
}

fn execute_search(
    request: &SearchRequest,
    runtime: &RepoRuntime,
) -> Result<OperationResponse, ApiError> {
    let output_format = request.output_format;
    let options = GraphSearchRequest {
        query: request.query.clone(),
        layer: request.layer.clone(),
        limit: request.limit,
        profile: request.profile.clone(),
        budget: request.budget,
        context_limit: request.context_limit,
        max_depth: request.max_depth,
        detail: request.detail.clone(),
    };
    let results = execute_graph_search(&runtime.db_path, &runtime.manifest_path, &options)
        .map_err(|error| ApiError::new("search_execution_failed", error.to_string()))?;
    let payload = serde_json::json!({
        "query": request.query,
        "layer": request.layer,
        "profile": request.profile,
        "limit": request.limit,
        "budget": request.budget,
        "results": results,
    });
    Ok(OperationResponse::from_payload(
        "search",
        output_format,
        payload,
    ))
}

fn execute_context(
    request: &ContextRequest,
    runtime: &RepoRuntime,
) -> Result<OperationResponse, ApiError> {
    let output_format = request.output_format;
    let search = GraphSearchRequest {
        query: request.query.clone().unwrap_or_default(),
        layer: request.layer.clone(),
        profile: request.profile.clone(),
        limit: request.limit,
        budget: request.budget,
        context_limit: request.context_limit,
        max_depth: request.max_depth,
        detail: request.detail.clone(),
    };
    let payload = if let (Some(node_id), Some(node_type)) =
        (request.node_id.as_ref(), request.node_type.as_ref())
    {
        let context = execute_graph_context(&runtime.db_path, node_id, node_type, &search)
            .map_err(|error| ApiError::new("context_execution_failed", error.to_string()))?;
        json!({
            "node_id": node_id,
            "node_type": node_type,
            "layer": request.layer,
            "profile": request.profile,
            "context": context,
        })
    } else {
        if search.query.is_empty() {
            return Err(ApiError::new(
                "context_validation_failed",
                "query is required",
            ));
        }
        let results = execute_graph_search(&runtime.db_path, &runtime.manifest_path, &search)
            .map_err(|error| ApiError::new("context_execution_failed", error.to_string()))?;
        json!({
            "query": request.query,
            "layer": request.layer,
            "profile": request.profile,
            "limit": request.limit,
            "budget": request.budget,
            "results": results,
        })
    };
    Ok(OperationResponse::from_payload(
        "context",
        output_format,
        payload,
    ))
}

fn execute_query(
    request: &QueryRequest,
    runtime: &RepoRuntime,
) -> Result<OperationResponse, ApiError> {
    validate_read_only_statement(&request.statement)
        .map_err(|error| ApiError::new("query_validation_failed", error.to_string()))?;
    let output_format = request.output_format;
    let parameters = request
        .parameters
        .as_object()
        .expect("normalized query parameters must be an object")
        .clone();
    let (rows, truncated) = execute_read_only_query(
        &runtime.db_path,
        &request.statement,
        &parameters,
        request.limit,
    )
    .map_err(|error| ApiError::new("query_execution_failed", error.to_string()))?;
    let payload = serde_json::json!({
        "statement": request.statement,
        "row_count": rows.len(),
        "rows": rows,
        "truncated": truncated,
    });
    Ok(OperationResponse::from_payload(
        "query",
        output_format,
        payload,
    ))
}

fn execute_materialization(
    request: &MaterializationRequest,
    runtime: &RepoRuntime,
    dry_plan: bool,
) -> Result<OperationResponse, ApiError> {
    if !dry_plan {
        reject_legacy_write_operation(runtime)?;
    }
    let materialize_options = MaterializeOptions::from_request(request, runtime, dry_plan);

    let mut native_request = if let Some(request_path) = request.native_request_path.as_ref() {
        read_request(request_path)
            .map_err(|error| ApiError::new("materialization_request_failed", error))?
    } else {
        build_request(&materialize_options)
            .map_err(|error| ApiError::new("materialization_build_failed", error))?
    };

    let response = if dry_plan {
        native_request.atomic_rebuild = false;
        execute_plan_native(&native_request)
            .map_err(|error| ApiError::new("materialization_plan_failed", error.to_string()))?
    } else {
        execute_materialization_request(&materialize_options, native_request)
            .map(|(_, response)| response)
            .map_err(materialization_api_error)?
    };

    Ok(materialization_operation_response(
        request, runtime, &response, dry_plan,
    ))
}

fn execute_isolated_materialization(
    request: &MaterializationRequest,
    runtime: &RepoRuntime,
    refresh: Option<&RefreshState>,
) -> Result<OperationResponse, ApiError> {
    reject_legacy_write_operation(runtime)?;
    let options = MaterializeOptions::from_request(request, runtime, false);
    let response = execute_explicit_worker(&options, |pid| {
        if let Some(refresh) = refresh {
            refresh.set_worker_pid(pid);
        }
    })
    .map_err(materialization_api_error)?;
    Ok(materialization_operation_response(
        request, runtime, &response, false,
    ))
}

fn materialization_operation_response(
    request: &MaterializationRequest,
    runtime: &RepoRuntime,
    response: &NativeSyntaxMaterializationResponse,
    dry_plan: bool,
) -> OperationResponse {
    let output_format = request.output_format;
    let payload = materialization_payload(request, response, &runtime.manifest_path, dry_plan);
    let mut operation_response = OperationResponse::from_payload(
        if dry_plan { "plan" } else { "materialize" },
        output_format,
        payload,
    );
    operation_response.diagnostics = response.diagnostics.clone();
    operation_response
}

fn materialization_api_error(message: String) -> ApiError {
    let Ok(details) = serde_json::from_str::<serde_json::Value>(&message) else {
        return ApiError::new("materialization_failed", message);
    };
    if details.get("error").and_then(serde_json::Value::as_str) == Some("memory_budget_exceeded") {
        return ApiError::new("memory_budget_exceeded", message)
            .with_details(details)
            .retryable(false);
    }
    ApiError::new("materialization_failed", message)
}

fn execute_plan_native(
    request: &NativeSyntaxMaterializationRequest,
) -> Result<NativeSyntaxMaterializationResponse, NativeError> {
    crate::plan_materialization(request)
}

fn reject_legacy_write_operation(runtime: &RepoRuntime) -> Result<(), ApiError> {
    runtime.require_graph_write().map_err(|message| {
        let remediation = runtime
            .remediation()
            .unwrap_or_else(|| "Run `codebase-graph reinstall`.".to_string());
        ApiError::new("legacy_storage_requires_reinstall", message)
            .with_details(json!({
                "schema_version": runtime.legacy_schema_version().unwrap_or(1),
                "remediation": remediation,
            }))
            .retryable(false)
    })
}

fn physical_database_bytes(runtime: &RepoRuntime) -> u64 {
    if let Some(active_read) = runtime.active_read.as_ref() {
        return active_read.physical_size_bytes;
    }
    if runtime.storage_root.is_some() {
        return physical_bundle_bytes(&runtime.db_path, &runtime.manifest_path);
    }
    physical_bundle_bytes(&runtime.db_path, &runtime.manifest_path)
}

fn logical_database_bytes(runtime: &RepoRuntime) -> u64 {
    if let Some(active_read) = runtime.active_read.as_ref() {
        active_read.logical_size_bytes
    } else {
        logical_bundle_bytes(&runtime.db_path, &runtime.manifest_path)
    }
}

fn physical_bundle_bytes(db_path: &Path, manifest_path: &Path) -> u64 {
    bundle_paths(db_path, manifest_path)
        .into_iter()
        .map(|path| allocated_or_len(&path))
        .sum()
}

fn logical_bundle_bytes(db_path: &Path, manifest_path: &Path) -> u64 {
    bundle_paths(db_path, manifest_path)
        .into_iter()
        .map(|path| file_len(&path))
        .sum()
}

fn bundle_paths(db_path: &Path, manifest_path: &Path) -> Vec<std::path::PathBuf> {
    let mut paths = direct_bundle_paths(db_path);
    paths.push(manifest_path.to_path_buf());
    paths
}

fn file_len(path: &Path) -> u64 {
    fs::symlink_metadata(path)
        .ok()
        .filter(|metadata| !metadata.file_type().is_symlink() && metadata.is_file())
        .map(|metadata| metadata.len())
        .unwrap_or(0)
}

#[cfg(unix)]
fn allocated_or_len(path: &Path) -> u64 {
    use std::os::unix::fs::MetadataExt;

    fs::symlink_metadata(path)
        .ok()
        .filter(|metadata| !metadata.file_type().is_symlink() && metadata.is_file())
        .map(|metadata| {
            let allocated = metadata.blocks().saturating_mul(512);
            if allocated == 0 {
                metadata.len()
            } else {
                allocated
            }
        })
        .unwrap_or(0)
}

#[cfg(not(unix))]
fn allocated_or_len(path: &Path) -> u64 {
    file_len(path)
}

fn materialization_payload(
    request: &MaterializationRequest,
    response: &NativeSyntaxMaterializationResponse,
    manifest_path: &std::path::Path,
    dry_plan: bool,
) -> serde_json::Value {
    if dry_plan {
        plan_materialization_payload(response, &request.mode, manifest_path)
    } else {
        serde_json::to_value(response).unwrap_or_else(|_| json!({}))
    }
}

#[cfg(test)]
mod tests {
    use super::{materialization_api_error, refresh_health_payload};
    use crate::api::contracts::{
        MaterializationRequest, McpInstallRequest, OperationInvocation, OperationRequest,
        OutputFormat, RepoSelector, RepositoryLifecycleRequest,
    };
    use crate::api::core::ApiCore;
    use crate::api::{
        install_mcp_server, McpClientInstallOptions, McpExistingEntryPolicy, McpInstallMode,
        McpServerDescriptor,
    };
    use serde_json::json;
    use std::{fs, path::PathBuf};

    fn unique_temp_dir(prefix: &str) -> PathBuf {
        std::env::temp_dir().join(format!(
            "{prefix}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ))
    }

    #[test]
    fn materialization_memory_failure_preserves_structured_details() {
        let error = materialization_api_error(
            serde_json::json!({
                "error": "memory_budget_exceeded",
                "phase": "staging",
                "limit_bytes": 1024,
                "accounted_bytes": 2048,
                "observed_rss_bytes": 1536,
            })
            .to_string(),
        );

        assert_eq!(error.code, "memory_budget_exceeded");
        assert!(!error.retryable);
        assert_eq!(error.details.unwrap()["phase"], "staging");
    }

    fn write_legacy_install_config(root: &PathBuf) {
        let state = root.join(".codebaseGraph");
        fs::create_dir_all(&state).unwrap();
        fs::write(
            state.join("config.json"),
            serde_json::to_string_pretty(&json!({
                "schema_version": 1,
                "repo_root": root,
                "database_path": state.join("legacy.ldb"),
                "manifest_path": state.join("legacy-manifest.json"),
            }))
            .unwrap(),
        )
        .unwrap();
    }

    #[test]
    fn operation_registry_is_unique_and_sorted() {
        let core = ApiCore::new();
        let operations = core.operations();
        let ids: Vec<_> = operations.iter().map(|entry| entry.id).collect();
        let mut sorted = ids.clone();
        sorted.sort();
        assert_eq!(ids, sorted);
        assert!(ids.iter().all(|id| core.resolve_operation(id).is_some()));
    }

    #[test]
    fn resolve_unknown_operation_is_none() {
        let core = ApiCore::new();
        assert!(core.resolve_operation("_missing_").is_none());
    }

    #[test]
    fn syntax_operation_publishes_the_selected_language_catalog() {
        let response = ApiCore::new()
            .execute_invocation(
                "syntax",
                &OperationInvocation {
                    repo: RepoSelector::default(),
                    arguments: json!({"language": "python"}),
                    output_format: OutputFormat::Typed,
                },
            )
            .expect("syntax operation should load the selected catalog");

        assert_eq!(response.operation, "syntax");
        assert_eq!(response.payload["language"], "python");
        assert_eq!(
            response.payload["grammar_version"],
            "tree_sitter_python@0.25.0"
        );
    }

    #[test]
    fn health_schema_documents_explicit_default_false_quiescence() {
        let descriptor = ApiCore::new()
            .operations()
            .into_iter()
            .find(|descriptor| descriptor.id == "health")
            .unwrap();
        let schema = (descriptor.request_schema)();
        assert_eq!(schema["confirm_legacy_quiescence"]["type"], "boolean");
        assert_eq!(schema["confirm_legacy_quiescence"]["default"], false);
        assert!(schema["confirm_legacy_quiescence"]["description"]
            .as_str()
            .unwrap()
            .contains("stopped and upgraded"));
        let payload =
            super::maintenance_health_payload(&crate::protocol::MaintenanceSummary::default());
        assert!(payload["bytes"]["total"]["allocated_bytes"].is_null());
        assert_eq!(
            payload["reasons"],
            serde_json::json!(["maintenance_not_observed"])
        );
    }

    #[test]
    fn duplicate_operations_are_rejected_in_registration() {
        let core = ApiCore::new();
        let descriptor = core
            .operations()
            .into_iter()
            .find(|descriptor| descriptor.id == "health")
            .expect("health descriptor should exist");
        let result = std::panic::catch_unwind(|| super::build_registry([descriptor, descriptor]));
        assert!(result.is_err());
    }

    #[test]
    fn unknown_operation_request_is_rejected() {
        let core = ApiCore::new();
        let unsupported = OperationRequest::Catalog {
            kind: "_missing_".to_string(),
            group: None,
            output_format: crate::api::contracts::OutputFormat::Typed,
        };
        let error = core
            .execute(&unsupported)
            .expect_err("unknown operation should be rejected");
        assert_eq!(error.code, "unsupported_operation");
        assert!(!error.retryable);
    }

    #[test]
    fn legacy_setup_returns_structured_reinstall_error() {
        let root = unique_temp_dir("codebase-graph-api-legacy-setup");
        fs::create_dir_all(&root).unwrap();
        write_legacy_install_config(&root);

        let error = ApiCore::new()
            .execute(&OperationRequest::Setup(RepositoryLifecycleRequest {
                repo: RepoSelector {
                    repo_root: Some(root.clone()),
                    config_path: None,
                    db_path: None,
                    manifest_path: None,
                },
                action: "setup".to_string(),
                output_format: OutputFormat::Typed,
                dry_run: false,
                mcp_client: Some("none".to_string()),
                agent_hooks: "none".to_string(),
                mcp_config_path: None,
                instructions_target: Some("skip".to_string()),
                skip_mcp_config: true,
                mcp_transport: crate::api::McpTransport::Auto,
                mcp_daemon_port: None,
                mode: "full".to_string(),
                include_fts: false,
            }))
            .expect_err("legacy setup should require reinstall");

        assert_eq!(error.code, "legacy_storage_requires_reinstall");
        assert!(!error.retryable);
        assert!(error
            .message
            .contains("codebase-graph reinstall --repo-root"));
        let details = error
            .details
            .expect("legacy rejection should include details");
        assert_eq!(details["schema_version"], 1);
        assert!(details["remediation"]
            .as_str()
            .unwrap()
            .contains("codebase-graph reinstall --repo-root"));
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn legacy_materialize_rejects_but_plan_is_still_allowed() {
        let root = unique_temp_dir("codebase-graph-api-legacy-plan");
        fs::create_dir_all(&root).unwrap();
        fs::write(root.join("service.py"), "def helper():\n    return 1\n").unwrap();
        write_legacy_install_config(&root);
        let repo = RepoSelector {
            repo_root: Some(root.clone()),
            config_path: None,
            db_path: None,
            manifest_path: None,
        };

        let materialize_error = ApiCore::new()
            .execute(&OperationRequest::Materialize(MaterializationRequest {
                repo: repo.clone(),
                native_request_path: None,
                source_root: None,
                mode: "full".to_string(),
                include_fts: false,
                use_git: false,
                git_diff: false,
                git_base: None,
                include_patterns: Vec::new(),
                exclude_patterns: Vec::new(),
                candidate_paths: Vec::new(),
                parallel: false,
                worker_memory_mib: None,
                rust_memory_mib: None,
                spill_chunk_mib: None,
                max_parallelism: None,
                progress: false,
                output_format: OutputFormat::Typed,
            }))
            .expect_err("legacy materialize should require reinstall");
        assert_eq!(materialize_error.code, "legacy_storage_requires_reinstall");

        let plan = ApiCore::new()
            .execute(&OperationRequest::Plan(MaterializationRequest {
                repo,
                native_request_path: None,
                source_root: None,
                mode: "full".to_string(),
                include_fts: false,
                use_git: false,
                git_diff: false,
                git_base: None,
                include_patterns: Vec::new(),
                exclude_patterns: Vec::new(),
                candidate_paths: Vec::new(),
                parallel: false,
                worker_memory_mib: None,
                rust_memory_mib: None,
                spill_chunk_mib: None,
                max_parallelism: None,
                progress: false,
                output_format: OutputFormat::Typed,
            }))
            .expect("legacy plan should remain readable");
        assert_eq!(plan.operation, "plan");
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn resolve_operation_returns_registered_descriptor_and_handler() {
        let core = ApiCore::new();
        let operation = core
            .resolve_operation("schema")
            .expect("schema should be registered");
        assert_eq!(operation.descriptor.id, "schema");
        let response = (operation.handler)(
            &OperationRequest::Catalog {
                kind: "schema".to_string(),
                group: None,
                output_format: crate::api::contracts::OutputFormat::Typed,
            },
            None,
        )
        .expect("registered schema handler should execute");
        assert_eq!(response.operation, "schema");
    }

    #[test]
    fn resolve_mcp_operation_uses_registered_operation_metadata() {
        let core = ApiCore::new();
        let operation = core
            .resolve_mcp_operation("graph_search")
            .expect("registered MCP operation should resolve");
        assert_eq!(operation.id, "search");
        assert!(core.resolve_mcp_operation("graph_missing").is_none());
    }

    #[test]
    fn mcp_install_operation_preserves_unrelated_client_configuration() {
        let root = unique_temp_dir("codebase-graph-api-mcp-install");
        let client_config = root.join("client").join("mcp.json");
        fs::create_dir_all(client_config.parent().unwrap()).unwrap();
        fs::write(
            &client_config,
            serde_json::to_string_pretty(&json!({
                "mcpServers": {
                    "unrelated": {"command": "keep", "args": []}
                }
            }))
            .unwrap(),
        )
        .unwrap();

        let response = ApiCore::new()
            .execute(&OperationRequest::InstallMcp(McpInstallRequest {
                repo: RepoSelector {
                    repo_root: Some(root.clone()),
                    config_path: None,
                    db_path: None,
                    manifest_path: None,
                },
                client: "generic".to_string(),
                scope: "local".to_string(),
                name: Some("codebase_graph_test".to_string()),
                client_config_path: Some(client_config.clone()),
                agent_hooks: "none".to_string(),
                dry_run: false,
                transport: crate::api::McpTransport::Stdio,
                daemon_port: None,
                output_format: OutputFormat::Typed,
            }))
            .expect("API MCP install should succeed");

        assert_eq!(response.operation, "mcp-install");
        assert_eq!(response.payload["action"], "updated");
        let payload: serde_json::Value =
            serde_json::from_str(&fs::read_to_string(&client_config).unwrap()).unwrap();
        assert_eq!(payload["mcpServers"]["unrelated"]["command"], "keep");
        assert_eq!(
            payload["mcpServers"]["codebase_graph_test"]["command"],
            "codebase-graph"
        );
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn generic_mcp_server_registration_preserves_configuration_with_short_arguments() {
        let root = unique_temp_dir("codebase-graph-generic-mcp-server");
        let client_config = root.join("client").join("mcp.json");
        fs::create_dir_all(client_config.parent().unwrap()).unwrap();
        fs::write(
            &client_config,
            serde_json::to_string_pretty(&json!({
                "mcpServers": {
                    "unrelated": {"command": "keep", "args": []}
                }
            }))
            .unwrap(),
        )
        .unwrap();
        let knowledge = root.join("knowledge");
        let descriptor = McpServerDescriptor {
            name: "k_wiki_test".to_string(),
            command: "k-wiki".to_string(),
            args: vec!["mcp".to_string(), knowledge.to_string_lossy().to_string()],
            repo_root: root.clone(),
            timeout: 60,
            setup_config_path: None,
            tool_policy: Some("knowledge_wiki".to_string()),
            manual_http_metadata: None,
        };
        let options = McpClientInstallOptions {
            client: "generic".to_string(),
            scope: "local".to_string(),
            client_config_path: Some(client_config.clone()),
            dry_run: false,
            install_method: McpInstallMode::Auto,
            existing_entry_policy: McpExistingEntryPolicy::Replace,
            legacy_server_names: Vec::new(),
        };

        let response = install_mcp_server(&descriptor, &options).expect("register MCP server");
        assert_eq!(response["action"], "updated");
        let payload: serde_json::Value =
            serde_json::from_str(&fs::read_to_string(&client_config).unwrap()).unwrap();
        assert_eq!(payload["mcpServers"]["unrelated"]["command"], "keep");
        assert_eq!(payload["mcpServers"]["k_wiki_test"]["command"], "k-wiki");
        assert_eq!(
            payload["mcpServers"]["k_wiki_test"]["args"],
            json!(["mcp", knowledge.to_string_lossy().to_string()])
        );

        let repeat = install_mcp_server(&descriptor, &options).expect("reuse MCP registration");
        assert_eq!(repeat["action"], "unchanged");
        let _ = fs::remove_dir_all(root);
    }

    fn refresh_status_for_health_test() -> serde_json::Value {
        json!({
            "enabled": true,
            "task_alive": true,
            "state": "running",
            "effective_root": "/tmp/repo",
            "pending": false,
            "last_successful_reconciliation_unix_ms": 1_000,
            "oldest_pending_unix_ms": null,
            "next_retry_unix_ms": null,
            "dirty_epoch": 4,
            "reconciled_epoch": 4,
            "last_error": null,
        })
    }

    #[test]
    fn refresh_health_classification_requires_live_acknowledged_reconciliation() {
        let healthy = refresh_status_for_health_test();
        let summary = refresh_health_payload(Some(&healthy), true, 1_100);
        assert_eq!(summary["freshness"], "current");
        assert_eq!(summary["readiness"], "ready");

        let mut pending = healthy.clone();
        pending["dirty_epoch"] = json!(5);
        pending["pending"] = json!(false);
        let summary = refresh_health_payload(Some(&pending), true, 1_100);
        assert_eq!(summary["freshness"], "pending");
        assert_eq!(summary["pending"], true);

        let mut overdue = healthy.clone();
        overdue["reconcile_interval_ms"] = json!(50);
        let summary = refresh_health_payload(Some(&overdue), true, 1_100);
        assert_eq!(summary["freshness"], "overdue");

        let mut disabled = healthy;
        disabled["enabled"] = json!(false);
        disabled["state"] = json!("disabled");
        disabled["task_alive"] = json!(false);
        let summary = refresh_health_payload(Some(&disabled), true, 1_100);
        assert_eq!(summary["freshness"], "unknown");
        assert_eq!(summary["readiness"], "disabled");

        let summary = refresh_health_payload(None, true, 1_100);
        assert_eq!(summary["freshness"], "unknown");
        assert_eq!(summary["readiness"], "unknown");

        let mut standby = refresh_status_for_health_test();
        standby["state"] = json!("standby");
        let summary = refresh_health_payload(Some(&standby), true, 1_100);
        assert_eq!(summary["freshness"], "unknown");
        assert_eq!(summary["readiness"], "standby");

        let summary = refresh_health_payload(Some(&refresh_status_for_health_test()), false, 1_100);
        assert_eq!(summary["freshness"], "unknown");

        let mut future = refresh_status_for_health_test();
        future["last_successful_reconciliation_unix_ms"] = json!(2_000);
        let summary = refresh_health_payload(Some(&future), true, 1_100);
        assert_eq!(summary["freshness"], "unknown");
    }
}
