use crate::adapters::{
    cli::{
        format::{graph_health_help, graph_query_help, graph_search_help, metadata_help},
        util::parse_usize_arg,
    },
    required_arg,
};
use std::path::PathBuf;

#[derive(Debug)]
pub(crate) struct HealthOptions {
    pub(crate) confirm_legacy_quiescence: bool,
    pub(crate) repo_root: Option<PathBuf>,
    pub(crate) config: Option<PathBuf>,
    pub(crate) db: Option<PathBuf>,
    pub(crate) manifest: Option<PathBuf>,
    pub(crate) help: bool,
    pub(crate) json: bool,
}

impl HealthOptions {
    pub(crate) fn parse(args: &[String]) -> Result<Self, String> {
        let mut options = Self {
            confirm_legacy_quiescence: false,
            repo_root: None,
            config: None,
            db: None,
            manifest: None,
            help: false,
            json: false,
        };
        let mut index = 0;
        while index < args.len() {
            match args[index].as_str() {
                "-h" | "--help" => {
                    options.help = true;
                    index += 1;
                }
                "--repo-root" | "--source-root" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--repo-root requires a path".to_string())?;
                    options.repo_root = Some(PathBuf::from(value));
                    index += 2;
                }
                "--config" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--config requires a path".to_string())?;
                    options.config = Some(PathBuf::from(value));
                    index += 2;
                }
                "--db" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--db requires a path".to_string())?;
                    options.db = Some(PathBuf::from(value));
                    index += 2;
                }
                "--manifest" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--manifest requires a path".to_string())?;
                    options.manifest = Some(PathBuf::from(value));
                    index += 2;
                }
                "--confirm-legacy-quiescence" => {
                    options.confirm_legacy_quiescence = true;
                    index += 1;
                }
                "--json" => {
                    options.json = true;
                    index += 1;
                }
                other => {
                    return Err(format!(
                        "unknown check-health option: {other}\n\n{}",
                        graph_health_help()
                    ));
                }
            }
        }
        Ok(options)
    }
}

#[derive(Debug)]
pub(crate) struct GraphQueryOptions {
    pub(crate) statement: String,
    pub(crate) parameters: serde_json::Map<String, serde_json::Value>,
    pub(crate) limit: usize,
    pub(crate) repo_root: Option<PathBuf>,
    pub(crate) config: Option<PathBuf>,
    pub(crate) db: Option<PathBuf>,
    pub(crate) manifest: Option<PathBuf>,
    pub(crate) help: bool,
    pub(crate) json: bool,
}

impl GraphQueryOptions {
    pub(crate) fn parse(args: &[String]) -> Result<Self, String> {
        let mut statement = None;
        let mut parameters = serde_json::Map::new();
        let mut limit = 100_usize;
        let mut repo_root = None;
        let mut config = None;
        let mut db = None;
        let mut manifest = None;
        let mut help = false;
        let mut json = false;
        let mut index = 0;
        while index < args.len() {
            match args[index].as_str() {
                "-h" | "--help" => {
                    help = true;
                    index += 1;
                }
                "--parameters" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--parameters requires a JSON object".to_string())?;
                    let parsed: serde_json::Value =
                        serde_json::from_str(value).map_err(|error| {
                            format!("graph-query --parameters must be a JSON object: {error}")
                        })?;
                    parameters = parsed.as_object().cloned().ok_or_else(|| {
                        "graph-query --parameters must be a JSON object".to_string()
                    })?;
                    index += 2;
                }
                "--limit" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--limit requires an integer".to_string())?;
                    limit = value
                        .parse::<usize>()
                        .map_err(|error| format!("--limit must be an integer: {error}"))?;
                    index += 2;
                }
                "--repo-root" | "--source-root" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--repo-root requires a path".to_string())?;
                    repo_root = Some(PathBuf::from(value));
                    index += 2;
                }
                "--config" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--config requires a path".to_string())?;
                    config = Some(PathBuf::from(value));
                    index += 2;
                }
                "--db" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--db requires a path".to_string())?;
                    db = Some(PathBuf::from(value));
                    index += 2;
                }
                "--manifest" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--manifest requires a path".to_string())?;
                    manifest = Some(PathBuf::from(value));
                    index += 2;
                }
                "--json" => {
                    json = true;
                    index += 1;
                }
                "--pretty" => {
                    index += 1;
                }
                "--output-format" | "--format" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--output-format requires json or block".to_string())?;
                    if value != "json" && value != "block" {
                        return Err("--output-format must be json or block".to_string());
                    }
                    json = value == "json";
                    index += 2;
                }
                "--context" | "--output" => {
                    if args.get(index + 1).is_some() {
                        index += 2;
                    } else {
                        return Err(format!("{} requires a value", args[index]));
                    }
                }
                other if other.starts_with('-') => {
                    return Err(format!(
                        "unknown graph-query option: {other}\n\n{}",
                        graph_query_help()
                    ));
                }
                value => {
                    if statement.is_some() {
                        return Err("graph-query accepts exactly one statement".to_string());
                    }
                    statement = Some(value.to_string());
                    index += 1;
                }
            }
        }
        if help {
            return Ok(Self {
                statement: String::new(),
                parameters,
                limit,
                repo_root,
                config,
                db,
                manifest,
                help,
                json,
            });
        }
        let statement = statement.unwrap_or_default();
        Ok(Self {
            statement,
            parameters,
            limit,
            repo_root,
            config,
            db,
            manifest,
            help,
            json,
        })
    }
}

#[derive(Debug)]
pub(crate) struct MetadataOutputOptions {
    pub(crate) format: String,
    pub(crate) pretty: bool,
    pub(crate) help: bool,
}

impl MetadataOutputOptions {
    pub(crate) fn parse(args: &[String], command_name: &str) -> Result<Self, String> {
        let mut options = Self {
            format: "block".to_string(),
            pretty: false,
            help: false,
        };
        let mut index = 0;
        while index < args.len() {
            match args[index].as_str() {
                "-h" | "--help" => {
                    options.help = true;
                    index += 1;
                }
                "--format" | "--output-format" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--format requires json or block".to_string())?;
                    if value != "json" && value != "block" {
                        return Err("--format must be json or block".to_string());
                    }
                    options.format = value.clone();
                    index += 2;
                }
                "--json" => {
                    options.format = "json".to_string();
                    index += 1;
                }
                "--pretty" => {
                    options.pretty = true;
                    index += 1;
                }
                other => {
                    return Err(format!(
                        "unknown {command_name} option: {other}\n\n{}",
                        metadata_help(command_name)
                    ));
                }
            }
        }
        Ok(options)
    }
}

#[derive(Debug)]
pub(crate) struct ArchitectureQueryOptions {
    pub(in crate::adapters::cli) output: MetadataOutputOptions,
    pub(in crate::adapters::cli) group: Option<String>,
}

impl ArchitectureQueryOptions {
    pub(in crate::adapters::cli) fn parse(args: &[String]) -> Result<Self, String> {
        let mut metadata_args = Vec::new();
        let mut group = None;
        let mut index = 0;
        while index < args.len() {
            match args[index].as_str() {
                "--group" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--group requires a group name".to_string())?;
                    group = Some(value.clone());
                    index += 2;
                }
                _ => {
                    metadata_args.push(args[index].clone());
                    index += 1;
                }
            }
        }
        Ok(Self {
            output: MetadataOutputOptions::parse(&metadata_args, "codebase-architecture-queries")?,
            group,
        })
    }
}

#[derive(Debug)]
pub(crate) struct SyntaxCatalogOptions {
    pub(in crate::adapters::cli) language: String,
    pub(in crate::adapters::cli) output: MetadataOutputOptions,
}

impl SyntaxCatalogOptions {
    pub(in crate::adapters::cli) fn parse(args: &[String]) -> Result<Self, String> {
        let mut language = None;
        let mut format = "block".to_string();
        let mut pretty = false;
        let mut help = false;
        let mut index = 0;
        while index < args.len() {
            match args[index].as_str() {
                "-h" | "--help" => {
                    help = true;
                    index += 1;
                }
                "--format" | "--output-format" => {
                    let value = args
                        .get(index + 1)
                        .ok_or_else(|| "--format requires json or block".to_string())?;
                    if value != "json" && value != "block" {
                        return Err("--format must be json or block".to_string());
                    }
                    format = value.clone();
                    index += 2;
                }
                "--json" => {
                    format = "json".to_string();
                    index += 1;
                }
                "--pretty" => {
                    pretty = true;
                    index += 1;
                }
                other if other.starts_with('-') => {
                    return Err(format!(
                        "unknown syntax option: {other}\n\n{}",
                        super::super::format::graph_syntax_help()
                    ));
                }
                value => {
                    if language.replace(value.to_string()).is_some() {
                        return Err("syntax accepts exactly one language".to_string());
                    }
                    index += 1;
                }
            }
        }
        if !help && language.is_none() {
            return Err(format!(
                "syntax requires a language\n\n{}",
                super::super::format::graph_syntax_help()
            ));
        }
        Ok(Self {
            language: language.unwrap_or_default(),
            output: MetadataOutputOptions {
                format,
                pretty,
                help,
            },
        })
    }
}

#[derive(Debug)]
pub(crate) struct GraphSearchOptions {
    pub(crate) query: String,
    pub(crate) layer: String,
    pub(crate) limit: usize,
    pub(crate) profile: String,
    pub(crate) budget: usize,
    pub(crate) context_limit: usize,
    pub(crate) max_depth: Option<usize>,
    pub(crate) detail: String,
    pub(crate) repo_root: Option<PathBuf>,
    pub(crate) config: Option<PathBuf>,
    pub(crate) db: Option<PathBuf>,
    pub(crate) manifest: Option<PathBuf>,
    pub(crate) output: MetadataOutputOptions,
}

impl GraphSearchOptions {
    pub(crate) fn parse(args: &[String]) -> Result<Self, String> {
        let mut query = None;
        let mut layer = "semantic".to_string();
        let mut limit = 3_usize;
        let mut profile = "brief".to_string();
        let mut budget = 600_usize;
        let mut context_limit = 3_usize;
        let mut max_depth = None;
        let mut detail = "standard".to_string();
        let mut repo_root = None;
        let mut config = None;
        let mut db = None;
        let mut manifest = None;
        let mut output_args = Vec::new();
        let mut index = 0;
        while index < args.len() {
            match args[index].as_str() {
                "-h" | "--help" | "--json" | "--pretty" | "--format" | "--output-format" => {
                    output_args.push(args[index].clone());
                    if matches!(args[index].as_str(), "--format" | "--output-format") {
                        if let Some(value) = args.get(index + 1) {
                            output_args.push(value.clone());
                        }
                        index += 2;
                    } else {
                        index += 1;
                    }
                }
                "--limit" => {
                    limit = parse_usize_arg(args, index, "--limit")?;
                    index += 2;
                }
                "--layer" => {
                    layer = required_arg(args, index, "--layer")?.to_string();
                    index += 2;
                }
                "--profile" => {
                    profile = required_arg(args, index, "--profile")?.to_string();
                    index += 2;
                }
                "--budget" => {
                    budget = parse_usize_arg(args, index, "--budget")?;
                    index += 2;
                }
                "--context-limit" => {
                    context_limit = parse_usize_arg(args, index, "--context-limit")?;
                    index += 2;
                }
                "--max-depth" => {
                    max_depth = Some(parse_usize_arg(args, index, "--max-depth")?);
                    index += 2;
                }
                "--snippet-context-lines" => {
                    let _ = required_arg(args, index, args[index].as_str())?;
                    index += 2;
                }
                "--include-snippets" => {
                    index += 1;
                }
                "--no-semantic" => {
                    index += 1;
                }
                "--no-confidence" => {
                    index += 1;
                }
                "--include-evidence" => {
                    index += 1;
                }
                "--detail" => {
                    let value = required_arg(args, index, "--detail")?;
                    detail = value.to_string();
                    index += 2;
                }
                "--repo-root" | "--source-root" => {
                    repo_root = Some(PathBuf::from(required_arg(args, index, "--repo-root")?));
                    index += 2;
                }
                "--config" => {
                    config = Some(PathBuf::from(required_arg(args, index, "--config")?));
                    index += 2;
                }
                "--db" => {
                    db = Some(PathBuf::from(required_arg(args, index, "--db")?));
                    index += 2;
                }
                "--manifest" => {
                    manifest = Some(PathBuf::from(required_arg(args, index, "--manifest")?));
                    index += 2;
                }
                "--no-refresh" | "--include-structured-content" => {
                    index += 1;
                }
                "--context" | "--output" => {
                    let _ = required_arg(args, index, args[index].as_str())?;
                    index += 2;
                }
                other if other.starts_with('-') => {
                    return Err(format!(
                        "unknown codebase-search option: {other}\n\n{}",
                        graph_search_help()
                    ));
                }
                value => {
                    if query.is_some() {
                        return Err("codebase-search accepts exactly one query".to_string());
                    }
                    query = Some(value.to_string());
                    index += 1;
                }
            }
        }
        let output = MetadataOutputOptions::parse(&output_args, "codebase-search")?;
        if output.help {
            return Ok(Self {
                query: String::new(),
                layer,
                limit,
                profile,
                budget,
                context_limit,
                max_depth,
                detail,
                repo_root,
                config,
                db,
                manifest,
                output,
            });
        }
        let query = query.unwrap_or_default();
        Ok(Self {
            query,
            layer,
            limit,
            profile,
            budget,
            context_limit,
            max_depth,
            detail,
            repo_root,
            config,
            db,
            manifest,
            output,
        })
    }
}

#[derive(Debug)]
pub(crate) struct GraphContextOptions {
    pub(in crate::adapters::cli) search: GraphSearchOptions,
    pub(in crate::adapters::cli) node_id: Option<String>,
    pub(in crate::adapters::cli) node_type: Option<String>,
}

impl GraphContextOptions {
    pub(in crate::adapters::cli) fn parse(args: &[String]) -> Result<Self, String> {
        let mut search_args = Vec::new();
        let mut node_id = None;
        let mut node_type = None;
        let mut index = 0;
        while index < args.len() {
            match args[index].as_str() {
                "--node-id" => {
                    node_id = Some(required_arg(args, index, "--node-id")?.to_string());
                    index += 2;
                }
                "--node-type" => {
                    node_type = Some(required_arg(args, index, "--node-type")?.to_string());
                    index += 2;
                }
                other => {
                    search_args.push(other.to_string());
                    index += 1;
                }
            }
        }
        let mut search = GraphSearchOptions::parse(&search_args)?;
        if node_id.is_some() && node_type.is_some() {
            search.query.clear();
        }
        Ok(Self {
            search,
            node_id,
            node_type,
        })
    }
}

#[cfg(test)]
mod maintenance_tests {
    use super::HealthOptions;

    #[test]
    fn health_quiescence_confirmation_is_opt_in_and_documented() {
        assert!(!HealthOptions::parse(&[]).unwrap().confirm_legacy_quiescence);
        let arguments = vec!["--confirm-legacy-quiescence".into(), "--json".into()];
        let options = HealthOptions::parse(&arguments).unwrap();
        assert!(options.confirm_legacy_quiescence);
        assert!(options.json);
        let help = crate::adapters::cli::format::graph_health_help();
        assert!(help.contains("--confirm-legacy-quiescence"));
        assert!(help.contains("stopped and upgraded"));
        assert!(HealthOptions::parse(&["--confirm-legacy-quiescence=true".into()]).is_err());
    }
}
