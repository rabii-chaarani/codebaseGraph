use super::*;
use super::{materialization_input::*, watch::*};
use crate::adapters::mcp::*;
use notify::{Event, EventKind};
use serde_json::json;
use std::{
    collections::{BTreeMap, BTreeSet, VecDeque},
    env, fs,
    path::{Path, PathBuf},
    process::Command,
    sync::mpsc,
    time::{Duration, Instant},
};

mod dispatch_materialize;
mod fixtures;
mod graph;
mod install;
mod mcp;
mod watch;

use fixtures::*;
