use super::McpInstallOptions;
use crate::agent_hooks::{resolve_agent_hook_clients, verify_agent_hooks};
use crate::api::CodebaseGraphApi;
use crate::daemon_service::{repository_fingerprint, verify_daemon_endpoint};
use serde_json::json;
use std::{
    collections::{BTreeMap, BTreeSet},
    env,
    io::Write,
    path::Path,
    process::Command,
};

pub(in crate::adapters::cli) fn attach_install_verification(
    mut payload: serde_json::Value,
    options: &McpInstallOptions,
) -> serde_json::Value {
    if !options.verify || options.dry_run {
        return payload;
    }
    if let Some(results) = payload
        .get_mut("results")
        .and_then(serde_json::Value::as_array_mut)
    {
        for result in results {
            attach_result_verification(result, options);
        }
    } else {
        attach_result_verification(&mut payload, options);
    }
    payload
}

fn attach_result_verification(result: &mut serde_json::Value, options: &McpInstallOptions) {
    if result.get("error").is_some() {
        return;
    }
    let client = result
        .get("client")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("generic")
        .to_string();
    let descriptor = result.get("descriptor").cloned().unwrap_or_default();
    result["verification"] = verify_mcp_install(&descriptor, &client);
    result["agent_hooks_verification"] =
        verify_agent_hooks_for_install(&descriptor, &client, options);
}

fn verify_agent_hooks_for_install(
    descriptor: &serde_json::Value,
    client: &str,
    options: &McpInstallOptions,
) -> serde_json::Value {
    let selection = options.agent_hooks.as_str();
    let clients = match resolve_agent_hook_clients(selection, client) {
        Ok(clients) => clients,
        Err(error) => return json!({"ok": false, "error": error}),
    };
    if clients.is_empty() {
        return json!({
            "ok": true,
            "action": "not_applicable",
            "selection": selection,
            "clients": [],
        });
    }
    let Some(config) = descriptor
        .get("setup_config_path")
        .and_then(serde_json::Value::as_str)
    else {
        return json!({
            "ok": false,
            "action": "not_applicable",
            "selection": selection,
            "error": "install response did not contain a setup config path",
        });
    };
    let Some(root) = descriptor
        .get("repo_root")
        .and_then(serde_json::Value::as_str)
    else {
        return json!({
            "ok": false,
            "action": "not_applicable",
            "selection": selection,
            "error": "install response did not contain a repository root",
        });
    };
    match verify_agent_hooks(
        std::path::Path::new(root),
        std::path::Path::new(config),
        &clients,
    ) {
        Ok(payload) => payload,
        Err(error) => json!({"ok": false, "selection": selection, "error": error}),
    }
}

pub(in crate::adapters::cli) fn verify_mcp_install(
    descriptor: &serde_json::Value,
    client: &str,
) -> serde_json::Value {
    if descriptor
        .get("transport")
        .and_then(serde_json::Value::as_str)
        == Some("streamable_http")
    {
        let endpoint = descriptor
            .get("url")
            .and_then(serde_json::Value::as_str)
            .unwrap_or_default();
        let fingerprint = descriptor
            .get("repo_root")
            .and_then(serde_json::Value::as_str)
            .map(Path::new)
            .map(repository_fingerprint);
        let http = match verify_daemon_endpoint(endpoint, fingerprint.as_deref()) {
            Ok(payload) => payload,
            Err(error) => json!({"ok": false, "endpoint": endpoint, "error": error}),
        };
        let server_name = descriptor
            .get("name")
            .and_then(serde_json::Value::as_str)
            .unwrap_or_default();
        let visibility = verify_client_visibility(client, server_name);
        return json!({
            "ok": http.get("ok").and_then(serde_json::Value::as_bool).unwrap_or(false)
                && visibility.get("ok").and_then(serde_json::Value::as_bool).unwrap_or(true),
            "http": http,
            "client_visibility": visibility,
        });
    }
    let stdio = verify_stdio(descriptor);
    let server_name = descriptor
        .get("name")
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default();
    let visibility = verify_client_visibility(client, server_name);
    json!({
        "ok": stdio.get("ok").and_then(serde_json::Value::as_bool).unwrap_or(false)
            && visibility.get("ok").and_then(serde_json::Value::as_bool).unwrap_or(true),
        "stdio": stdio,
        "client_visibility": visibility,
    })
}

pub(in crate::adapters::cli) fn verify_stdio(descriptor: &serde_json::Value) -> serde_json::Value {
    let Some(command) = descriptor_command(descriptor) else {
        return json!({"ok": false, "error": "install response did not contain a valid descriptor"});
    };
    let descriptor_name = descriptor
        .get("name")
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default();
    let payload = [
        stdio_json_rpc_message(
            "initialize",
            json!({"protocolVersion": CodebaseGraphApi::latest_mcp_protocol_version()}),
            1,
        ),
        stdio_json_rpc_message("tools/list", json!({}), 2),
        stdio_json_rpc_message(
            "tools/call",
            json!({"name": "graph_health", "arguments": {"include_structured_content": true}}),
            3,
        ),
        stdio_json_rpc_message(
            "tools/call",
            json!({"name": "graph_search", "arguments": {"query": descriptor_name, "limit": 1}}),
            4,
        ),
        stdio_json_rpc_message(
            "tools/call",
            json!({"name": "graph_query", "arguments": {"statement": "MATCH (n) DELETE n"}}),
            5,
        ),
    ]
    .join("");
    let mut process = match Command::new(&command[0])
        .args(&command[1..])
        .stdin(std::process::Stdio::piped())
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
    {
        Ok(process) => process,
        Err(error) => return json!({"ok": false, "command": command, "error": error.to_string()}),
    };
    if let Some(mut stdin) = process.stdin.take() {
        if let Err(error) = stdin.write_all(payload.as_bytes()) {
            return json!({"ok": false, "command": command, "error": error.to_string()});
        }
    }
    let output = match process.wait_with_output() {
        Ok(output) => output,
        Err(error) => return json!({"ok": false, "command": command, "error": error.to_string()}),
    };
    let responses = parse_stdio_json_lines(&output.stdout);
    if !output.status.success() {
        return json!({
            "ok": false,
            "command": command,
            "returncode": output.status.code().unwrap_or(1),
            "stderr": String::from_utf8_lossy(&output.stderr).to_string(),
            "responses": responses,
        });
    }
    let checks = stdio_checks(&responses);
    json!({
        "ok": checks.values().all(|value| *value),
        "command": command,
        "checks": checks,
        "responses": responses,
        "stderr": String::from_utf8_lossy(&output.stderr).to_string(),
    })
}

pub(in crate::adapters::cli) fn verify_client_visibility(
    client: &str,
    server_name: &str,
) -> serde_json::Value {
    let Some(command) = visibility_command(client) else {
        return json!({"ok": true, "skipped": true, "reason": format!("{client} has no CLI visibility check")});
    };
    if !executable_in_path(&command[0]) {
        return json!({"ok": true, "skipped": true, "reason": format!("{} executable not found", command[0])});
    }
    match Command::new(&command[0]).args(&command[1..]).output() {
        Ok(output) => {
            let stdout = String::from_utf8_lossy(&output.stdout).to_string();
            let stderr = String::from_utf8_lossy(&output.stderr).to_string();
            let found = stdout.contains(server_name) || stderr.contains(server_name);
            json!({
                "ok": output.status.success() && found,
                "command": command,
                "returncode": output.status.code().unwrap_or(1),
                "found": found,
                "stdout": stdout,
                "stderr": stderr,
            })
        }
        Err(error) => json!({"ok": false, "command": command, "error": error.to_string()}),
    }
}

pub(in crate::adapters::cli) fn descriptor_command(
    descriptor: &serde_json::Value,
) -> Option<Vec<String>> {
    let mut command = vec![descriptor.get("command")?.as_str()?.to_string()];
    command.extend(
        descriptor
            .get("args")?
            .as_array()?
            .iter()
            .map(|value| value.as_str().map(str::to_string))
            .collect::<Option<Vec<_>>>()?,
    );
    Some(command)
}

pub(in crate::adapters::cli) fn stdio_json_rpc_message(
    method: &str,
    params: serde_json::Value,
    id: u64,
) -> String {
    serde_json::to_string(&json!({
        "jsonrpc": "2.0",
        "id": id,
        "method": method,
        "params": params,
    }))
    .unwrap_or_else(|_| "{}".to_string())
        + "\n"
}

pub(in crate::adapters::cli) fn parse_stdio_json_lines(data: &[u8]) -> Vec<serde_json::Value> {
    String::from_utf8_lossy(data)
        .lines()
        .filter_map(|line| serde_json::from_str::<serde_json::Value>(line).ok())
        .collect()
}

pub(in crate::adapters::cli) fn stdio_checks(
    responses: &[serde_json::Value],
) -> BTreeMap<String, bool> {
    let mut by_id = BTreeMap::new();
    for response in responses {
        if let Some(id) = response.get("id").and_then(serde_json::Value::as_u64) {
            by_id.insert(id, response);
        }
    }
    let tools = by_id
        .get(&2)
        .and_then(|value| value.pointer("/result/tools"))
        .and_then(serde_json::Value::as_array)
        .cloned()
        .unwrap_or_default();
    let tool_names = tools
        .iter()
        .filter_map(|tool| tool.get("name").and_then(serde_json::Value::as_str))
        .collect::<BTreeSet<_>>();
    let mut checks = BTreeMap::new();
    checks.insert(
        "initialize".to_string(),
        by_id
            .get(&1)
            .and_then(|value| value.pointer("/result/protocolVersion"))
            .and_then(serde_json::Value::as_str)
            == Some(CodebaseGraphApi::latest_mcp_protocol_version()),
    );
    checks.insert(
        "tools_list".to_string(),
        tool_names.contains("graph_health") && tool_names.contains("graph_search"),
    );
    checks.insert(
        "graph_health".to_string(),
        by_id
            .get(&3)
            .and_then(|value| value.pointer("/result/structuredContent/ok"))
            .and_then(serde_json::Value::as_bool)
            == Some(true),
    );
    checks.insert(
        "graph_search".to_string(),
        by_id
            .get(&4)
            .is_some_and(|value| value.get("error").is_none()),
    );
    checks.insert(
        "tool_error_result".to_string(),
        by_id
            .get(&5)
            .and_then(|value| value.pointer("/result/isError"))
            .and_then(serde_json::Value::as_bool)
            == Some(true),
    );
    checks
}

pub(in crate::adapters::cli) fn visibility_command(client: &str) -> Option<Vec<String>> {
    match client {
        "codex" => Some(vec![
            "codex".to_string(),
            "mcp".to_string(),
            "list".to_string(),
        ]),
        "claude" | "claude-project" => Some(vec![
            "claude".to_string(),
            "mcp".to_string(),
            "list".to_string(),
        ]),
        "openclaw" => Some(vec![
            "openclaw".to_string(),
            "mcp".to_string(),
            "list".to_string(),
        ]),
        _ => None,
    }
}

fn executable_in_path(executable: &str) -> bool {
    let path = Path::new(executable);
    if path.components().count() > 1 {
        return path.is_file();
    }
    env::var_os("PATH")
        .map(|paths| env::split_paths(&paths).any(|dir| dir.join(executable).is_file()))
        .unwrap_or(false)
}
