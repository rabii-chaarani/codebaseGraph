# Knowledge Wiki

`k-wiki` turns one or more Open Knowledge Format (OKF) 0.1 bundles into a
safe, searchable, deterministic repository wiki. Source Markdown remains the
canonical record; generated state is disposable and lives under `.kwiki/`.

## Trust boundary

The service reads only configured bundle roots. Its three authoring operations
create bundles, create concept pages, and populate existing pages beneath those
roots. They reject absolute paths, traversal, escaping symlinks, reserved-file
misuse, stale revisions, and existing destinations. Browser routes are
read-only. Remote HTTP binding, arbitrary file editing, Git operations, and
multi-user authorization are not part of this release.

Graph context is optional. When enabled, the wiki calls only the public
`CodebaseGraphApi` search, context, and health operations. Graph failures
degrade related context without blocking concept reading or publication.

## Source layout

An OKF bundle is a directory whose root `index.md` declares `okf_version`.
Every other non-reserved Markdown file is a concept whose stable ID is its
bundle-relative path without `.md`.

- `index.md` describes its directory and never becomes a concept.
- `log.md` contributes scoped dated history and never becomes a concept.
- A concept requires YAML frontmatter containing a non-empty `type`.
- Unknown types and unknown frontmatter fields remain consumable.

## Commands

```text
k-wiki validate <bundle> [--profile consume|conformant|recommended] [--json]
k-wiki install [--repo-root <directory>]
k-wiki build <bundle> --out <directory> [--base-url <path>]
k-wiki serve <bundle> [--host 127.0.0.1] [--port 4321]
k-wiki inspect <bundle> --concept <concept-id>
k-wiki check-links <bundle> [--include-external]
k-wiki mcp install --client <client> [--repo-root <directory>] [--scope local|user|project] [--name <name>] [--client-config-path <path>] [--dry-run] [--verify]
k-wiki mcp [bundle]
k-wiki --version
```

`serve` binds to the local machine by default and refuses remote hosts.
Generated HTTP responses include restrictive content, framing, referrer, MIME,
and cache policies.

`install` creates a conformant starter source bundle at `knowledge/index.md`
and initializes the repository-local `.kwiki/` state layout. It defaults to the
current directory and accepts `--repo-root` for another repository. The starter
bundle remains separate from generated state and can be passed to the remaining
commands. It also creates or updates a managed MCP-only k-wiki workflow block
in both `AGENTS.md` and `CLAUDE.md`, preserving all instructions outside the
`<!-- k-wiki:start -->` and `<!-- k-wiki:end -->` markers.

## MCP client registration

After bootstrapping the repository, register the wiki's stdio server with a
chosen MCP client:

```text
k-wiki mcp install --client <client> [--repo-root <directory>] [--scope local|user|project] [--name <name>] [--client-config-path <path>] [--dry-run] [--verify]
```

`--client` is required and accepts `codex`, `claude`, `claude-project`,
`github-copilot`, `lmstudio`, `hermes`, `openclaw`, `generic`,
`copilot-studio`, `microsoft-copilot`, or `all`. The command resolves the
canonical `knowledge/` bundle and records `k-wiki mcp <absolute-bundle-path>`
with the client. Target locality depends on both client and scope:

- Codex `local`/`project`, Claude project and `claude-project`, generic
  `project`, and GitHub Copilot are `repository_local`.
- Codex `user`, Claude `user`/`local`, generic `user`/`local`, LM Studio,
  Hermes, and OpenClaw are `shared`.
- Copilot Studio and Microsoft Copilot are `manual`.
- For file-backed clients, an explicit config path overrides the default and is
  `repository_local` only when it is inside the canonical repository root.

Repository-local registrations use `k_wiki`. Shared and manual registrations
derive `k_wiki_<sanitized-repo>_<hash8>` from the first eight SHA-256 hex
characters of the normalized canonical repository path. Explicit names are
preserved, except explicit `k_wiki` is rejected for shared/manual targets.
Each client uses a file adapter with `RejectDifferent`: matching `command` and
`args` are idempotent, while mismatches or unparseable managed entries fail
without changing the file. It fails safely when the starter bundle is absent;
run `k-wiki install` first.

After a successful replacement, legacy shared `k_wiki` entries for the same
bundle are removed. Entries for another valid repository are atomically renamed
to that repository's deterministic shared name, preserving access without
colliding with the new local `k_wiki`. Migration conflicts and malformed legacy
entries fail during preflight. Cross-file migration writes the local entry
first, then applies the preflighted shared migration; a later cleanup failure
reports a partial migration and keeps the safe local entry. Manual results
include explicit cleanup instructions. `--dry-run`
reports registration and cleanup without writing. `--client all` resolves and
names every client independently. Machine-readable results retain the existing
fields and add `target_locality` and `legacy_cleanup`.

`--verify` reads back the installed entry, starts its stdio command, and checks
the Knowledge Wiki identity, required tool schema, single-bundle boundary, and
configured bundle. A failed runtime check leaves the registration installed,
returns `installed_but_unverified`, and exits unsuccessfully. With `--dry-run`,
verification is reported as skipped.

Registration is separate from repository bootstrap and does not start a
persistent server. The registered command uses `k-wiki` by default; set
`K_WIKI_SERVER_COMMAND` before registration to write a different executable
path. The runtime remains single-bundle: each server records one absolute
`knowledge/` path, and `wiki_list_bundles` does not accept caller-selected
`repository_roots`. After upgrading, rerun `k-wiki mcp install` in every
repository and restart the MCP client to replace stale running registrations.

## MCP maintenance tools

The MCP server exposes the same maintenance operations as the CLI, so agents
can validate, check links, and build without invoking a shell:

| CLI command | MCP tool | Required inputs |
| --- | --- | --- |
| `k-wiki validate knowledge --profile recommended --json` | `wiki_validate` | `bundle_root`, `profile` |
| `k-wiki check-links knowledge` | `wiki_check_links` | `bundle_root` |
| `k-wiki build knowledge --out .kwiki/site` | `wiki_build` | `bundle_root`, `output_root` |

`wiki_build` is marked as a write operation because it writes the static site.
All three tools accept `include_structured_content: true` when an agent needs
the typed result as well as the standard MCP text response. `bundle_root` must
identify the bundle configured when the server was registered; use its absolute
`knowledge/` path when the MCP client's working directory is not the repository.

## AI-agent workflow

Use the `k_wiki` MCP server for every wiki interaction; do not invoke the
`k-wiki` CLI or edit generated state directly.

1. **Orient before acting.** Treat `knowledge/` as curated repository intent,
   not a substitute for current code. Start with `wiki_list_bundles`, then
   `wiki_search_concepts`. Read the most relevant entries with
   `wiki_get_concept`; use `wiki_list_directory`, `wiki_get_backlinks`, and
   `wiki_get_neighborhood` to understand related decisions.
   `wiki_list_bundles` accepts no bundle-selection arguments and lists only the
   bundle roots configured when the MCP server was registered. It never scans
   caller-supplied repository paths.
2. **Ground implementation work.** Use the wiki for architecture, terminology,
   invariants, ownership, and prior decisions. Verify changeable details with
   the repository's codebase-graph MCP tools. When code and wiki conflict,
   identify the conflict and use `wiki_populate_page` to record the clarified
   intent rather than silently following stale content.
3. **Author knowledge deliberately.** Create missing pages with
   `wiki_create_page`; update existing pages with `wiki_populate_page`, always
   supplying title, type, tags, useful Markdown, and `expected_content_hash`.
   Record durable decisions, public contracts, runbooks, invariants, and
   non-obvious trade-offs—not transient implementation noise or copied source.
4. **Validate and publish after edits.** Call `wiki_validate` with
   `profile: "recommended"` and `include_structured_content: true`, then call
   `wiki_check_links`. Call `wiki_build` with the configured `bundle_root` and
   the repository's `.kwiki/site` `output_root`; it is a write operation.
   `knowledge/` is source, while `.kwiki/` is generated state and must never be
   edited manually.
5. **Close the loop.** Use `wiki_get_diagnostics` to inspect remaining issues
   and `wiki_get_recent_changes` to see changes since prior work. In a handoff,
   cite the updated concept paths and summarize decisions, uncertainties, and
   validation results.

## State and rollback

Successful builds publish complete versioned generations under `.kwiki/`.
Compilation or rendering failures leave the last valid generation readable.
An unchanged input is a cache hit; generation tokens prevent stale concurrent
work from replacing newer output.

Runtime reads reload configured source content before reusing a cached
projection, so the next request observes completed edits and memory lifecycle
changes made by another process. This adds source-reading work per request;
external multi-file edits are not transactional. An incomplete I/O or UTF-8
scan returns `source_unavailable` for ordinary reads and retains the previous
complete cache. Health reports `ok: false` and HTTP status 503; its
`projection_available` field indicates whether a prior snapshot remains.
Permissive diagnostic and build operations return partial content with its
findings, without replacing that runtime cache.

To roll back, stop the preview process and restore the previous manifest and
generation pointer from normal repository backup tooling. Never edit generated
projection JSON as source.

## Validation profiles

- `consume`: retains readable content and reports diagnostics, including errors.
- `conformant`: rejects error diagnostics.
- `recommended`: rejects warning and error diagnostics, including authoring guidance.

Validation exits with status 0 for acceptance and 1 for rejection, in both text
and JSON modes. Validation, link checks, diagnostic queries, and projection
builds combine loader, conformance, and compiler findings. Builds retain their
consume-mode behavior. Locations refer to full source-file lines, including
frontmatter offsets.

MCP errors preserve the existing numeric RPC code and message, and include
`error.data` with the domain `code`, `details`, and `retryable` flag.

Diagnostics use stable codes and repository-relative paths. Public errors never
include absolute host paths, source contents, secrets, or raw parser failures.
