#[derive(Debug)]
enum JoinState {
    Empty,
    Running(JoinHandle<()>),
    // Preserve target identity even after another drainer takes the handle.
    Joining(thread::ThreadId),
    Joined,
}

#[derive(Debug)]
struct JoinedThread {
    state: Mutex<JoinState>,
    completed: Condvar,
}
impl JoinedThread {
    fn new(handle: Option<JoinHandle<()>>) -> Self {
        Self {
            state: Mutex::new(handle.map_or(JoinState::Empty, JoinState::Running)),
            completed: Condvar::new(),
        }
    }
    fn install(&self, handle: JoinHandle<()>) {
        let mut state = self.state.lock().unwrap_or_else(|e| e.into_inner());
        assert!(matches!(*state, JoinState::Empty));
        *state = JoinState::Running(handle);
    }
    fn is_running(&self) -> bool {
        match &*self.state.lock().unwrap_or_else(|e| e.into_inner()) {
            JoinState::Running(handle) => !handle.is_finished(),
            JoinState::Joining(_) => true,
            _ => false,
        }
    }
    /// False means the target is the calling thread, never completed drain.
    fn join(&self) -> bool {
        let handle = {
            let mut state = self.state.lock().unwrap_or_else(|e| e.into_inner());
            loop {
                match &*state {
                    JoinState::Empty | JoinState::Joined => return true,
                    JoinState::Running(handle) => {
                        let target = handle.thread().id();
                        if target == thread::current().id() {
                            return false;
                        }
                        let JoinState::Running(handle) =
                            std::mem::replace(&mut *state, JoinState::Joining(target))
                        else {
                            unreachable!()
                        };
                        break handle;
                    }
                    JoinState::Joining(target) if *target == thread::current().id() => {
                        return false
                    }
                    JoinState::Joining(_) => {
                        state = self
                            .completed
                            .wait(state)
                            .unwrap_or_else(|e| e.into_inner())
                    }
                }
            }
        };
        // First local, last to drop, including if a join panic payload panics.
        // Concurrent drainers cannot pass until all join-owned disposal ends.
        let _completion = JoinCompletion(self);
        let result = handle.join();
        drop(result);
        true
    }
}
struct JoinCompletion<'a>(&'a JoinedThread);
impl Drop for JoinCompletion<'_> {
    fn drop(&mut self) {
        *self.0.state.lock().unwrap_or_else(|e| e.into_inner()) = JoinState::Joined;
        self.0.completed.notify_all();
    }
}

