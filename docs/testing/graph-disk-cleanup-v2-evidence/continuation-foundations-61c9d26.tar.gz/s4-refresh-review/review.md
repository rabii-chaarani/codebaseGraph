# DC-S4 refresh cancellation and owned join — final lifecycle review

Clear this focused lifecycle prerequisite for the exact v4 snapshot below. No confirmed P0-P3 defect remains in the reviewed scope. Collector integration and whole DC-S4 acceptance remain pending.

Fresh independent reviewer: GPT-6.1 Sol / Max, applying adversarial-review-engineer. The reviewer did not implement the changes. No author/shared source, Scryer, wiki, Git or Linear writes were made. Shared Cargo lease183 was released before this report was prepared.

## Reviewed boundary and authority

This slice adds explicit refresh cancellation, a unique RefreshRuntime owning the refresh JoinHandle, the private API tuple/barrel bridge, and completed coordinator/monitor joins outside shared mutexes. It preserves existing refresh policies, status schema, real dispatcher occupancy and caller-timeout behavior. The signed proposal is `/private/tmp/dc-s4-refresh-owned-join-proposal-20261021.md`, SHA-256 `5ea3b3280a0282262c4a1dce30ea4658ebc01f8aba134d79bff7d27be64c07fe`, under canonical DC-S4 revision0.2 and explicit-checkout Scryer `chg-6vx5tj`, `node-hxxbg1`. Governing existing refresh responsibilities include `node-144` / `resp-269`; Scryer remains the architectural authority.

Repository memory, canonical refresh wiki context and Scryer rules/intent were consulted. Semantic graph search discovered refresh, facade, coordinator and API barrel files before source reads. The graph indexes an older checkout, so all implementation conclusions use only the explicit frozen source and executed evidence below. No other project's state was substituted.

## Exact final snapshot

Baseline: `45a9eae45236f6a1527c1173c93e2cb652f67b8d`. Frozen root: `/private/tmp/cleanup-s4-refresh-v4-gt0s2aom`. Independent reconstruction: `/private/tmp/cleanup-s4-refresh-review-b9owzhuh/final-repo`, made from a clean Git archive plus only these five overlays: `src/api/refresh.rs`, `src/api/facade.rs`, `src/api/mod.rs`, `src/coordinator.rs`, and `src/coordinator/tests.rs`.

Owned diff SHA-256: `b10971a694636e7e733a9b74ef8406bb06f089ec6a6ddede448532d8c38b5bb8`. All467 captured inputs match before and after execution: manifest SHA-256 `61c25bdf58602d4f0fd58cb81e1100a5dd432164d5660588abef1c9f3f8342a7`. Later live S2/S3 changes were excluded.

## Findings and verified safeguards

No confirmed P0-P3 findings and no unresolved conditional defect requiring a new user decision remain.

- The cancellation token is created before the serving thread/API construction, shared by owner and refresh state, and read independently of status/Core Arc counts. The unique non-Clone Runtime stays in the serving thread; Core/API clones retain state/control only. Retained Core clones do not prevent cancellation or create a Runtime cycle.
- The serving thread joins refresh before removing owned serving state or releasing its coordinator lease. Early return, executor-start failure and Runtime Drop follow the same cancellation/join ownership. Optional refresh spawn failure records failed refresh while the committed graph remains readable through health.
- Explicit StoppedAfterDrain, LegacyDisabled and failure/panic dispositions remain distinct. RefreshExitFinalizer publishes terminal status after run-owned resource and caught panic-payload disposal, including unwinding; premature mark_stopped in refresh_batch was removed. Ordinary stop does not overwrite a delivered genuine failure or legacy-disable result.
- JoinedThread retains the real target ThreadId through Joining, so a target cannot join itself even after another drainer takes its handle. Other drainers wait on the completion condition. Joins and panic-payload disposal happen outside the control mutex; JoinCompletion notifies all waiters on normal return or unwind.
- Monitor stop is a separate Arc token. Its final weak/stop check occurs after iteration-owned strong ClientInner/API references have dropped, preventing another wait/work tail after final self-drop. External drains wait for actual join, then snapshot/drop route ownership outside route locks.
- The executor's actual slot and caller-timeout semantics remain intact. Native/poll backend identity, retry/backoff, dirty epochs, generated-path filtering and cancellable-worker lock waiting pass their affected regressions.

## Test correction and historical attribution

The v2 author attempt (codegen178) failed compilation with E0603 because coordinator imported the private api::refresh module. It establishes no passing execution. The successor adds only the explicitly owned pub(crate) API barrel exports and corresponding import; refresh stays a private module and no public API change is introduced.

The v3 author attempt (codegen184) passed60/61 and exposed a fixture race. The target could observe stop before the drainer's brief Running-to-Joining mutex transition completed; try_lock could therefore correctly fail before join began. Static interleaving confirms this was a false assertion about the transition, not a demonstrated production join-lock defect. Its historical log is preserved as `author-v3-excluded-compile-test.log`.

Final v4 is production-byte-identical to v3. The fixture now waits, with a deadline, until it observes Joining under the same short mutex; that guard is released before its original one-shot unlocked-join/route assertion. The target has not exited, so the drainer still waits for it. Holding the mutex across join would still fail this test. This synchronization preserves the intended assertion. The corrected fixture passed the real-library run and20 further direct repetitions against one unchanged captured binary.

## Independent execution and provenance

A fresh root-package compilation with codegen183 is visible at `compile-test-final.log:59`, naming `/private/tmp/cleanup-s4-refresh-review-b9owzhuh/final-repo`; it completed in18.62s with no root Rust compiler warning. Tests ran with authorized local loopback access from the outset.

Independent execution passed61 distinct affected library tests in two reports:59/59 coordinator/refresh/scheduler cases, then2/2 facade and cancellable-worker cases. The union is exactly the author's61 named cases:25 coordinator,23 refresh,11 scheduler,1 facade and1 cancellable worker. All31 previously accepted driver regressions are included. There are no72 distinct tests; the earlier anticipation double-counted scheduler coverage.

- Main JUnit SHA-256 `4554c3a0f1d1a4b43424c77c90ee5cb4a9622363d18411a5a0ec59c8d3b637dc`, run `56d46c3a-0163-4764-abb3-736d2822ec73`, records59 passes in14.045s.
- Additional JUnit SHA-256 `6a6498b975b4d78699f5468ef72378ae1f610de0ffba3ffc97fc91ae7dfa783c`, run `c0d4aa02-51f8-4b0d-8643-d63dfe69a160`, records2 passes.
- Binary `codebase_graph-c1ab31ef0df36936` SHA-256 `095e02f4e590125518b327f412a490875384870e91c4f3d147b1c9b096928611` is unchanged before/after the20 fixture repetitions. Registered inventory614 tests, SHA-256 `a1f534544e92b85e0443cf34b61ff864e37c2787d0f4742afde8c4a67d0889c4`.
- Two independent private rustc probes over the byte-exact extracted JoinedThread implementation passed: four concurrent drainers remain blocked through normal/panicking join-payload disposal and all are notified; target self identity remains correct while an external drainer owns the handle. These local probes supplement the real library execution.

Author codegen185 evidence is corroborated: evidence JSON SHA-256 `25568a56631ab2b8252e3bc799b4dae41b3892d3ef30fbe441cd5a81594440fa`; author JUnit SHA-256 `de96401e3dd8060bd6eecc8cfe1c57e8da9156b1b1ddcd718d2673829d63fd9c`. Exact commands, source identities, report paths and binary identities are in evidence.json and execution-proof.json.

## Scope limits and handoff

This clears only the explicit refresh cancellation/owned join lifecycle prerequisite. The native unit refresh case uses the existing in-process materialization fallback when no isolated worker executable is registered. It does not qualify the full isolated-worker process/descendant lifecycle or other native platforms. Those existing release gates remain separate.

Concrete S2/S3 controller callbacks, automatic collection triggers, typed Managed transaction-versus-janitor recovery, retired-Direct behavior, compact health measurements and aggregate DC-S4 closure remain pending. This review does not authorize marking those outcomes complete.

Reusable-knowledge assessment: no new memory candidate was written; the report records focused source/evidence and a resolved fixture issue, while the coordinator owns canonical handoff and closure reconciliation. No tracking updates were sent to Linear.
