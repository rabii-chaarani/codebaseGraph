use std::sync::{Arc,Condvar,Mutex,mpsc};
use std::thread::{self,JoinHandle};
use std::time::{Instant,Duration};
#[derive(Debug)]
enum JoinState {
    Empty,
    Running(JoinHandle<()>),
    // Preserve target identity even after another drainer takes the handle.
    Joining(thread::ThreadId),
    Joined,
}

#[derive(Debug)]
struct JoinedThread {
    state: Mutex<JoinState>,
    completed: Condvar,
}
impl JoinedThread {
    fn new(handle: Option<JoinHandle<()>>) -> Self {
        Self {
            state: Mutex::new(handle.map_or(JoinState::Empty, JoinState::Running)),
            completed: Condvar::new(),
        }
    }
    fn install(&self, handle: JoinHandle<()>) {
        let mut state = self.state.lock().unwrap_or_else(|e| e.into_inner());
        assert!(matches!(*state, JoinState::Empty));
        *state = JoinState::Running(handle);
    }
    fn is_running(&self) -> bool {
        match &*self.state.lock().unwrap_or_else(|e| e.into_inner()) {
            JoinState::Running(handle) => !handle.is_finished(),
            JoinState::Joining(_) => true,
            _ => false,
        }
    }
    /// False means the target is the calling thread, never completed drain.
    fn join(&self) -> bool {
        let handle = {
            let mut state = self.state.lock().unwrap_or_else(|e| e.into_inner());
            loop {
                match &*state {
                    JoinState::Empty | JoinState::Joined => return true,
                    JoinState::Running(handle) => {
                        let target = handle.thread().id();
                        if target == thread::current().id() {
                            return false;
                        }
                        let JoinState::Running(handle) =
                            std::mem::replace(&mut *state, JoinState::Joining(target))
                        else {
                            unreachable!()
                        };
                        break handle;
                    }
                    JoinState::Joining(target) if *target == thread::current().id() => {
                        return false
                    }
                    JoinState::Joining(_) => {
                        state = self
                            .completed
                            .wait(state)
                            .unwrap_or_else(|e| e.into_inner())
                    }
                }
            }
        };
        // First local, last to drop, including if a join panic payload panics.
        // Concurrent drainers cannot pass until all join-owned disposal ends.
        let _completion = JoinCompletion(self);
        let result = handle.join();
        drop(result);
        true
    }
}
struct JoinCompletion<'a>(&'a JoinedThread);
impl Drop for JoinCompletion<'_> {
    fn drop(&mut self) {
        *self.0.state.lock().unwrap_or_else(|e| e.into_inner()) = JoinState::Joined;
        self.0.completed.notify_all();
    }
}


#[cfg(test)] mod independent_probes {
 use super::*;
 struct Release(Option<mpsc::Sender<()>>);
 impl Drop for Release {fn drop(&mut self){if let Some(tx)=self.0.take(){let _=tx.send(());}}}
 struct PausedPayload {entered:mpsc::Sender<()>,release:mpsc::Receiver<()>,panic_again:bool}
 impl Drop for PausedPayload {fn drop(&mut self){let _=self.entered.send(());let _=self.release.recv();if self.panic_again{panic!("owned payload drop");}}}
 #[test] fn all_waiters_observe_complete_disposal_even_after_joiner_unwinds(){
  for panic_again in [false,true] {
   let (entered,entered_rx)=mpsc::channel();let (release,release_rx)=mpsc::channel();
   let target=thread::spawn(move||std::panic::panic_any(PausedPayload{entered,release:release_rx,panic_again}));
   let joined=Arc::new(JoinedThread::new(Some(target)));
   let mut release=Release(Some(release));
   let (done,done_rx)=mpsc::channel();let mut drainers=Vec::new();
   for _ in 0..4 {let j=joined.clone();let done=done.clone();drainers.push(thread::spawn(move||{let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||j.join()));done.send(result.is_ok()).unwrap();}));}
   entered_rx.recv_timeout(Duration::from_secs(5)).unwrap();
   let unlocked=joined.state.try_lock().is_ok();
   let premature=done_rx.recv_timeout(Duration::from_millis(25)).is_ok();
   release.0.take().unwrap().send(()).unwrap();
   let answers=(0..4).map(|_|done_rx.recv_timeout(Duration::from_secs(5)).unwrap()).collect::<Vec<_>>();
   for d in drainers {d.join().unwrap();}
   assert!(unlocked);assert!(!premature);assert_eq!(answers.iter().filter(|ok|!**ok).count(),usize::from(panic_again));
   assert!(matches!(*joined.state.lock().unwrap(),JoinState::Joined));assert!(joined.join());
  }
 }
 #[test] fn target_self_identity_is_kept_while_an_external_join_is_pending(){
  let joined=Arc::new(JoinedThread::new(None));let weak=Arc::downgrade(&joined);
  let (release,release_rx)=mpsc::channel();let (answer,answer_rx)=mpsc::channel();
  let target=thread::spawn(move||{let _=release_rx.recv();answer.send(weak.upgrade().unwrap().join()).unwrap();});
  joined.install(target);
  let j=joined.clone();let drainer=thread::spawn(move||j.join());
  let deadline=Instant::now()+Duration::from_secs(5);
  while !matches!(*joined.state.lock().unwrap(),JoinState::Joining(_)){assert!(Instant::now()<deadline);thread::yield_now();}
  release.send(()).unwrap();let answer=answer_rx.recv_timeout(Duration::from_secs(5)).unwrap();
  let complete=drainer.join().unwrap();assert!(!answer);assert!(complete);assert!(!joined.is_running());
 }
}
