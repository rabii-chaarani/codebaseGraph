# DC-S3 pure validation and codecs — independent implementation review

**No confirmed P0–P3 defects were found in the reviewed snapshot.** The pure facts slice may proceed to integration within its existing narrow clearance. This review adds no producer publication, loader-usability, file/stamp binding, current-reference, admission, backup restoration, actual journal-write, container-detach or deletion clearance.

Reviewer: **GPT-6.1 Sol / Max**, independently configured by coordinator dispatch and separate from the implementation author. Applied `/Users/rabii/.codex/skills/adversarial-review-engineer/SKILL.md` and its engineering lenses. All probes and report files are isolated. No author/shared source, tests, Git, model, wiki, memory or tracking records were changed. Shared Cargo was released to the coordinator immediately after the independent root rebuild/run.

## Exact reviewed artifact and intent

- Baseline: `7b0ad57ba26152c9fe19a9145a7c83c363f87b23`.
- Author freeze: `/private/tmp/dc-s3-validation-164-gjtbfe3o/repo`; independent copy: `/private/tmp/cleanup-v2-s3-validation-review-4c1uud_k/repo`.
- Five overlays: new `src/storage/maintenance_validation.rs`, new `maintenance_journal.rs`, JSON position fact, test-only budget adapter, and two module exports in `mod.rs`. Archive comparison confirmed exactly these overlays and no missing baseline files. All **429** inventoried inputs matched supplied hashes before and after independent execution.
- Verified source-manifest SHA-256 `e4b303cccc388e005a5522aae6fec3ed7b85f0e82193e3bc9af6b9564b8ff7bd`; diff SHA-256 `93a1c503c45953cbe43a1971b0fca4edc22679facf9c13d06eb2760f5d5b5609`; author evidence-summary SHA-256 `897530452d429525e69975169173e73e1bff80ee9e54ce3e16a4747e4a9b4163`. Every entry in the supplied artifact manifest was checked.
- Read the actual authoritative temporary checkout AGENTS.md, SHA-256 `6cdcafee03c4b2138b3839cd59b336198176837ab4fef73a922c6d98029cb2d7`. Recalled repository memory, consulted configured wiki bundle/search/get for `architecture/graph-disk-cleanup-contract` revision 0.2, fetched governing Scryer rules, and read/oriented explicit project `/private/tmp/codebasegraph-disk-cleanup-7t9af0a6/repo`, `chg-6vx5tj`, `node-eje4rb` and its updated pure-validation brief. No ticket gate or external publication was introduced for this read-only review.
- Reviewed concrete mechanism `e63875a0acc346c3231411b0a1bf68ed59679e1d9f9dcc884844d3570705514b`, its fresh Max starting review, and the separate serializer-feature qualification. Existing approval covers this private implementation scope; no user product decision was reopened.
- Required semantic/slim graph searches and dependency context preceded source reads. The configured older index has no new validation/journal file entries; explicit Scryer briefs and frozen file anchors supplied that mapping. Indexed validator, artifact envelope, ManifestEntry, row and partition-hash anchors located surrounding implementation. No unrelated project state was substituted.

## Confirmed findings

None after source tracing, counterexample probes and execution against the frozen input. No author fix is requested for this snapshot.

## Conditional risk retained for the existing throughput gate

`maintenance_validation.rs:504–509`: **Table::find scans every capacity slot on a miss, even after observing an empty slot.** This is a complete source trace: the loop records an empty slot and continues through the entire table. In ordinary replay, inserting many distinct IDs therefore pays a capacity-sized lookup cost even while occupancy is low. Large capacity and many distinct raw or metadata IDs can make the future collector's validation expensive, in addition to the already documented replay amplification.

This is not a claimed measured latency failure or a confirmed defect against the supplied pure-facts correctness scope. The brief explicitly leaves large-file/default-ceiling throughput unqualified and no production caller is enabled here. Preserve that gate before promoting this engine into the collector. A suitable next step is to measure realistic allocated capacities and distinct IDs; normal open-addressing lookup could stop at an empty slot if separated from the collision-selection path, whose arbitrary replacement needs different lookup rules. No benchmark or production load was run for this review.

## Contracts and counterevidence examined

**Producer/schema and numbers.** The scanner preserves actual typed field order, required/omitted/default forms, schema/count and partition-ID facts without materializing GraphPartition, arbitrary Value objects or IDs. String comparisons decode complete spans in bounded chunks. Control escapes are checked against actual serializer form; Unicode escape equivalents remain distinct producer-form facts. Optional serialized nulls that the producer would omit do not gain a producer-shaped flag.

Every typed float and metadata Value number uses the pinned parser-to-serializer equality oracle; numerical representability and exact token stability remain separate. The known `0.9966544878724393 → 0.9966544878724392` counterexample is detected. Integer extrema, negative zero, subnormals, finite generated bit patterns, oversized integers and exponent overflow were compared against the actual linked serde_json scalar parser/serializer. Nonfinite confidence serialized as null remains origin-only factual data, with typed usability false. Long nonproducer numeric spellings do not allocate source-sized strings.

The actual selected root serde_json 1.0.150 runtime has **default + std**, confirmed by its root dependency fingerprint and by executed serialization; tree-sitter's build-context preserve_order/indexmap is a separate unit. The scanner exposes `metadata_keys_sorted` independently. A probe recomputed a matching lexical wire checksum over an unsorted metadata object, confirmed wire-checksum equality, and independently observed sorted typed reserialization differ: a wire checksum alone never becomes a loader-usability witness. Pinned parser depth behavior was cross-checked through the complete typed envelope, with surrounding container depth included. Primary dependency source: [serde_json 1.0.150 parser](https://docs.rs/serde_json/1.0.150/src/serde_json/de.rs.html).

**Exact join.** Traced all raw IDs, declared array IDs and declared map keys through hashing, prefix replay and exact comparison. Hash is an index/partition hint; decoded complete ID plus domain decides equality. Raw multiplicity equals the declared multiset, declared map membership is exactly one per distinct raw ID, and final raw ordinal supplies the expected final type. Metadata objects have independent offset-derived namespaces and exact key-uniqueness checks. Extra declared-only keys cannot disappear in either replay path.

On prefix overflow, incomplete aggregates are cleared before splitting. Prefix depth represents 256, and short-circuit checks avoid an out-of-bounds whole-byte lookup at that boundary. A complete single-hash bucket can go directly to exact-key batching. Its selection pass retains at most capacity distinct keys above the prior exact lower bound; aggregation happens in a separate replay so replacements do not lose occurrence counts. Capacity one progresses, empty strings and long/escaped IDs compare exactly, and completed lower ranges are not recounted. Existing actual-library tests plus independent forced-collision probes exercised those paths. This yields RawRowsMatch facts, never LoaderUsable.

**Memory and errors.** New dynamic storage is the exact-layout reserved table and the existing reader buffer; overflow/capacity zero are rejected. Scalar workspace, scanner/join floors and metadata prior-key arrays reserve against the same account. Source backing allocations remain the caller's explicit responsibility. Normal return, schema/numeric/source errors, low ceilings, allocation failures and table-size overflow released reservations back to the initial account floor in probes. No new unsafe block was introduced in the two new modules. This review does not convert explicit requested-layout accounting into a whole-pipeline or RSS claim.

**Receipt/journal facts.** Receipt phases distinguish intent, actual creation observation, writing, completed staging, rename/backup/canonical observations, fsync publication and rollback. Stored usable bits remain claims. Illegal publication and substituted identities are rejected by the pure transition table; the module has no filesystem operations or capability constructors.

Journal source epoch is immutable across every staged frame and disposal update. Stage generation, committed/disposed frame ordinals, frame-chain bytes and next logical address are separate progress facts. Own E increment before durable Detaching yields NeedsReprepare. Detaching without an actual matching private incarnation yields NeedsRecovery; recorded Detached/Draining without a matching observation yields Unknown. Done requires explicit private absence and all committed frames disposed. Reordered/duplicate progress, epoch and generation overflow boundaries, checksum corruption and 257 fresh codec reconstructions were checked. These are pure crash-state simulations, not actual crash/power-loss execution or adoption of a multi-leaf container from one inode.

## Executed evidence and attribution

Host: Darwin arm64, rustc **1.96.0**. Independent rebuild used unique root override `profile.test.package.codebase-graph.codegen-units=165`; compilation visibly rebuilt the root from the reviewer copy in **17.92 s**, with no warnings in that test build.

Command:

```text
cargo nextest run --lib --locked --offline --config 'profile.test.package.codebase-graph.codegen-units=165' --target-dir /Users/rabii/Projects/Repositories/codebaseGraph/target --config-file /private/tmp/codebasegraph-disk-cleanup-7t9af0a6/nextest.toml --profile cleanup-s3 --filterset 'test(storage::maintenance)'
```

Result: **78 passed, 485 skipped, retries 0**. The list contained the expected 563 library tests: 12 new pure cases, 14 accepted facts cases and 52 ownership cases were selected. Counts describe executions, not 78 new tests.

Independent binary `codebase_graph-6c8959779608703b`, SHA-256 `6a20d7ad5de3dc13d27a8d5d241cc9d894afed32dd286788653537a8e4835b5b`, was copied with its dependency file before execution and verified unchanged afterward. JUnit SHA-256: `7b70db1dde9093a33ecf0e3a8a360113612fa2661b4b1e7ab7e7310b3f9fb96e`. Visible compile cwd, unique root setting, complete source inventory, binary identity and exact selected inventory jointly establish attribution; no binary-string pathname claim was used.

Independent fixture probes passed:

- **1,084** scalar oracle cases covering typed float, Value Number, i64 and u64.
- **654** raw-row differentials against the frozen actual validate_raw_rows implementation, including capacities 1/3/32, normal and injected full-digest collision paths, orphan keys, multiplicity, final type, cross-domain/empty/long IDs and counts.
- **22** schema, default, checksum, map-order and complete typed-depth cases.
- **20** low-memory/error/overflow and injected table/reader allocation-failure release checks.
- **852** journal ordinal/restart/corruption/epoch boundary checks, including 257 frames and disposal ordinals.
- **4** dense metadata checks: a 48-key object forced through capacity-one full-hash collision batches; exact duplicate and escaped-equivalent duplicate keys rejected without leaked reservations.

The direct-rustc probe linked copied dependencies selected by the exact rebuilt root fingerprint DAG, not a convenient cached variant. `probe-dependencies.json` records all 20 dependency units and hashes. Fixture type/validator excerpts are verbatim frozen source. For private collision injection only, a scratch replica removes two module doc-comment lines and appends a visibility accessor calling the unchanged existing join_inner with forced=true; the remaining source body was verified byte-for-byte. Original 429 source inputs were untouched, and the real root suite separately executed its own forced-collision tests. Fixture backing data and expected-value allocations are outside the tested maintenance account; no whole-pipeline memory claim is made.

All five changed Rust files passed direct rustfmt check. No probe compiler warnings appeared. Earlier author attempts with compilation/fixture failures are retained and excluded from passing qualification; this review used the corrected 164 freeze and its independent 165 reconstruction.

## Limits and handoff

No FileSource, physical source-stamp stability, current-reference proof, producer receipt publication, on-disk journal staging, recovery syscall, backup restore, controller or deletion operation was added or exercised. Concurrent unfinished S2 B/C and S4 work was excluded deliberately. No native Linux/Windows, full workspace suite, production warning-free build, Miri/sanitizer, million-ID/default-384-MiB throughput, allocator slack/RSS or aggregate cleanup qualification was performed. Preserve the existing authority, source-binding, throughput and native-platform gates.

Reusable-knowledge assessment: the actual linked runtime versus build-dependency feature distinction is worth retaining with the accepted evidence; it is already clarified in the authoritative Scryer brief and serializer qualification. Other results are snapshot-specific evidence or readily rediscovered implementation facts. This read-only reviewer made no wiki/memory or tracking writes; the coordinator owns any durable reconciliation.

Evidence directory: `/private/tmp/cleanup-v2-s3-validation-review-4c1uud_k`; machine-readable outcome: `verification.json`; hashes: `review-artifact-sha256.json`.
