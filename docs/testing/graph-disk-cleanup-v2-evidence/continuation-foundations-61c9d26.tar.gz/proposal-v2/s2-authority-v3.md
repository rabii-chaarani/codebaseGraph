# DC-S2 selected bounded authority mechanism

Design only, immutable Max-review input, 2026-10-21. Approved revision0.2; Scryer `chg-6vx5tj`, `node-2xwzve` and `node-n2z01j`; existing work/closure identities unchanged. This selects the remaining private implementation mechanism. No new product behavior, user decision, source clearance, Ready permit or release qualification is inferred.

Source baseline for the private B/C foundation: `7b0ad57ba26152c9fe19a9145a7c83c363f87b23`. Frozen foundation `/private/tmp/cleanup-s2-bc-foundation-final-vvbfeega`: patch SHA256 `f85e6131e355dc5a457fb0558b47b32f5ba3084dc54994b24a1234aa129b25c9`; actual159 root build,76/76 tests including19 new cases, format pass,427 input hashes unchanged. Windows branches neither compiled nor run on Darwin. Configured graph indexes the older original checkout; new foundation/module facts were checked against the supplied exact source mappings and isolated source.

Aligned S3 input `/private/tmp/dc-s3-origin-join-journal-mechanism-20261021.md`, SHA256 `e63875a0acc346c3231411b0a1bf68ed59679e1d9f9dcc884844d3570705514b`; Max review `/private/tmp/cleanup-v2-proposal-review-Ox0SyW/s3_mechanism_review.md`, SHA256 `58e5d1a207da3164e68355d1c0389a9f8a2356e9cee02a23bbff1f9ae0f18ea5`. The selected per-entry transition implements that review's explicit alternative to an unproved whole-tree foreign-insertion certificate. S3 confirmed its current JournalFacts models one exact moved payload; a newly created multi-leaf container cannot inherit one source inode's proof.

## 1. Selected decisions

1. Use **leaf-first terminal-workspace compaction**. Never rename an arbitrarily large workspace tree after only a prior scan/top-directory stamp. Detach one exact owned leaf to one exact private payload address; unknown siblings stay at their PUBLIC paths. Remove directories only using atomic-empty `rmdir`. No whole-tree recursive delete or unknown-tree adoption exists.
2. Canonical artifact admission requires both public worker/phase payload registries to satisfy **fixed structural emptiness**, using fixed native first-entry probes. Stable gates/cohort metadata live outside these registries. Any real entry is Pending/Unknown. Large registries fail admission in bounded work; fair offslot selection and eligible terminal leaf cleanup make progress until genuinely empty. No global retained catalog/counter is used to pretend a nonempty registry is empty.
3. Each owned workspace gets a fixed, incarnation-bound local control protocol. Its frozen source identity, mutation/admission version, child-closure progress and private journal generation are different fields. Local cleanup never borrows global exclusive reference observation while another producer holds shared activity.
4. Stable destination writer/state/use/family/registry gate files never move or unlink. Incarnation-local run/lifecycle leases also stay at public addresses during payload cleanup; their final unlink is a separate closed-root action under stable gates and a durable removal intent. This avoids relying on movable lock-path validation.
5. Every launcher that can create a collectible workspace participates in a stable **startup gate** before registration/creation, with the child independently opening and acquiring its OWN Shared gate before its lifecycle lease and validating the incarnation. Post-lock root/nonce/Closed checks reject late startup. Caller-owned/fallback roots and legacy incompatible actors do not gain collection ownership.
6. Full Work remains owned OFF the execution permit. Only borrowed fixed hot frames, borrowed effect context, bounded scratch and actual fixed-count authority enter a callback. Callbacks return fixed facts; no owned Work/decoder/path vector/result backlog is moved in or dropped during an error/panic under authority.

## 2. Shared account and bounded projections

The accepted `maintenance_budget.rs` account is the ONLY ceiling. S3 physically owns it; S2/S4 consume clones of the same account. Its requested-layout boundary is not an RSS/allocator-slack promise. S4 reserves job/stack bookkeeping before starting its one joined advisory job. All buffers, decoded paths, fixed projection state, queued Work/results and disposal retain reservations until freed offslot.

S2 will own a bounded control-projection implementation after coordinator assignment (proposed `maintenance_projection.rs`, not yet created). It consumes S3's `MaintenanceJsonReader`/span facts, not an unaccounted reader or `serde_json::Value`. Each control is noncreating-opened with B's fixed native scratch, its FD identity/type/link count/stamps checked before and after streaming. The fresh final address is reopened and compared before a projection is accepted. Source change is Stale; missing/foreign/unsupported evidence stays Unknown/NeedsRecovery. Preparation never calls `probe_registry`, `probe_lifecycle`, `ensure_registry_empty`, `retire_lifecycle`, generic `claim` or generic `revalidate`.

Projection table:

| Control | Retained projection | Compatibility rule |
|---|---|---|
| Config | fixed spans for schema_version, repo_root, storage_root, database_path, manifest_path; config identity/stamp; selected physical role IDs | Complete JSON/UTF8 validation; repeated relevant keys follow current last-value-wins behavior. Exact current null/missing/path/type/schema1/2/3 semantics. Preserve raw Direct address bytes in writer/journal/domain keys. External config must bind the same repository; original path components are validated before any normalization. |
| Descriptor/proof | version, exact lifecycle/root IDs and nonce, endpoint/job/FIFO spans, device/inode, expected lease/control identities | v2 Guardian policy remains; v1/missing/foreign/ambiguous evidence is Unknown. No PID/age abandonment inference. Decode only selected bounded paths/scalars outside authority. |
| Receipt | exact descriptor/incarnation binding, containment_empty, completion/error policy | A receipt is terminal proof only for its matched supported guardian/control incarnation. Otherwise perform the fresh nonmutating kernel check under its actual lease. |
| Run/scope/barrier | actual run ID/root/lease, source-domain tuple, phase, candidate/base/active IDs, absolute barrier root/control identity | Publishing/unresolved replay =>NeedsRecovery. Relative/missing/unassociated barriers =>Unknown. No default terminal disposition from a missing journal or one empty inner lifecycle. |
| Publication/recovery | fixed current pointer, exact transaction/journal/incarnation/disposition | Consume existing authoritative completed recovery outcome; do not run recovery during preparation. Recovery changes sources, so discard old E/Work and reprepare. |

Relevant string spans are decoded only after reserving their complete required capacity, with checked lengths and native path limits. A path larger than the native addressing domain or remaining configured memory returns a typed limit, never truncation. Unknown large values are streamed/skipped after full syntax/type representability validation; no maps/arrays/strings are materialized. Recognized key comparison uses exact chunk-decoded bytes, not hash equality.

Numeric validation must match the pinned ordinary control loader, including ignored numeric values: lexical JSON alone must not admit an out-of-range number that the current loader rejects. The selected bounded numeric projection is the pinned parse-state algorithm over streamed spans (checked integer accumulator, significand/exponent overflow state, finite-result predicate), shared with S3's scalar facts; schema_version additionally requires current `Number::as_u64` semantics. Differential tests include long zeros, overflow exponents, decimal/exponent versions, duplicate keys and huge ignored strings. No float_roundtrip feature change or arbitrary total-control-file cutoff is introduced. Until this exact projection is implemented/tested, Ready remains disabled; a narrower grammar must not be presented as full compatibility.

Fresh authority reads only fixed-size stamps/control headers and kernel proof. JSON scanning, scalar/path decoding, hashing, reference traversal and error-string formatting stay outside authority and reader-facing state.lock. B's direct native paths avoid uncharged CString/wide Vec allocation; full authority reserves its fixed FD/scratch/projection floor in the same account before the real permit.

## 3. Owned workspace registration and local state

A collectible root must be factory-created under an actual registered storage scope, never merely discovered by prefix or use-guard participation. Proposed fixed `WorkspaceControl` record binds:

- protocol version and kind (managed run / stable worker workspace / stable registered phase workspace);
- repository/destination/registry/root physical IDs and random incarnation nonce;
- stable writer/worker/registry-gate/root-use identities;
- actual incarnation-local run/lifecycle lease IDs and parent-run control/nonce if nested;
- `source_epoch`, `admission_epoch`, child registration generation/coverage/counts;
- state and an authoritative terminal disposition;
- exact cleanup barrier and publication/recovery control identities/stamps.

Payload layouts, paths and ownership inventories remain S3's domain. The record is application provenance/change evidence, not authentication against a malicious same-user writer. It has private capability constructors at actual successful factory events, not a function accepting arbitrary caller-provided identities. Fresh creation establishes child-registration coverage before launches. A failed initial optional coverage setup can leave a new workspace untracked/Unknown; a previously covered workspace must invalidate its coverage/version BEFORE any incompatible effect, or fail the producer before that effect. Ordinary validated committed reads never depend on these controls.

`source_epoch` identifies the sealed source/payload incarnation. After Quiescent it is immutable; janitor-owned control/progress files are not payload source leaves. `admission_epoch` changes at each local authority transition. `child_generation`/closure cursor tracks registration/closure, while private `stage_generation` tracks journal progress. Updating a stage frame never changes source_epoch or refreshes eligibility.

### Local finite states

| State | Entry condition | Allowed next action |
|---|---|---|
| Building | actual owner run/worker lease; factory coverage bound | Owner source mutation first increments source/admission version. Launch registration first dirties/increments child generation, binds exact child, then completes registration. |
| NeedsRecovery | Publishing, unresolved transaction/result, missing coherent outcome | Release maintenance authority; S4 requests real admitted recovery; discard old preparation. Recovery either restores Building with a new source version or mints a terminal disposition. |
| OwnerTerminal | exact authoritative PublishedAndConsumed or AbortedNotPublished outcome, actual owner/worker no longer consuming results | Under exact stable writer/worker/registry gates + actual parent run lease, freeze this root into Closing; invalidate current global reference epoch before changing source/eligibility controls. |
| Closing | registration generation frozen; new launch/source mutation denied | Fair per-child fresh grants: acquire only that exact lifecycle lease, recheck prepared controls, prove current kernel emptiness, publish Closed child token/cursor. Unknown/live child stays protected; other roots progress independently. |
| Quiescent | parent terminal/barrier/recovery proof; frozen complete child coverage; all registered children individually Closed | Seal immutable source_epoch and closure witness under exact owner/gates; invalidate current global epoch before this eligibility change. Start/resume inert private leaf-frame journal preparation. |
| RetiringLeaf | actual local admission version validated before its own increment; exact prepared leaf/journal/parent/native-use proof | Publish durable leaf rename intent, invalidate global references, rename ONLY selected exact leaf, commit private physical fact. Return to Quiescent with new admission_epoch; next leaf is freshly prepared. |
| RemovingControls | payload/known child directories atomically empty; durable RootRemovalIntent | Under stable gates, close/unlink exact incarnation controls/leases last; drop those actual handles before Windows empty-directory removal; retry Pending deletion/NotEmpty without touching unknown children. |
| Removed | exact public root absent after atomic-empty removal | Reconcile only its own durable removal intent. A fresh root at the same public name is a different nonce/identity and cannot be targeted. |

The terminal disposition is not inferred from enum spelling/PID/age/lease availability alone. `materialization_worker` currently retains its worker lease through result consumption/removal; this boundary must remain. A parent still consuming a result makes admission Busy. RunWorkspace's actual run lease, scope, absolute cleanup barrier and publication disposition are all required. Unknown/unassociated child process evidence blocks that enclosing root's quiescence, while an unrelated sibling root does not become a prerequisite for local proof.

Registration coverage is a local bounded certificate: compatible factories increment/dirtify before every child creation and bind the exact lifecycle/lease before completing registration. Closing freezes that generation. A full advisory audit checks one-to-one current child association and unknown evidence outside authority; Closed child records/cursor accumulate over grants under the frozen generation. No whole registry traversal occurs under a grant, and no restart of the first100 children is allowed. Quiescent is minted only from complete coverage plus all exact child closure proofs. Old/uncovered roots cannot bootstrap this certificate from shape or count: use S3's already approved exact-incarnation controlled association/quiescence path, or retain Unknown.

## 4. Startup gate and final incarnation-lock removal

Stable registry startup gates/cohort records are outside public payload registries so canonical emptiness can be probed literally. Stable destination writer/state/use/database-family gates are also outside every selectable payload/cleanup set.

For every **collectible** creation/launch:

1. Acquire actual startup gate Shared BEFORE root/child creation or opening a potentially blocking lifecycle lease. Check registered root/parent nonce and Building state. Serialize registration metadata with its small fixed header lock.
2. Child independently opens the same stable startup gate and acquires its OWN Shared lock BEFORE lifecycle acquisition. Parent retains its own independently acquired Shared lock until readiness. An inherited FD/HANDLE is never the child proof: fs2 unlock/drop and process death semantics are not portable ownership transfer. Child rechecks root/parent nonce and Building after Shared acquisition. If parent dies before child Shared acquisition, janitor may win Exclusive and publish Closed; the late child must then refuse. If child wins Shared first, it blocks janitor until its own lifecycle lease and post-lock checks succeed.
3. Guardian acquires its existing lifecycle lease, then verifies the held FD equals the current named lease, current root and parent physical IDs/nonces match the launch scope, and neither root nor lifecycle is Closing/Closed/Retiring/receipt-complete. Only then create/adopt native work and release startup ownership after lifetime lease/registered containment is established.
4. Missing/replaced controls or a closed incarnation refuse BEFORE data mutation/spawn. Repeat the identity/state check after any blocked lease acquisition. Never recreate a missing lease/control to revive a closed root.

Janitor takes stable startup gate Exclusive nonblockingly BEFORE local incarnation leases. A queued startup holding Shared prevents janitor from declaring the world empty. Once a guardian has handed off, its retained lifecycle lease/kernel proof protects live work. Gate failure is Busy, not cancellation/teardown. All actual acquisitions are nonblocking for maintenance. This prevents own-shared/exclusive deadlock and late-start-after-retirement races without moving stable coordination.

Current v2 `run_guardian` checks retired/receipt/path existence after acquiring a lease but does not compare a held old lease to a replacement public incarnation. The new check and independent child startup capability must be deployed for modern covered roots before their controls may be removed. Unupgraded/legacy roots remain excluded until exact compatible-cohort quiescence/association; no live shutdown is automated. Low-level fallback beside caller-owned candidate data keeps its existing execution behavior and never receives collectible scope.

Last-control cleanup is separate from leaf payload retirement. RootRemovalIntent is durable before removing any incarnation-local lease/control. Retain stable writer/worker/registry ownership throughout. Closed/missing version controls make every compatible late actor refuse; actual FD/root/nonce mismatch protects a fresh public root. On Windows, a waiter may keep an unlinked lease pending deletion: close janitor's incarnation handles, attempt atomic-empty rmdir once, then yield Pending rather than wait. Unknown children cause NotEmpty and stay public. Replay never recreates a deleted run lease or deletes an unknown child to force emptiness.

## 5. Three bounded authorities and bulk-offslot callbacks

These proposed signatures replace consuming Work/PreparedMaintenance parameters. They are not implemented or cleared yet.

```rust
// S3 owns Work, paths, sources, journal frames and reservations offslot.
// Hot frames borrow exact native paths/encoded bytes and fixed stamps only.
struct CanonicalHotFrame<'a> { /* same verified global E, config, roots, structurally empty registries */ }
struct LocalWorkspaceHotFrame<'a> { /* selected leaf + enclosing terminal source/versions/closure */ }
struct JournalStageHotFrame<'a> { /* journal-only origin/stamp/sourceE/stageG/one fixed frame */ }

// S2 constructs private !Send/!Sync actual authority on the mutation thread.
struct CanonicalAuthority<'a> { /* fixed owned handles, borrowed grant/hot facts */ }
struct TerminalWorkspaceLease<'a> { /* enclosing owner/gates + exact leaf/native exclusion */ }
struct JournalStageLease<'a> { /* same journal coordination held through check+append */ }

// Fixed, nonallocating, no Drop-heavy fields. Detached fact/proof binds ONE
// exact moved leaf, its private parent/journal identities and source incarnation.
enum TransitionFact { NoEffect, Progress, Detached(DetachedWorkspaceProof), Removed }

fn try_with_canonical(
    hot: &CanonicalHotFrame<'_>, grant: &mut MutationGrant,
    scratch: &mut FixedAuthorityScratch, effect: &mut impl CanonicalEffect,
) -> Result<TransitionFact, AdmissionFailure>;
fn try_with_terminal_workspace(
    hot: &LocalWorkspaceHotFrame<'_>, grant: &mut MutationGrant,
    scratch: &mut FixedAuthorityScratch, effect: &mut impl WorkspaceEffect,
) -> Result<TransitionFact, AdmissionFailure>;
fn try_with_journal_stage(
    hot: &JournalStageHotFrame<'_>, grant: &mut MutationGrant,
    scratch: &mut FixedAuthorityScratch, effect: &mut impl JournalStageEffect,
) -> Result<TransitionFact, AdmissionFailure>;

// S3's borrowed effect gets S2's ephemeral exact lease and one prepared frame;
// no owned Work, all-frames Vec, parser or path clone crosses this interface.
trait WorkspaceEffect {
    fn apply(&mut self, lease: &mut TerminalWorkspaceLease<'_>,
             frame: &PreparedLeafFrame<'_>) -> Result<TransitionFact, AdmissionFailure>;
}
```

S3's current single-payload JournalFacts equality is retained: source leaf inode == actual private leaf inode after rename. A per-leaf private parent may be created only from its own exact creation binding; that parent does not inherit ownership of other files. DetachedWorkspaceProof contains fixed root/journal/private-parent/address/incarnation facts, no actual authority or arbitrary public path. S3 reconstructs any owned path/reservation wrapper OFF slot from that fixed proof. Private disposal prepares one leaf outside authority, then reacquires only exact private coordination and rechecks the bound leaf before unlink. No original-public-name fallback or unrelated global registry scan exists.

S4 pattern: Work and borrowed effect context are declared outside the mutation closure. Start grant BEFORE trying the real execution permit. Inside a catch/unwind boundary acquire the real permit and invoke S2 with borrowed hot frame/context. S2's fixed guards drop first on success/error/panic, then the real permit drops. Only after this boundary may the controller discard/replace/drop Work, decoder state, results or buffers. No authority parks in a job/result/queue; no Owned Work parameter can be consumed by an unsuccessful admission. Prepared facts/reservations are Send; actual grant/authority is !Send/!Sync.

Canonical authority: exact writer -> worker -> registry/startup Exclusive -> artifact/root/database-family exclusions and applicable state ordering. After fixed control validation, use section10's fixed structural probe: Managed literal empty; Direct outer permits only identity-bound phases and its empty contents, then rejects any next outer entry. Under actual exclusive reference activity+serial, compare captured verified global E BEFORE exact own E+1 using B/C; no shared activity is acquired first. Short state sections only check fixed current evidence and execute the reserved action. Config/descriptor/reference JSON and hashing never occur there.

Local authority: exact writer/worker/startup/parent-run/lifecycle/native-family exclusions, root-use Shared, local source/admission/control stamps and quiescence witness. Require local captured admission epoch before its own increment; source_epoch stays sealed. To invalidate global cached references, acquire existing activity Shared plus serial Exclusive and advance the CURRENT covered global epoch before reference/eligibility effects, retaining Shared activity through the transition. It NEVER calls global exclusive observation or claims complete global references. Another unrelated producer's Shared activity can coexist. Missing/inconsistent coverage is Pending/Unknown, never a fake canonical E. This separate local invalidation primitive still needs its own focused implementation review.

Private journal-only authority: current target/private-root origin, same exact journal lock and stage generation, no destination writer/state/family/exclusive-artifact authority. Appending an inert frame changes only stage_generation/cursor. Hold the SAME journal coordination through completed-stamp check and any Sealed/Detaching phase publication, so an appender cannot extend it between proof and effect. No canonical admission/global-E increment is used merely to append metadata. Real dispatcher permit and the same MutationGrant still apply to its filesystem effects.

## 6. Source identity, journal progress and physical transition

| Axis | Meaning | May change during inert staging? |
|---|---|---|
| source_epoch E_s | immutable sealed payload/source incarnation, exact enclosing root/nonce and selected leaf proof | No. Changed source discards eligibility; never retag old frames. |
| local admission epoch A | current controlled local state version | Only an explicitly admitted local transition changes it; capture/recheck before own A+1. Own journal records bind the exact prior/next versions. |
| journal stage_generation G | committed segment/frame prefix and logical cursor | Yes. Appends resume the prior committed prefix rather than restarting. |
| physical detach state D | Public, Intent, MatchingPrivate, Disposing, Done, Unknown | Derived from actual current source/private identities plus durable own journal, never a reducer bool alone. |

For a selected leaf the durable order is: complete inert frame/source proof -> fresh local admission checks -> Prepared rename intent binding exact source/private identities and own A->A+1 -> global invalidation before reference effects -> local Retiring admission version -> exact leaf rename -> parent durability -> Detached journal commit. No whole workspace is moved. On the next leaf, perform fresh local preparation at its current A; do not carry a global reference set through workspace mutations. Sealed source epoch/leaf origin identifies the source generation, while progress/removal facts describe known own deltas; unrelated recovery/source writes invalidate it.

More than100 leaves requires multiple journal grants/processes, not one all-frames proof under authority. Each bounded logical segment occupies a committed range of the one prebound stream; stream inode binding, sourceE, frame range/hash and monotone logical cursor are retained. No segment file is created per grant. A crash resumes the earlier durable committed prefix. Final single-leaf detach retains journal coordination, checks the completed exact frame and physical source, then makes one transition. A previous stage-generation update never invalidates/relabels sourceE.

## 7. Filesystem effect accounting

The same grant starts before dispatcher/storage admission. Every independently examined entry consumes admission allowance before its fixed check. Before the FIRST effect, atomically reserve the entire known action cost; no partially reserved transition begins. Afterwards use check_time before each already-reserved effect (remaining_entries may correctly be0). Individual calls/fsync can overrun; no syscall/exit deadline is promised.

Conservative counting is permitted. Publication uses the prebound slot protocol in section10; old temp+rename P=4 is withdrawn. P_b costs6 existing-entry effects (intent write/readback2, inactive slot write/readback2, selector write/readback2), each write includes file sync. All admission/path/control reads additionally consume one entry each; native scalar fields from one fixed open are a single charged observation, never an unbounded traversal. Directory fsync is charged separately where an entry changes.

| Action | Complete reserved effect cost, excluding charged fixed admission checks |
|---|---|
| Initialize root publisher at genuine factory creation | Three fixed files create/write/sync3 + parent sync1 + fixed inode-binding publication (bound existing factory record write/readback2) =6; readback3 =9 total. If the prebound journal stream is also created, add create/write/sync1 + readback1 =2, with the same already charged parent sync and factory binding, for11 total. Crash before binding makes this root permanently untracked for automatic collection, with no new slot/job allocation on retry. |
| Append one inert bounded frame to prebound stream | AppendIntent P_b6 + stream positioned append/sync/readback2 + committed cursor P_b6 =14; stageG changes, sourceE/globalE do not. |
| Enter Closing / seal Quiescent | local control P_b6 + current-global fixed epoch write/readback2 + closure header P_b6 =14 |
| Close one lifecycle and advance closure cursor | Closed token P_b6 + cursor P_b6 =12 |
| Detach exact leaf | intent P_b6 + global epoch2 + local admission P_b6 + rename entries2 + source/private parent sync2 + Detached P_b6 =24 |
| Unlink exact private leaf / remove atomic-empty directory | effect1 + parent sync1 + progress P_b6 =8 |
| Final incarnation controls | RootRemovalIntent P_b6 + K exact unlinks K + parent sync1 + root rmdir1 + parent sync1 + completion P_b6 =K+15. Fixed-schema K; recoverably split if total plus admission exceeds100. |
| Private parent creation | create directory1 + parent sync1 + creation-binding P_b6 =8, plus readback1 =9. Must be tied to original exact leaf frame before any payload moves; crash before binding retains unknown parent and cannot allocate another per attempt. |
| Housekeeping | each exact unlink/rmdir1 + parent sync1 + progress P_b6 when required. |

Directory rename changes only the two selected leaf directory entries; it does not authorize deletion of descendants. A big workspace is many separate leaf effects. No recursive removal exists. Too-small or zero grants return with no effects, including metadata/marker/cursor effects. Fixed native registry first-entry/descriptor probes avoid unbounded hidden scans/allocations under authority. Current B/C already demonstrates full epoch effect+readback reservation and last reserved entry behavior; the full action adapter must use the same accounting semantics.

## 8. Crash, stale and late-start outcomes

| Boundary | Required recovery/result |
|---|---|
| Preparation / journal prefix while source changes | Discard source eligibility; retain only exact owned inert journal for bounded disposal/resume where sourceE still matches. Never adopt a newer E. |
| Closing intent durable, child live/unknown | Keep root public; report Pending; process other eligible roots. Do not manufacture emptiness or erase barrier evidence. |
| Closed child marker/cursor torn | Recover only exact own bound inode/prefix; unknown bytes stay unknown. Frozen registration generation and complete closure coverage are rechecked before Quiescent. |
| Global invalidation succeeds before intent/local state completes | Old global proofs are stale. Resume only own durable journal/version transition or reprepare; no old global-reference relabeling. |
| Prepared leaf intent durable, source still public | Recheck exact source/private absence and same local source/admission transition; resume or retain Unknown. Do not touch a replacement source. |
| Rename happened before Detached commit | Exact source inode at the recorded private leaf + own durable intent allows completion under the same journal lock. No private match =>Unknown; never synthesize Detached. |
| Fresh public leaf/root reuses the name | Private replay addresses only its bound private leaf; root/lease/nonce mismatch refuses late startup or cleanup. Fresh public data survives. |
| Parent result not consumed / Publishing | Busy or NeedsRecovery; release authority and old Work before real admitted recovery. No inner lifecycle Empty bypass. |
| Unknown file inserted in nested directory | It remains public because only exact selected leaves move; rmdir fails NotEmpty. No top-directory timestamp is treated as recursive coverage. |
| Lease waiter paused before acquisition | Child-owned Shared startup gate prevents janitor closure; a child arriving after janitor Closed refuses; after any blocked acquisition, exact current FD/root/nonce/Closed checks precede native work. |
| Run/lifecycle control unlinked with Windows waiter handle | Yield Pending deletion/NotEmpty under durable removal intent. Do not wait, recreate controls or force-delete unknown children. |
| Cancellation/error/panic | Fixed actual authority drops before execution permit; bulk Work/buffers drop outside. Durable exact intents/prefixes remain for replay. |
| Permission failure / blocked first candidate | Retain journal, rotate logical cursor/categories and service later candidates. Restored permission permits progress. |

## 9. Implementation slices and required executed evidence

No code for these slices is cleared by this artifact. Coordinator records selected interfaces/source ownership in Scryer first; fresh Max gate then grants bounded slices.

1. **Control projections / fixed directory probe:** S2 implementation, S3 scanner shared APIs read-only. Differential config/descriptor/scope semantics versus current readers, huge ignored strings/long numeric spans, duplicate/null/missing fields, exact memory peak/overflow and source substitution. Probe empty versus first unknown entry in a registry with>1000 children without full scan. No Ready yet.
2. **Local control/startup protocol:** coordinator transfers exact `RunWorkspace`, stable materialization-worker/phase factories and `process_lifecycle::{mod,unix,windows}` hooks to one writer per file. Add new scoped capability only for registered owned roots; caller fallback stays excluded. Tests pause creator before lease, guardian before/after blocked acquisition, parent death before/after independently acquired child Shared gate, result consumption, Publishing recovery, root/name replacement and Windows pending-delete. No detach until proof is reviewed.
3. **Private journal stage authority:** S2 actual capability + S3 exact frame/reducer under agreed ownership.>100 leaves across fresh processes; stageG advances without globalE changes/restarting; source change invalidates eligibility; no effects for zero/small grants; same journal lock blocks appender through seal/detach.
4. **Local leaf admission / opaque private proof:** enclosing owner+barrier+recovery+closure+native-use authority; selected actual leaf only. Concurrent unrelated Shared reference producer stays live while terminal siblings make progress. Foreign nested child remains public. No old generic claim/revalidate or whole-tree path.
5. **Canonical integration / S4 operation:** complete config/references at verified E, fixed structurally empty registries, B/C exact E comparison/invalidation and bounded effects. Preparation/disposal paused while real MCP reads/writer admission continue; cancellation joins/drains. Aggregate memory includes results/paths/decoder/destructor lifetime. Native Windows qualification uses the established native-tests/xtask recipe, not an ordinary release-only test command.

Acceptance:>100/1000 eligible terminals converge with blocked-first/live/unknown siblings retained; only unknown/live public roots keep global canonical admission Pending. Current cache/active graph/result semantics remain unchanged. Every effect/cancellation/crash boundary above has executed fixture-owned evidence; native platforms and aggregate closure remain distinct. No live process termination, shutdown, deployment, user-data cleanup, Git/wiki/model mutation or new repository memory candidate accompanies this design artifact.


## 10. Focused-review successor: selected corrections and exact publisher

This immutable successor supersedes the predecessor SHA8e50debf6e31edd9e04e5d3dd04f63ea87dfb6f059c4ec7eff0cf7dff5d1fffa wherever it differs. It remains DESIGN ONLY. The committed B/C foundation is993212c7f1ef0829e6d134f7ce3a0195e068bdc1; the private artifact nonce bug fix is separately under verification, not presumed accepted.

### Structural registry proof

Managed worker/phase registries use literal emptiness. Direct worker root has its existing literal `phases` directory. A fixed probe permits ONLY that exact name after no-symlink/native directory identity proof, then a fixed first-entry probe of its phase directory must be empty, and the outer iterator must return no next real entry. Any additional entry, replacement phases inode, wrong type, alias, traversal spelling, or symlink yields Unknown/Pending. This examines at most two outer entries plus the first inner entry, with fixed scratch; it does not recursively enumerate. Stable gates remain outside selectable payload. Unknown/live siblings stay public. Direct persisted journal/address strings are never canonicalized by this protocol.

### Fixed local-global invalidation exception

A local terminal-root action takes existing activity Shared and serial Exclusive, never exclusive global observation. Under those actual guards, but OUTSIDE reader-facing state.lock, it reads exactly one supported2048-byte fixed reference epoch record using charged fixed scratch; validates exact magic/schema/root/use-nonce/checksum and checked counter arithmetic; patches only CURRENT counter and checksum in the same scratch; writes/syncs then exact readback-validates. The fresh grant began before admission. Reading and checking costs one charged entry; write/readback costs2, fully reserved before effects. Hashing exactly this2048-byte control is an explicit bounded exception, not permission for payload hashes or JSON. Overflow, unsupported layout, short/extra/torn bytes, stale coordination nonce, or readback mismatch fails closed. All subsequent effects require the successful actual before/after fact. Torn control becomes NeedsRecovery; no old seal is retagged, no general serde decode or phase walk runs under these guards. Existing canonical C primitive still compares captured E before E+1; the local lane records CURRENT global before/after separately from RootSourceEpoch and local A before/after.

### Fixed PREBOUND publisher, initialization and resume

Choose one fixed publisher per genuinely owned root, not per key/attempt. The factory creates exactly three fixed control files: data0,data1,selector. Each data slot has fixed maximum layout, root nonce, its own identity, generation, operation kind, full bounded state payload and checksum. Selector includes bound identities of both slots, committed generation/slot/checksum, and an in-place intent area binding prior and next generation plus expected next bytes/checksum. Files never rename or truncate; slots must support the complete fixed control schema. A separately prebound fixed journal stream is created/bound at the same successful factory event when staging is needed. No arbitrary JSON or variable payload is stored in these controls.

Factory owns actual Exclusive root/startup controls while creating, syncing, fresh-address validating and binding these exact inodes into its already established creation record. It publishes covered Building only after the binding is durable and verified. Crash before durable binding leaves the root Untracked/Unknown. A later observer neither repairs nor adopts orphan files, and does not allocate another publisher/job on repeated advisory passes. Such a root requires the already approved explicit controlled association/quiescence path; ordinary production/reads remain available according to their existing policy. This intentionally retains a finite unknown initialization remnant instead of claiming evidence that never committed. Once bound, all repeated updates/resume use only the same fixed inodes; no per-attempt orphan stream exists.

An admitted update verifies all bound identities and previous selector generation; reserves P_b6; writes/syncs+readback validates selector intent; writes/syncs+readback validates inactive data slot; writes/syncs+readback validates committed selector. Each check_time precedes its reserved effect. No time or entry budget renewal occurs between them. A slow fsync may consume the deadline: stop before the next syscall and yield durable Pending intent. Next fresh grant reopens exact bound files, validates intent and expected slot checksum, and resumes the precise next step. Neither old selection nor new selection is inferred from highest slot generation. Invalid/torn selector means NeedsRecovery; previous proof cannot be used. Recovery is a separately admitted exact-control transition and must reconstruct from durable intent plus physical facts; ambiguity retains Unknown. Fixed controls never authorize a payload rename solely from an intent.

Inert leaf frames use one prebound append stream, not one newly named segment per grant. A prepared fixed-size frame is assembled/reserved outside authority. Publish AppendIntent binding stream identity, prior committed length/hash, expected offset/frame/hash and nextG (P_b6); positioned append/sync+exact readback2; publish committed cursor/G (P_b6). A failed or partial append does not advance the committed prefix. Resume at the same bound offset, never allocate another stream or silently append after unknown tail. SourceE remains immutable and separate. Exact stream/intent inconsistency returns NeedsRecovery, and unrelated source/recovery discards the old eligibility rather than rebasing it.

### Required S3 codec contract

S3 single-leaf source-incarnation == private-incarnation equality is preserved. Local workspace event adds explicit RootSourceEpoch, localAdmissionBefore/After and actualGlobalBefore/After fields; it MUST NOT reuse canonical OwnEpochAdvanced's immutable source_epoch equality. StageGeneration/cursor is separate. DetachedWorkspaceProof is minted only from the actual rename/readback state under TerminalWorkspaceLease, with bound journal/private-parent/exact source leaf facts. No new multi-leaf container inherits leaf ownership. S3 owns all bulk frame/origin/journal preparation and reservations outside authority; only borrowed fixed frame crosses S2 callbacks. Journal-only grants never acquire destination/state/family authorities or increment global E merely for staging.

### Focused acceptance evidence required before effects

Pause each prebinding creation/sync/binding cut: no covered scope before final verified binding, no observer repair, no retry-created orphan series. Pause P_b after each write/sync/readback: resume exact bound inodes/generation or retain Unknown, never choose uncommitted maximum generation. Exercise partial stream append and>100frames across fresh processes with immutable sourceE and increasingG. Pause child before OWN Shared startup acquisition, after Shared, before/after lifecycle; kill parent at each cut and verify late-after-Closed refusal versus child-owned Shared exclusion. Direct structural phases-only root succeeds; unknown outer/inner sibling/replaced phases survives. Run local terminal cleanup while unrelated actual producer retains Shared global activity; prove no exclusive global acquisition and no blocked self-shared upgrade. Tests include zero/expired/last-entry grants, slow fsync cuts, panic/error drop order, source/nonce substitution and exact current-global overflow/torn bytes. Native Windows execution remains a separate gate.
