# S3 OriginOnly GC qualification

Proceed with the selected split. No decision-blocking contradiction with the approved DC retention/recovery contract was found. This is an additive qualification of the existing proposal review, not whole-collector acceptance or permission for live cleanup.

Reviewer: GPT-6.1 Sol / Max, read-only adversarial-proposal-review-engineer, 2026-10-21. Scope: the distinction between modern retirement eligibility and loader usability; no source or implementation re-review.

## Exact inputs and authority

- Producer-effects proposal v2: `/private/tmp/dc-s3-producer-leaf-effects-gate-20261021-v2.md`, SHA-256 `44391219454b4265529f8d766f40603f9aee71a2b34548d6449549c92a4d4231`.
- Existing effects review: `/private/tmp/cleanup-v2-proposal-review-Ox0SyW/s3_producer_effects_v2_review.md`, SHA-256 `cec734298bb4beef5bf49def687024211017cfc22051983de0329f9329330f29`.
- Existing mechanism review: `/private/tmp/cleanup-v2-proposal-review-Ox0SyW/s3_mechanism_review.md`, SHA-256 `58e5d1a207da3164e68355d1c0389a9f8a2356e9cee02a23bbff1f9ae0f18ea5`.
- Approved existing canonical contract: `architecture/graph-disk-cleanup-contract`, revision 0.2, and the coordinator's explicit same-scope approval/Scryer intent. The local MCP-authored contract copy now has SHA-256 `b8064a83767fee30f1ce7b991ee1e515f7ee340ac2fb826cccac68dd2923dc61`; relevant DC-S3-R1/R2/R6/R7/R8, A2 and the entry-origin paragraph were re-read. The previously verified approved authoring hash remains `f7cacf81e39eb67affea10e07e3aa067ef50c093d3ea86d15bfe33ab6772d41b`; subsequent evidence additions do not advance approval scope. The known stale k-wiki reader is not used to override approved v0.2 intent.

## Selected proof boundary

Modern GC may consume genuine completed origin for the actual role/state, unchanged exact leaf integrity/incarnation, strict owned filesystem shape, and complete fresh absence of active/live-run/recovery need under the proper S2 authority. It need not construct LoaderUsable. Completion, publication and exact identity remain distinct facts; a completed temporary does not gain a fabricated canonical publication event.

A known producer's unchanged bytes can fail the ordinary loader while remaining genuinely owned bytes. Examples include nonfinite f64 serialized by the producer as `null`, and a witnessed numeric token that changes on the pinned parse/re-serialize roundtrip. Such incompatibility does not itself invalidate an actual completed-origin receipt or prove the witnessed file was corrupted. Modern GC may retire that unnecessary leaf without running the schema/raw-row join needed to certify usability.

Receipt, digest, physical identity, role or stamp mismatch remains unknown. A failed loader is not origin evidence. Unsupported or incomplete reference/recovery coverage still prevents retirement. Active or potentially necessary recovery bytes stay protected even when known unusable.

BACKUPRESTORE still requires independently established LoaderUsable plus exact expected-entry association and fresh current-reference/recovery proof. An OriginOnly receipt cannot justify restoring bytes as a usable cache. DC-S3-R2's invalid/ambiguous recovery-evidence preservation remains: unresolved backup necessity/association is not converted to disposable by a loader failure. Only independently proven unnecessary modern bytes may use the modern GC route.

Legacy adoption where origin is otherwise unproven retains the selected full historical producer/association/coherence and usability requirements under verified quiescence. This qualification provides no shape-only legacy origin, no unknown-directory ownership and no permission to move an unknown-containing canonical directory.

## Qualification of prior wording

The effects review's sentence that OriginOnly does not bypass the pinned LoaderUsable checks applies when constructing LoaderUsable or restoring/adopting through a route that requires it. Read as a universal modern GC prerequisite, it is too broad and is withdrawn to that extent. Proposal v2's independent usability composition is needed for those usability-dependent operations, not every modern receipt-backed retirement.

The original mechanism review's numeric/depth/metadata-policy requirements remain correct for LoaderUsable/ProducedUsable. Its original hashed artifact and the later serializer qualification remain unchanged. No parser or checksum rewriting is selected.

## Focused verification at implementation review

1. Exact completed modern origin with unchanged loader-incompatible bytes and complete fresh absence can retire; the same leaf with an active/recovery reference cannot.
2. Mismatched integrity/incarnation, incomplete origin and incomplete absence remain protected; neither failed loading nor a plausible envelope upgrades them.
3. OriginOnly alone cannot produce a restore/adoption witness; a usable referenced backup follows recovery before any removal.

These are required future checks, not executed results. Existing S2 v3 clearance is unchanged. S4's external monitor-stop token and shared join-state/Condvar refinement is within the previously selected lifecycle boundary; fresh implementation review still verifies actual drain, simultaneous joiners, self-join avoidance, notifications, panic and resource drop.

No Cargo, source/model/wiki/Git/ticket writes, probes or live cleanup were performed. Only this scratch artifact was written. Reusable-knowledge assessment: this is a clarification of an approved proof distinction; the coordinator owns canonical/Scryer reconciliation, and no additional memory candidate is created by this read-only review.
