# S2 publication factory extension: focused clearance

Proceed with the narrow factory/binding/publisher implementation under the exact selected addendum below, after the separately reviewed capability/slot foundation is accepted and source/manifest ownership is assigned. No remaining design blocker was found for that commitment. This does not enable Ready, collection, stream journal adoption or S3 producer callers before their independent prerequisites.

GPT-6.1 Sol / Max, read-only adversarial-proposal-review-engineer, 2026-10-21. Approved DC revision0.2 / Scryer chg-6vx5tj. No new product decision.

Verified inputs:

- Extension `/private/tmp/dc-s2-publication-factory-extension-20261021.md`, SHA-256 `b2d6ce12530c4f96a9b1985d3ab2449b4cc41c4d9ba1f36e0f99ce3d691b8f96`.
- Exact implementation addendum `/private/tmp/dc-s2-publication-factory-extension-addendum-20261021.md`, SHA-256 `1bd90983b6591fb3c29d753cca85ccb4e8282c9891cf27f290b389e02c530564`.
- Existing accepted v3 design SHA-256 `88f647d10406eb44646f38430b3098cb7db6c1df07c3d99f5563866ef5c2478e`; its Commit/Intent witness condition is preserved.
- Source inspected only as implementation evidence: frozen `/private/tmp/cleanup-s2-cap-controls-successor-rdqnse82/repo/src/storage/{maintenance_ownership.rs,maintenance_controls.rs}`. Author supplied patch `6b6f7f88e96b9b6c74e85933600721b44e5f417f73ade63bf8f52b58936d5cad` and 133+6 passing execution results; this proposal review neither reruns nor independently accepts those results. Actual factory/effect hooks are absent from that snapshot.

## Exact selected schema and entry costs

Five reserved root-relative names are data0, data1, selector, stream and binding, each with the `.publication.` prefix. NoStream creates four; WithStream creates all five. No variable user component or per-attempt publisher/job name is introduced.

Slots are2136 bytes; selector is2392 = Commit128 + Intent2264. Intent contains the complete next slot. Commit/Intent checksums and write ranges are independent; publishing either must preserve the other durable witness. Existing pure codecs implement those lengths; they do not themselves attest physical ownership.

Binding is exactly512 bytes: magic/version/rootnonce; actual root/use/data0/data1/selector identities; explicit stream mode and identity; zero reserved bytes and checksum. The two-u64 FileIdentity encoding preserves the existing identity domain. NoStream=0 requires zero stream-ID bytes and yields None. WithStream=1 requires the actual independently verified stream identity; an all-zero/default tuple never implies stream presence. Unsupported versions/modes and nonzero reserved bytes fail closed.

The addendum resolves the undefined initial stream header: WithStream creates a deliberately ZERO-LENGTH bound inode, fsyncs it and verifies exact EOF/identity. It establishes neither sourceE, stageG, a journal prefix nor disposal authority. S3's later actual source/journal binding is required before append. NoStream cannot later create/adopt a missing stream through ordinary acquisition.

Effect arithmetic is correct under the already selected conservative counting convention: with stream4 create/write/sync +4 exact readbacks +first root sync1 +binding create/write/sync1 +binding readback1 +final root sync1 =12. Without stream this is3+3+1+1+1+1=10. The final directory sync is necessary for the newly created binding name. Root mkdir/parent durability/use-header/cohort publication remain additional base effects. Ordinary primary creation is outside cleanup permits; a future maintenance creator is NOT cleared to hide those effects in12/10.

P_b6 remains intent write/readback2, inactive slot write/readback2, Commit write/readback2, each write including sync. No new inode/rename is introduced per update. Staging14 and all admission observations remain separately charged. Whole action reservation precedes first effect; fresh time checks precede each already-reserved effect, including when remaining-entry count is zero.

## Creation, failure and memory boundary

Only actual successful create_dir branches may initialize. Frozen source identifies ensure_root and acquire_shared(created=true), retaining actual Exclusive use ownership. Existing-root/observer/retry paths never call the factory, repair a prefix, replace a control or allocate another set. A partial initial set stays finite Unknown. The separate binding preserves accepted cohort/header/B/C bytes.

Anchor creation to the actual held directory FD/HANDLE and current root/use nonce, including header, controls, binding and cohort. Establish and validate that anchor BEFORE the first header write; placing a helper after header initialization cannot retroactively anchor earlier effects. Unix fixed-name openat with exclusive-create/no-follow and Windows actual RootDirectory-relative creation are the selected mechanisms. Keep the anchor/use ownership through final association/content/identity checks. A substituted public root yields no attestation and cannot redirect later creates. No joined-path Windows fallback is cleared.

Optional control/binding failure disables attestation; it does not override existing required header/cohort/reference-invalidation failures. It cannot authorize unknown replacement. The author's clarified primary behavior is the already selected S3 no-replace, exact fresh-byte equality or safe prepublication-error lane. Proposal wording about ordinary replacement is subject to that boundary; retaining an unproven backup alone does not permit moving an unknown-containing directory.

Factory scratch is7432 simultaneous inline BYTE storage = Slot2136 + Selector2392 + Binding512 + Readback2392, plus separately explicit native metadata/name scratch and fixed facts. The slot buffer is reused sequentially. This is a fixed primary-operation cost, not a second cleanup ceiling or a full-memory claim for7432 alone. Maintenance preparation instead reserves every simultaneous image, duplicate/readback/effect buffer, path encoding, owner/hotframe, parser/stack/native scratch from the SAME CleanupMemory before allocation, keeping data charged through off-permit disposal. No sizeof-only heap estimate or double-use of a reservation is accepted.

Actual admitted publication uses prepared fixed bytes/stamps/native paths and borrowed live guards. It must not call the current capability.revalidate(), which joins paths and parses cohort Serde data. Actual selector Exclusive spans validation/range writes, with nonblocking maintenance acquisition. The normal producer lock confers same-root namespace serialization only; it does not create global retirement authority.

## Cuts and accepted implementation boundary

Before the final binding-name directory sync, no publisher creation attestation returns. Missing/torn first binding is Unknown; ordinary acquisition never completes it. After a completed binding but failed cohort publication, the root capability still cannot bypass the required cohort/header validation. Crash replay of later updates follows v3: old Commit survives torn Intent; valid Intent supplies the complete interrupted inactive slot; durable Intent survives torn Commit; mismatched/both-invalid evidence is Unknown. No highest-generation heuristic or new inode allocation is selected.

Independent code may implement the binding codec/mode checks, fixed primary scratch, anchored genuine-creation hook, existing-only preparation and callback-only publisher. S3 hooks wait for accepted capability/factory interfaces and explicit artifact_store ownership. Stream source/journal publication and full authority/collector integration remain separate.

Coordinator owns the pinned windows-sys0.61.2 feature addition requested by S2: Wdk_Storage_FileSystem, Wdk_Foundation and Win32_System_IO. That is a private build prerequisite, not native qualification. Target compilation/execution must verify the selected actual parent-handle helper; no Windows result is claimed by static Darwin review.

Required focused execution remains: all factory write/sync/name-durability cuts, no second set after failure; explicit stream modes/zero-length initial state; root/control/nonce substitution; every Commit/Intent partial-write cut with other witness unchanged; real producer serialization; zero/tiny/last-entry and slow-sync effects; optional failure preserving actual safe primary publication/read behavior; shared-account exhaustion/duplicate-image peaks; and error/panic releasing guards before bulk drop. These are future tests, not executions by this reviewer.

No Cargo, source/wiki/model/Git/ticket writes, probes or live operations. Only scratch review artifacts were written. Memory/wiki/Scryer/graph procedure was followed; configured graph lacks these new control/capability symbols, so the explicit mapped frozen paths were used. No new memory candidate: canonical/Scryer reconciliation remains coordinator-owned.
