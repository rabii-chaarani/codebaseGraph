# DC-S4 explicit refresh cancellation and owned join prerequisite

Read-only selected mechanism; implementation gated on fresh Max proposal review and coordinator Scryer brief. Scope is lifecycle ownership only, independent of unfinished S2/S3 collection. Same approved revision0.2/`chg-6vx5tj`/`node-hxxbg1`; no new product/GUI/routing/daemon decision. No source changes for this slice yet. Do not mix this future slice into scheduler v4/v5 review snapshots.

## Current caller and ownership trace

Graph discovery: semantic slim/context1 found refresh.rs `start_refresh_service`, `run_refresh_service`, `refresh_task_should_stop`; dependency context2 found facade.rs. Coordinator discovery found start_owner/CoordinatorOwner/drain_owned_operation. Source verified in explicit shared checkout only. Relevant memory recall reiterated real execution occupancy beyond caller timeout and preserving dirty epochs across in-flight refresh.

`CoordinatorApiConfig::build_api()` -> `CodebaseGraphApi::for_coordinator_owner(selector, refresh)` -> optional `start_refresh_service` -> `ApiCore::for_coordinator(Option<Arc<RefreshState>>)`. `start_owner` runs this inside the unique coordinator serving thread, then `serve_owner` clones CodebaseGraphApi into real executor closure. Current refresh startup discards JoinHandle; the supervisor captures Arc<RefreshState>. `refresh_task_should_stop` uses `Arc::strong_count(state)==1`; joining before ApiCore/executor copies drop cannot rely on that condition.

`CoordinatorOwner::Drop/stop_and_drain` currently take and join server handle while `thread` mutex guard is alive. `CoordinatorClient::drain_owned_operation` does the same with operation monitor. Route replacement already releases route mutex before dropping the old owner and must retain that ordering. Monitor runs from Weak<ClientInner>, transiently upgrading it each iteration; self-drop is already a special case because a thread cannot join itself.

## Exact proposed private types and signatures

In `api/refresh.rs`:

```
#[derive(Clone, Debug, Default)]
struct RefreshCancellation { stop: Arc<AtomicBool> }
impl RefreshCancellation {
    fn request_stop(&self);
    fn is_stopping(&self) -> bool;
}
struct RefreshRuntime { state: Arc<RefreshState>, thread: Option<JoinHandle<()>> }
impl RefreshRuntime {
    fn state(&self) -> Arc<RefreshState>;
    fn request_stop(&self);
    fn stop_and_join(&mut self);
}
impl Drop for RefreshRuntime { /* request + take handle + join, no shared lock */ }
fn start_refresh_service(selector: RepoSelector, config: RefreshServiceConfig,
                         cancellation: RefreshCancellation) -> RefreshRuntime;
```

These are `pub(crate)` only where cross-module calls require it. Runtime is non-Clone. The runtime owns its thread; thread owns ONLY state/cancellation plus existing supervisor inputs. State gains the explicit cancellation token and keeps current status mutex. No state/Core/API/maintenance handle owns Runtime or JoinHandle; no closure captures Runtime. A state clone remains a status view and cannot keep refresh alive after cancellation. `RefreshState::with_config` still supports direct fixture states, constructing a fresh token; a private `with_cancellation` constructor binds service startup to the owner's token.

`refresh_task_should_stop(&Arc<RefreshState>)` keeps its current call signature and reads that token instead of Arc count. All existing worker-cancellable, native/poll loop, supervisor retry/backoff checks therefore observe the SAME explicit cancellation. No additional watcher, routing process or cancellation mechanism is introduced. Existing 50ms supervisor polling and native/poll waits remain. There is no new shutdown deadline promise.

In `api/facade.rs`:

```
CodebaseGraphApi::for_coordinator_owner(selector, refresh, cancellation)
    -> (CodebaseGraphApi, Option<RefreshRuntime>)
```

It extracts `runtime.state()` into ApiCore, returning the unique Runtime separately. `ApiCore::for_coordinator(Option<Arc<RefreshState>>)` and `ApiCore` fields need no change: they already provide the correct non-owning status/control boundary. No Runtime gets added to a cloneable Core.

In `coordinator.rs`:

```
CoordinatorApiConfig::build_api(refresh_cancel: RefreshCancellation)
    -> (CodebaseGraphApi, Option<RefreshRuntime>);
CoordinatorOwner { existing fields..., refresh_cancel: RefreshCancellation }
```

`start_owner` creates cancellation BEFORE spawning the serving thread. External CoordinatorOwner and server startup each receive a clone of this token. Thus a stop racing initial API construction immediately cancels refresh as soon as it starts. The thread destructures `(api, mut refresh_runtime)` locally and owns the runtime until it explicitly joins it after serving ends. No new callback cycle or extra background control thread is needed. Existing serve_owner_with_executor signature and dispatcher callback routing remain unchanged.

## Stop and disposal ordering

1. Authorized owner drain sets coordinator stop, requests refresh stop via token, and closes dispatcher admission. No join while these short calls run. They are idempotent; a cancelled refresh does not itself stop the coordinator or otherwise disable reads.
2. Take the server JoinHandle from `CoordinatorOwner.thread` inside a short poison-recovering mutex scope; RELEASE guard, then join.
3. Serve loop exits; existing handler/executor/response joins retain actual operation completion and caller-timeout semantics. Refresh has already been signalled, including isolated worker cancellation through its existing callback. No new materialization launch is authorized by refresh after the cancellation check; existing cancellation/containment recovery remains authoritative.
4. Back in the unique server closure, `refresh_runtime.stop_and_join()` completes actual refresh supervisor/watcher/worker/resource unwinding while `api`/Core clones may still exist. Explicit cancellation prevents the old Arc-count deadlock. Only after join may owner cleanup remove the serving state and release the coordinator lease. Runtime Drop repeats stop/join safely on early return or server unwind.
5. `RefreshState::mark_stopped` is emitted only from the service wrapper after `run_refresh_service` returns and its watcher/leader lease/runtime/worker scopes unwind. Remove the premature `mark_stopped` in `RefreshServiceContext::refresh_batch`; it returns cancellation to the enclosing service instead. Terminal failure remains failure; a legacy-disabled service keeps its existing disabled status. Status JSON names/dirty epochs/retry values are preserved.
6. `drain_owned_operation`: request monitor stop; take monitor handle under short mutex scope; unlock, then join it. After monitor drain, snapshot owner under route mutex; unlock, then owner drain. Existing current-thread check remains a self-join guard, not permission to report aggregate completed drain early from an external caller.

`ClientInner::Drop` also takes monitor handle out of the mutex before any joining. If dropped by an external caller, request stop and join monitor outside all locks. If the monitor itself releases the final strong reference, it cannot join itself: explicitly recognize the current-thread handle, drop that handle, and return immediately from that final monitor iteration (do not enter another sleep/retry). This preserves the weak-monitor topology while making its final self-owned tail finite. Tests must prove no work/resources remain after that tail, and no external drain claims completion before the monitor returns. If implementing this finite tail needs broader ownership changes than these functions, stop and amend the execution brief before dependent code.

## Startup and error behavior

Use fallible `thread::Builder::spawn`. On refresh spawn failure, mark the returned state failed with a concrete error and return a Runtime with no handle; ApiCore still serves otherwise committed reads. Do not turn optional refresh failure into coordinator-start failure. If the coordinator server/executor cannot start after refresh starts, Runtime's owner requests cancellation and joins it before coordinator state/lease cleanup. Worker panic is caught only at supervisor ownership boundary, after inner resources unwind; preserve existing failure/retry semantics and do not reinterpret transaction recovery errors as cleanup success.

Configuration changes still take existing run_refresh_service supervisor paths and resolve_service_config rules; this slice does not manufacture new repository rebinding or confirmation behavior. Explicit uninstall/rebind integration remains later S4 wiring. No collector triggers, mutation permit, fake collection outcome or public health measurement is introduced here.

## Exact ownership and tests

Needed writers: `src/api/refresh.rs` (types, cancellation predicate, owned join, two existing start-service tests and new inline lifecycle tests); `src/api/facade.rs` (private tuple return); `src/coordinator.rs` and `src/coordinator/tests.rs` (token, unique owner join, monitor handle extraction and narrow tests). `src/api/core.rs` is inspected but needs no edit. No manifests, mod exports, S2/S3 storage, public contracts or native guardian changes.

Tests:

- Retain several ApiCore/RefreshState clones while a fake supervisor waits in a real cancellable wait; request stop and join completes without dropping clones. Assert no Arc-count dependency and no Runtime/Core/State cycle.
- Pause refresh worker teardown/drop after cancellation; owner join stays pending while status does not claim task stopped; release and verify all resources and real JoinHandle drained. Destructor panic is a failed worker, not early stopped success.
- Race owner stop against startup before Runtime is constructed; shared token prevents supervisor work and ownership returns with a joined thread. Inject refresh spawn error: failed refresh summary and successful ordinary committed graph read/health path remain available.
- Real coordinator drain fixture: server/executor thread tries to take its owner thread mutex during teardown; drain must release that mutex before join. Similar monitor mutex probe for drain_owned_operation; keep route lock available during both joins.
- Executor-spawn/startup failure after refresh creation joins refresh; ordinary explicit shutdown and Runtime Drop idempotently drain. Monitor's final-strong-reference case exits its tail without another sleep/work; external monitor drain joins normally.
- Existing coordinator actual-permit timeout/drain/route recovery suite; refresh native startup backend identity, policy/legacy disabled behavior, retry/backoff, in-flight dirty epoch, generated-path filtering and worker cancellation regressions. Real resource probes are necessary; attached tests/compilation alone do not qualify supported native platforms.

No test execution for this read-only slice yet. Required fresh Max proposal review must approve this exact mechanism and Scryer brief/ownership must be recorded before implementation. Lifecycle-source changes will get a fresh frozen baseline plus exact owned overlays and separate final review. Coordinator owns wiki/memory/Git closure.
