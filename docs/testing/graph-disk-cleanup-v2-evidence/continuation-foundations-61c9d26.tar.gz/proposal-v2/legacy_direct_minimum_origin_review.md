# Legacy default Direct: minimum origin lane

Do not require full native graph-row/usability validation merely to retire an obsolete Direct bundle. Do not clear the proposed manifest/cache/header-only composite either: it lacks a binding to the actual database leaf. Select a smaller native provenance projection using existing producer-written support/File records, with its bounded physical-format mechanism reviewed before code. No full database-engine rewrite is authorized by this review.

GPT-6.1 Sol / Max, read-only adversarial-proposal-review-engineer, 2026-10-21. Approved DC revision0.2; Scryer chg-6vx5tj, maintain_storage node-eje4rb. Scope: origin needed by DC-S3-R5, not LoaderUsable or runtime effects. No product decision is open.

## Contract conclusion

DC-S3-R5 requires retirement of approved former repository-local Direct bundles, preserving stable ownership files and coherent retirement/rebuild behavior. Shared constraints and DC-S1-R8 exclude foreign/custom state and preserve uncertain association; DC-S2-R8 requires verified legacy quiescence. None requires every native row to survive loading or reproduce graph-query semantics solely to prove disposal eligibility. LoaderUsable remains necessary for BACKUPRESTORE and the already selected legacy artifact route that uses payload/schema/coherence validation to establish origin. That does not impose native loader usability on every obsolete Direct DB leaf.

The distinction does not waive provenance. Current writer/use authority and operator quiescence exclude activity; neither identifies what produced bytes already present. No foreign siblings is a confinement observation, not a DB-origin witness.

## LD-01 — The proposed composite does not bind the DB

Established premise gap, blocking only header-only DB eligibility.

NativeManifest (protocol.rs260–275) records schema/ontology/parser/options digest/search metadata/files; it has no database checksum or UUID. graph_build_compatibility_digest (protocol.rs103–157,220–238) hashes request/output-shaping settings including source_root and schema, not the resulting database. Full cache recognition can prove those cache objects belong to the repository, but does not by itself prove the neighboring native DB does.

Concrete counterexample: retain a genuine old manifest and all its genuine caches, then substitute an unrelated same-version native DB at the default DB address. Header/version, manifest/cache coherence, exact default layout, no extra siblings, real exclusion and quiescence can all hold. No deliberate valid-record forgery is needed. Automatic retirement would delete an unassociated leaf. This is the missing association, not a demand to authenticate malicious same-user records.

DirectPublishJournal has exact DB/manifest/sidecar hashes and candidate/destination paths (direct.rs19–33,198–218). That is a stronger existing lane where a genuine unresolved journal applies, subject to its actual recovery protocol. Normal publication removes the journal (direct.rs216,361–368), so successful historical state cannot universally be required to possess it. No historical receipt is invented. Search metadata binds search files, not native DB bytes (author's exact search_index/model.rs31–37 inspection).

## Selected minimum additional existing witness

The native producer writes more than a generic header. In the accepted source:

- syntax_materializer/builder/traversal.rs17–38 creates actual Repository, SourceRoot and File support nodes, then Contains relations with repository_source_root/source_root_file roles.
- builder/nodes.rs9–40 derives support IDs from table/stable key and stores metadata.canonical_key; SourceRoot carries the actual source_root in key/label/path, Repository the repository label, File the source path.
- staging_writer/accumulator.rs105–132 supplies each File row's content_hash from its partition entry. staging_writer/rows.rs6–27,49–74 persists those fields through native COPY.
- api/catalog_support.rs43–81,232–288 defines the producer's catalog shape; File adds content_hash to common fields. There is no hidden native GraphMeta producer table or DB/manifest checksum. partition_builder.rs88–116's graph_meta is input to these ordinary graph records, not a separately persisted receipt.

Select a historical profile that recognizes the exact pinned catalog/storage framing and checks the COMPLETE relevant Repository/SourceRoot/File identity inventory against the recognized manifest and full cache facts, with exact strings/IDs/content hashes and the producer's merge/dedup semantics. Include the corresponding support-association relation roles where required to disambiguate the profile. It must not accept one matching sampled File, counts alone, a byte-string search, or an arbitrary user table that happens to contain the expected text. Missing/extra/ambiguous source identity makes that profile Unknown.

This is a provenance witness for disposal, not a certificate that every native node/edge/query/index is usable. It need not read all graph-row values, rebuild native indexes, execute the loader, or compare every edge against caches. A format-correct selected-column projection can skip unrelated data while validating the framing/pointers needed for the records it relies on. Historical version/schema recognition must follow actual producer evidence; unsupported forms remain explained Unknown rather than being relabeled recognized.

The concrete bounded reader is not yet reviewed: correct catalog/page selection, compression/string decoding, overflow/null/deletion semantics, complete selected inventory, fixed-memory exact comparisons and source stability still need a small mechanism. Do not claim an existing safe SDK adapter: S3's pinned-source investigation reports eager unbounded catalog/nodegroup/index/result allocation beyond buffer-pool limits. No native open or allocation experiment was executed here. A selected-column reader may still require format work; this gate does not pretend a full visitor is already cheap or qualified.

Keep advisory reads outside exclusive authority, reserve all requested memory through the shared account, bind exact physical DB incarnation/stamps across passes, then consume the proper fresh authority for coherent RETIRING/journal transitions. Retain stable controls and unknown siblings at their public addresses. Existing S2 v3 and exact-incarnation replay conditions remain unchanged.

## Verification and limits

Before eligibility is enabled, compare the proposed projection with supported historical producers using fixtures: genuine journal-free default pair; same-header unrelated DB substitution; genuine caches with wrong native SourceRoot/File inventory; truncated/unsupported catalog/page/compression; ambiguous or extra source rows; large valid selected inventories under the configured shared ceiling; changed incarnation during prep; and native/file-hash journal recovery. Usability failure in an unrelated graph row must not be confused with failed provenance, provided the selected profile's actual ownership witness remains intact.

Sources read from accepted frozen B/C checkout `/private/tmp/cleanup-s2-bc-foundation-final-vvbfeega/repo`, base7b0ad57 with accepted B/C overlay; the cited producer/schema files are unchanged baseline evidence. S2v3 input SHA-256 88f647d10406eb44646f38430b3098cb7db6c1df07c3d99f5563866ef5c2478e; S3 effects v2 44391219454b4265529f8d766f40603f9aee71a2b34548d6449549c92a4d4231. S3 author independently supplied matching accepted164 source facts and confirmed no full native visitor was started.

Procedure: memory recall, wiki bundle/search/get, explicit-checkout Scryer rules/model, sequential graph discovery then frozen-source reads. This round's k-wiki read returned approved v0.2 (the earlier reader-cache limitation no longer affected it). One graph busy response was retried. No Cargo, probes, benchmarks, source/model/wiki/Git/ticket writes or live operations. Only this scratch report was written. No new memory candidate; coordinator owns canonical/Scryer reconciliation of the selected mechanism.
