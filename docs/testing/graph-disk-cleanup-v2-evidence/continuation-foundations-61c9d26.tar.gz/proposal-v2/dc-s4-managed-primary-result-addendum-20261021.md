# Managed primary-result split — selected correction addendum

Read-only addendum to proposal SHA `6753f5d586f719ec39e894c1cbdcdacd19c273cfad3503b5a8f77c3d335de085` and fresh Max review SHA `2a991ae1d2bea8fa8327566ab8b54d5553457e62c4fe834d0585a3dff8d6712c`. These selections supersede ambiguous sketch wording. Same approved DC-S4-R7/A4 scope, Scryer chg-6vx5tj/node-hxxbg1 and RAB-9; no new public policy/schema or durability protocol. Existing canonical wiki spec stays at its original location/revision. This scratch input is not a parallel canonical spec. No source/Cargo/model/Git/Linear write; ownership and recorded Scryer clearance remain prerequisites.

## 1. Required ready evidence versus absent alternatives

Use `ReadyProbe::{Absent, Valid, Invalid(NativeError)}` with an actual non-following root existence/type observation. Only established namespace absence is Absent. A present symlink/non-directory, unreadable root or invalid present bundle is Invalid, never absence. Full bundle validation is selected lazily by the transaction branch:

- `active == candidate`: exact published bundle is required; validate it and the actual active pointer. A staged address is not a second required bundle and is not validated merely to reject a normal already-promoted run.
- Active/base match and published address Absent: exact staged bundle is required; validate, promote and activate through the existing protocol.
- Active/base match and published address present: validate that exact published bundle. Do not overwrite it or fall back to staged on corrupt/I/O-invalid present evidence. Staged absence is normal here.
- Both required alternatives absent or associations conflicting: recovery Err/Unknown and retained journal, not terminal cleanup permission.
- Stale base: only the validated existing stale-base decision yields Obsolete/Rejected. Ordinary publication preserves its stale-base primary error. An I/O/validation failure never becomes stale/obsolete.

Tests must independently cover staged-only, published-only and same-active seams, both-absent, corrupt-present/absent-other, inaccessible-present, and foreign/symlink evidence. Do not replace both old Boolean probes with unconditional `?` validation.

## 2. Resume actual mandatory durability before same-active commitment

After pointer/managed-root synchronization Err, return the original transaction error and preserve exact Publishing/candidate/published evidence. Remove the candidate-retired-marker write from that ambiguous error branch. No generic `publication_is_committed` readback fallback remains.

For the explicit same-active recovery branch, validate the current pointer and required READY/metadata/bundle, then complete the existing directory barriers under actual writer/state ownership:

```
sync_parent_dir(published.root())?; // existing helper syncs generation directory AND generations parent
sync_dir(layout.storage_root())?; // active-pointer/root publication barrier
```

These cover the existing promotion parent and generation/managed-root barriers. Existing mandatory file writes/sync-before-rename obligations remain part of their original transaction path; do not treat an unflushed/invalid file as valid evidence. If implementing the branch exposes an additional outstanding existing mandatory file step, finish that exact step before ResolvedCommitted; do not broaden this into a new durability protocol.

Do not call `activate_published_generation_locked` again for an already active candidate: it would regenerate semantic publication timestamps/READY contents. Preserve generation identity, metadata published_at_ms, pointer activated_at_ms/published_at, READY bytes and graph/manifest/search bytes while resuming durability. Required sync failure stays Err and keeps the journal; only completion supplies ResolvedCommitted and permits optional retirement/removal. No candidate or previous-generation retirement occurs on ambiguous failure.

Fault tests: pointer/root-sync error despite readable bytes -> original Err and byte-identical retained evidence/actual lease release; repeated recovery sync fault -> Err with same identities/timestamps/bytes; fault removed -> recovery committed, followed by separately reported janitor outcome.

## 3. Scan roles cannot preempt required run recovery

Split the current mixed `has_reference_cleanup_work` preflight by role. Run enumeration, association/journal checks, selected-bundle validation and required replay are recovery. Generation-only enumeration, entry-type/predicate checks and unrelated retired-generation removal are janitor work, including their I/O failures. An optional generation preflight failure is retained as a generation issue and incomplete observation; it cannot return early before required run recovery.

Retain one run enumeration and no retained path union. After an optional issue, defer further optional work as appropriate but visit all remaining required transaction decisions. A later required run error is primary. Partial run enumeration cannot produce a complete recovery report. Existing established benign NotFound races remain only at their specific observation points.

## 4. Exact API identity and drop order

The migrated Managed API path is:

1. Typed publish; actual reopen/identity/native-count/digest/manifest/search/artifact verification.
2. Typed reconcile; preserve every observed required recovery Err.
3. Fresh actual active-generation read/check AFTER reconcile, while session writer remains owned. If identity differs, return the existing primary identity-mismatch failure, not success for the earlier snapshot. The earlier check is retained but is insufficient alone.
4. Apply only typed janitor diagnostics after those checks. Explicitly `drop(validation_snapshot)` while the session writer is still held, including error exits.
5. `session.finish_without_cleanup()` releases writer ownership. It starts no hidden second mixed cleanup. Outer reference/run guards finish before a later scheduler completion trigger.

The snapshot drop at step4 makes the existing GenerationLease::drop best-effort writer acquisition fail harmlessly while this writer is held. Do not remove that established last-reader policy for other callers. A fresh post-reconcile check must not create another snapshot that survives writer release; scope/drop every such snapshot first.

## 5. One owned issue per report and truthful remaining counts

Each report owns at most one original `ManagedJanitorIssue`/NativeError plus bounded counters, including total observed issue count. Move with `take`/consuming merge; NativeError is never cloned. Typed publication returns its report to the typed caller. The String compatibility wrapper instead moves that report into session storage; the same error is not owned by both places. Strict cleanup/recover wrappers consume the single issue and return its original source unchanged.

When merging, keep the first issue by move and increment the bounded issue count for later faults; extra-source diagnostics are explicitly counted/omitted, not silently presented as one fault. Do not keep a Vec or format/copy unbounded diagnostic text under collector authority. A later required recovery error remains the primary error; if an earlier janitor issue is appended, use the existing compound-error format with the primary Display first and cleanup failure secondary, without classifying by that text or changing single-error variants. No new error.rs variant/public schema is needed.

Issue history and extant work are different facts. The selected typed path may defer run disposal after its first optional journal issue; if so, that actually retained run contributes one known pending run. If a compatibility/current path instead completes disposal after a journal error, confirm its actual removal and contribute zero pending runs for it; retain the issue diagnostic/count. Generation errors never invent a run. Do not derive `pending_runs` or remaining-work `pending` solely from issue count. Unknown removal/remaining counts retain incompleteness and a concrete reason. Other genuinely deferred work (including separately deferred artifact maintenance) may still make the overall maintenance summary pending. A resolved journal fault is still reported, but is not a fabricated surviving workspace.

Required focused cases: journal fault+deferred disposal -> one pending run; journal fault+actual successful disposal -> zero for that run with diagnostic retained; multiple faults -> first source retained once, exact bounded issue count; optional generation fault followed by later required success AND error; fresh active change after reconcile -> primary error; snapshot destruction observed before writer release with no hidden cleanup attempt.

Tracking consultation: read-only lookup of parent-supplied RAB-9 through the CodebaseGraph Linear connection returned “Could not find referenced Issue” (request a4deedd6b907d9b8). No alternate project/account was substituted and no record was written. Coordinator must reconcile the existing record/reference before implementation bookkeeping; approved spec/Scryer scope is unchanged.
