# S3 native header/key foundation: narrow clearance

Proceed with pure fixed positional/header/range facts and complete-stream NativeUtf8/JSON key readers after recording the exact private ownership/interface boundary below. Do not implement or enable the full native catalog/chunk/version/dictionary projection from the present sketch. There is no new product decision; the remaining gaps concern that later mechanism.

GPT-6.1 Sol / Max, read-only adversarial-proposal-review-engineer, 2026-10-21. Approved DC revision0.2, chg-6vx5tj / node-eje4rb. This report resumes the same bounded review after an intentional interruption; no work was restarted or requalified by the interruption.

Inputs independently verified:

- `/private/tmp/dc-s3-legacy-native-projection-proposal-20261021.md`, SHA-256 `9ab1f97bd62d8bbe4cbc866b4d94d578a6f142aa587f34baa43b30f0c5602442`.
- `/private/tmp/dc-legacy-direct-history-20261021/history.json`, SHA-256 `0c6c2ac96e9ed71addc462253aa23679180fada0582d68d9855b7d40ebe94556`.
- Prior minimum-origin report SHA-256 `beea9a010d508368d5f9c0833e61e97519de917106c7e5620aa2c6fea6d8891c`.
- Pinned primary source: `/Users/rabii/.cargo/registry/src/index.crates.io-6f17d22bba15001f/lbug-0.19.0/lbug-src`; producer/merge source from accepted164 frozen `/private/tmp/dc-s3-validation-164-gjtbfe3o/repo`. No current unreviewed source is treated as qualified.

## Starting ownership and interface commitment

S3 may own new `src/storage/maintenance_native_projection.rs` for these FACTS ONLY and narrow key-reader changes in its existing `maintenance_validation.rs`. Coordinator serializes module registration and exact ownership/brief updates. No SDK, dependency, native-library, producer, store, authority or runtime-hook changes are included. Preserve the separately reviewed comparator correction: comparisons consume and validate both entire streams even after finding their first ordering difference.

Keep the new header result explicitly distinct from NativeProjectionFacts/LegacyAssociationFacts. A suitable exact callable boundary is `scan_native_header43(source: &impl ByteSource, account: &CleanupMemory) -> Result<NativeHeader43Facts, NativeUnknown>`, with a private fixed no-debug/little-endian layout definition. It borrows a noncreating source, reports parsed fields/range checks and allocates no file-sized object. It does not manufacture a confirmed-producer profile, open an engine, establish source ownership or mint usability/retirement authority. Unknown layouts remain explicit; the proposed full NativeProjection::prepare/replay and prove_legacy_association are outside this starting slice.

For the key foundation, clear fixed streaming key cursors plus `compare_native_json(native_source, native_span, json_source, json_span, account)` and corresponding domain-prefixed hash/exact-compare adapters. Inputs use the existing ByteSource/Span error discipline. NativeUtf8 denotes a LOGICAL unescaped UTF8 view supplied by a bounded source; it does not assert that compressed physical dictionary bytes already are decoded strings. JSON uses exact decoded bytes. A key-reader extension must preserve explicit source/encoding/locator identity, never reinterpret native offsets as quoted JSON spans or create an unbounded source registry. Any enlarged fixed join-slot/locator layout must be reflected in checked capacity reservation before allocation. Private spelling/refactoring may follow repository conventions without changing this boundary.

## NH-01 — Pin actual header widths, not the stale comment

Selected correction before implementation, source-verified:

- magic4 at0; storage_version u64 at4;
- catalog start/count u32 at12/16;
- metadata start/count u32 at20/24;
- UUID16 at28;
- header-format byte at44; format2 dataFileNumPages u32 at45–48.

The selected format2 prefix is49 bytes. common/types/types.h33 defines page_idx_t as uint32_t; storage/page_range.h and database_header.h use that type. storage_version_info.h12 is uint64_t. DatabaseHeader serializes the actual types at database_header.cpp71–85. Its comment about a nine-byte tail is stale; the actual format2 tail is five bytes. Do not copy that comment into a53-byte codec.

Use checked u64 arithmetic for byte offsets/range ends before any narrowing. Mirror Checkpointer99–105's native sentinel rule: INVALID_PAGE_IDX requires zero count; other ranges have nonzero count, start within available pages, and count<=pages-start. A syntactically parsed empty/sentinel header is still facts, not a recognized obsolete graph. Header/page inconsistencies, unsupported endianness/debug/layout/tail forms or truncation are Unknown. Reading a storage43 number is not sufficient to select all other layout/build properties.

Tool-checked arithmetic on the ALREADY RECORDED64-byte observation produced catalog1+24 pages, metadata25+62, format2/pages87;356352/4096=87 and both ranges fit. No live user file was read or copied by this review. This corroborates the interpretation of that observation, not producer provenance or a parsing oracle.

## Key completeness and memory conditions

The native reader validates UTF8 across buffer/page boundaries, supports embedded NUL and all valid scalar encodings, and rejects overlong, surrogate, truncated and invalid sequences. Hashing, equality and ordering use the same decoded byte stream with no normalization or truncation. First mismatch/prefix ordering does not bypass suffix validation or short-read/source errors. Null, empty and missing fields remain distinct facts. Any logical-length or offset overflow is an error, not EOF.

Use the SAME CleanupMemory for fixed reader state, both simultaneous key buffers/carry, prefix/collision state, locators, join slots and retained owners, reserving before allocations and keeping reservations through disposal. The proposal's below32KiB FULL-visitor floor is not established by this review; do not expose it as a measured bound. The pure header/key foundation can use its actual finite layout without a total-file/string/row-count cutoff. C=0 fails before table use; capacity>=1 and full-collision progress retain the accepted exact-join contract. No escaping worker, mmap whole file, native allocator or materialized string/result inventory is selected.

## Exact later visitor gaps and useful reduction

The minimal witness remains genuine producer Repository/SourceRoot/File records and support Contains NODE fields, joined to the complete recognized manifest/cache inventory under the actual first-nonempty merge rule. It does not require all graph-row usability or native CSR/ALP value decoding.

S3's source-backed reduction is valid for partial projection facts: Catalog::serialize/deserialize632–671 places the table set first; StorageManager436–464/502 onward places all node metadata before relationship-group metadata. A decoder can find all selected node tables without traversing later relationship storage. Contains.kind/source_id/target_id are ordinary node columns. Complete selected-table/row coverage still matters; do not stop after one sampled match or omit a duplicate/extra selected table.

For final DB-origin composition, retain the original supported-catalog-shape safeguard. A table-prefix decoder alone does not bless an unexamined suffix containing added macros/functions/indexes. A minimal later mechanism may recognize expected-empty suffix sets and return Unknown on unexpected nonempty sets, or recognize only actual producer-generated extension/index forms. No generic SQL function/macro parser is required by this report. This condition does not block header/key facts.

Before the full visitor is coded, pin its actual table/property/default-expression and node metadata grammar and exact fixed layout. CatalogEntry.cpp15–75 is tag-dispatched without a generic payload length. ColumnChunkData580–630 includes LogicalType, compression metadata, optional null metadata and type-specific children; STRING/JSON then have index/dictionary children. NodeTable1046–1076 permits skipping index storageInfoSize bytes only AFTER IndexInfo's actual framing. VersionInfo664–695 and VectorVersionInfo328–386 contain optional per-vector visibility and conditional deletion arrays. These are concrete required prefixes/branches, not permission to guess offsets, skip arbitrary records or treat missing version data as visible.

Pin actual node-group/order/column/index schemas, stream their counts, validate lengths against the enclosing catalog/metadata range, retain only bounded selected descriptors, and measure the resulting requested layout. Source changes invalidate every replay/locator. No full native engine or graph-value reconstruction is inferred from those framing needs.

## Profile and verification boundary

The history record establishes lock versions0.19.0 for reviewed/current/August revisions and0.17.1 for the older revision. The observed former-default header is43. Actual StorageVersionInfo maps0.19->43,0.18->42,0.17->41,0.12–0.16->40. build.rs supports external/precompiled/source overrides; CMake page/vector/group sizes and DESER_DEBUG labels are build choices. Therefore neither lock version nor storage43 alone proves the writer binary/configuration.

Pure header/key tests may use synthetic bytes now. Enabling a real historical profile later requires synthetic journal-free fixtures from an identified native writer/library/build with captured header/page format and a native-query oracle, outside collection. This is profile/oracle evidence, not an invented requirement for a receipt naming every old file's original binary. Candidate origin still comes from the reviewed format/source association. Unsupported profiles remain explained Unknown; this foundation does not close the mandatory legacy category or silently waive older recognized cases.

Focused future foundation checks: every header truncation/overflow/sentinel/tail/version case; short positional reads; mixed JSON/native encodings; NUL, multibyte splits and invalid suffix after early difference/prefix; capacity1 and forced digest collisions; distinct source locators and changed sources; shared-account exact exhaustion and allocation failure. Full visitor qualification separately needs normal compressed/constant/bitpacked strings/nulls, multigroup dictionaries, deletion/version states, first-nonempty merge, unrelated same-header DB substitution, complete extra/missing source rows, large valid inventories and real profile fixtures. No such execution was performed here.

Procedure/limits: memory recalled for this subsystem; existing approved wiki/Scryer intent and sequential graph discovery were followed. Configured graph does not index the new validation/native module or SDK internals; explicit mapped frozen/source package paths supplied by S3 were used. No Cargo, source/wiki/model/Git/Linear changes, probes, native open or live operation. Only this scratch artifact was written. Reusable-knowledge assessment: retain the header-width correction and profile distinction in coordinator-owned canonical evidence after implementation verification; no memory candidate is created by this read-only proposal review.
