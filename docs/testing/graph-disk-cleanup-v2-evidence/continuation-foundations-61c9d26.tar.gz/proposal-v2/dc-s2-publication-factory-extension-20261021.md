# DC-S2 exact prebound publication factory extension

Design-only focused review input. Extends accepted v3 SHA88f647d10406eb44646f38430b3098cb7db6c1df07c3d99f5563866ef5c2478e and its independent-region condition; preserves artifact cohort v2/header and B/C exact prepared bytes. Coordinator owns Scryer/module exports and qualification. No producer effects authorized merely by this artifact.

## Exact ownership and paths

S2 owns maintenance_controls.rs codecs, actual fixed publisher handles, factory and maintenance_ownership.rs genuine-creation hook. S3 owns artifact_store.rs key/origin/receipt/equal-payload/no-replace integration only after this factory and live-root capability acceptance. One existing root selector inode is the stable publication namespace lock; no immortal per-key coordination files and no additional unbounded root catalog.

Five fixed root-relative names: `.publication.data0`, `.publication.data1`, `.publication.selector`, `.publication.stream`, `.publication.binding`. No user-derived component enters these names. Slot size2136: magic8/rootnonce32/generation8/payload_len8/fixed schema payload2048/checksum32. Selector2392 comprises Commit128 and Intent2264. Commit and Intent have independent checksum regions and range-limited writes; Intent contains the COMPLETE next2136-byte slot, not only its hash. The stream is one bound inode; range/cursor/source proofs govern append, not one new segment per attempt. Binding is a fixed512-byte record: version, root/header nonce, exact root and coordination identities, exact two data/selector/stream native identities, root publication schema kind, checksum and zero reserved bytes. Binding has no paths, timestamps or PIDs. Cross-root/nonmatching headers/aliases/unknown versions fail closed. All checksums prepare outside maintenance authority; actual write/readback uses exact already prepared bytes.

## Genuine factory order and cuts

Only the actual fresh-root `fs::create_dir` success branch, retaining real root Exclusive, can call the private factory. The separate root use header is initialized first by existing creation code; no observation/acquire/retry path invokes initialization. The factory's rootnonce is borrowed from that actual header, not supplied by a caller-owned path or bool.

1. create_new data0; write complete generation0 initial supported state; sync file; read back exact bytes and physical identity;
2. create_new data1; write supported empty inactive slot; sync/read back physical identity;
3. create_new selector; write initial valid Commit pointing at data0 and zero Intent; sync/read back identity/bytes;
4. create_new stream; initialize exact private inert stream header; sync/read back identity/bytes;
5. sync root directory so every preceding slot name is durable;
6. create_new fixed binding with these actual identities/rootnonce; write/sync/read back complete fixed record and physical identity;
7. sync root directory AGAIN, making the new binding name durable;
8. only then return BoundPublisherCreation to the genuine creator. Existing root cohort/header format is untouched; normal root cohort publication follows its existing write/sync/root-sync protocol. Reference epoch initialization happens after this creator returns.

Crash or error before step8 yields no publisher attestation. Partial fixed names remain finite Unknown. Existing acquisition does not recreate, overwrite/adopt or allocate a second publisher/stream/job. Existing primary publication follows its old path without origin attestation. Do not erase partial controls to force a retry; explicit approved controlled association/quiescence can handle these remnants later.

Missing/invalid binding makes ONLY publisher/origin attestation None, not a new mandatory producer/read failure. The existing v2 root provenance and reference-source invalidation coverage keep their established meaning; neither claims leaf ownership or origin. A valid old graph stays readable, ordinary primary cache replacement still occurs, and unproven old backup is retained under S3 policy. Cleanup sees unattested leaves/controls as Unknown. Canonical references do not become a substitute publisher creation proof.

## Exact existing-only producer API

`ReferenceMutation::artifact_root_producer_capability(&self) -> Result<Option<ArtifactRootProducerCapability<'_>>,NativeError>` borrows the live actual root-use and Shared reference-activity handles and binds the v2 root/cohort/header nonce. No Clone/serde/Send/Sync escape. Actual borrowed MaintenanceLease root is a real reference, not a marker.

`prepare_root_publication(&ArtifactRootProducerCapability, &CleanupMemory) -> Result<Option<PreparedRootPublication>,PrepareFailure>` runs off cleanup authority, reserves its complete layout before any allocation, opens existing binding/slot/selector paths without creation, validates fixed codecs and full physical stamps, and retains reserved exact hot bytes/native paths. No optional error becomes mandatory primary publication failure.

`try_with_root_publication(hot:&RootPublicationHotFrame, cap:&mut ArtifactRootProducerCapability, grant:&mut MutationGrant, scratch:&mut FixedAuthorityScratch, effect:&mut impl PublicationEffect) -> Result<PublicationFact,AdmissionFailure>` only when maintenance effects are involved. Authority opens the existing selector actual Exclusive nonblocking and owns the same guard across checks/range writes. The callback borrows fixed frame and actual RootPublicationLease; no bulk Work moves inside. A normal producer's analogous same-root lock lifetime is retained across S3 temp binding/no-replace/equality actions, but does not gain global deletion authority or secretly run a cleanup grant. S3 `begin_artifact_publication` must borrow this actual existing namespace lease plus root capability, not call any factory.

## Filesystem effect and reservation accounting

Factory happens during ordinary genuine production, never inside a cleanup permit; nevertheless its FULL additional work is explicit. Four slot/selector/stream create+write+sync actions4; each exact readback/identity observation4; first root sync1; binding create/write/sync1; binding readback/identity1; final root sync1 =12. Without stream:10. This supersedes v3's11/9 for the separate NEW binding name: the extra directory sync cannot be omitted. Root mkdir, root-parent durability, use-header creation, and existing cohort publication remain SEPARATE base creator effects; they are not hidden in12. A maintenance-controlled new publisher (if later supported) must reserve those base effects plus12 and every admission observation BEFORE first effect; it is not implemented by ordinary acquisition.

Existing update remains P_b6: Intent range write/sync/readback2; inactive slot write/sync/readback2; Commit range write/sync/readback2. Intent preserves previous Commit; Commit preserves durable Intent. No directory-entry creation/rename occurs. Stream staging14 excludes separately charged fixed admission reads; sourceE never becomes stageG. Private leaf parent creation/binding remains S3's separately costed action, never part of publisher12.

Preparation requests one shared CleanupMemory account reservation for: `size_of(PreparedRootPublication)` plus all retained native path encodings plus binding512, both slot images4272, selector2392, stream fixed header, fixed OS open scratch and the one selected intent/commit/effect frame. Checked additions fail before buffers are allocated; each buffer consumes a split of that SAME reservation. No second ceiling. A helper taking caller-reserved slices allocates nothing. All bulk owner/destructors remain outside the permit; fixed hotframe borrows these images and exact native paths. Actual File/lock handles remain thread-local lifetime authority, never Send advisory job results.

## Recovery matrix and test cuts

Torn Intent+intact old Commit/oldslot: use old committed state, no new payload effect authorized. Torn inactive slot+valid Intent: rewrite only COMPLETE expected bounded bytes retained by Intent. Torn Commit+valid Intent/newslot: complete exact intended Commit. Both witnesses invalid/mismatched: Unknown/NeedsRecovery, no highest-generation rule. Repeated recovery interruption repeats the same idempotent range and never creates another inode. Receipt lifetime provenance binds incarnation+completed bytes; fresh current pre-effect full stamps are prepared after permission restoration. Own rename produces distinct post-own-effect stamp; no ctime refresh changes sourceE.

Required actual tests: every prefix partial-write cut for all three regions; independent-region invariance; version/nonce/overflow/crossslot substitution; zero and last-entry grants; slow sync cut after each reserved effect; concurrent actual Shared producers serialized by selector Exclusive; missing/partial factory never allocates another set; existing untracked primary write/read succeeds;>100 frame prefixes resume same stream with unchanged sourceE; error/panic release actual namespace/root/sharedactivity while bulk remains offslot; native Windows owning-handle read/write semantics. Pure codecs may be accepted separately, but production factory/admission needs this concrete extension review and integrated executed evidence.
