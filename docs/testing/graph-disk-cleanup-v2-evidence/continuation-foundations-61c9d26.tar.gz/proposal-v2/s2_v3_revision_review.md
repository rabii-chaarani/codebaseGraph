# S2 v3 focused revision verification

Proceed with the bounded implementation slices after recording the conditions below in Scryer. No blanket production Ready or native qualification is granted.

Input /private/tmp/dc-s2-bounded-authority-selected-mechanism-20261021-v3.md, SHA-256 88f647d10406eb44646f38430b3098cb7db6c1df07c3d99f5563866ef5c2478e, independently verified. GPT-6.1 Sol / Max, read-only, 2026-10-21. Only accepted frozen B/C source was inspected; current unreviewed S2/S3/S4 overlays and the separately running nonce correction were not treated as qualified.

The revision resolves prior F1/F2 and C1:
- Direct structural phases exception preserves the existing nested topology and rejects every additional entry in fixed native work.
- The local lane explicitly permits the2048-byte current-counter/checksum operation under shared activity+serial, outside state.lock.
- Guardian acquires its OWN Shared startup gate before the lifecycle lease, with exact post-block root/nonce/Closed checks. Parent/child ownership no longer depends on inherited Windows byte-lock ownership.
- RootSourceEpoch, local A, actual current-global before/after and stageG are separate. A workspace event does not reuse canonical OwnEpochAdvanced's captured-E contract.
- One moved payload retains source-ID == private-ID equality; a new container does not inherit that proof.

The three prebound files and single prebound stream are a concrete improvement over P=4 temporary creation. Initialization is9 effects without stream,11 with stream; P_b is6 and inert staging14, excluding separately charged admission reads. Initial prebinding failure remains a finite untracked root, with no repeated new job allocation.

Selected publisher layout condition before actual writes: Commit and Intent must have independently validated checksum regions, and writes must be range-limited. Publishing Intent preserves the previous committed selector; final Commit preserves the durable Intent. Otherwise one torn whole-selector write can destroy both recovery witnesses despite the prebound inodes.

Required recovery matrix:
- torn Intent + intact old Commit/old slot: no subsequent data effect was authorized; recover through the old committed state under actual ownership;
- torn inactive slot + valid Intent: rewrite only the expected bounded bytes from that intent;
- torn Commit + valid Intent/new slot: complete the exact intended commit;
- both witnesses invalid/mismatched: retain Unknown/NeedsRecovery;
- never select the highest slot generation by itself.
The expected next bytes must be available in the bounded intent or its equally bound immutable source, not only an unreconstructible hash. Test every partial-write boundary and recovery interruption. This region separation preserves P_b6; it adds no syscall target.

Clear implementation scope: projections/native probes, slot codecs/reducers and the prebound publisher with that layout; fresh factory/startup hooks with independent child gate acquisition; local current-global invalidation; and callback-only admission/private stage code against exact branded interfaces. Coordinate one writer per file and Root/Scope API signatures first. No generic ReferenceActivity::begin/acquire_shared helper may invalidate before local A validation.

The factory creation record must already be genuine/bound; slots and stream become covered only after final binding/readback. Ordinary acquisition does not recreate controls, upgrade unknown roots or allocate a second publisher. RootRemovalIntent stays outside the removed root. Stable gates stay public; Windows closes janitor incarnation handles and retries empty removal without blocking or recreating leases.

Production effects still require accepted S3 origin/current-source/journal proofs and the separately qualified nonce/cohort fix. Do not use old numeric cohort identity as durable recreation proof. The Linux replacement regression remains independently tracked; inode ABA is not declared its confirmed cause by this review.

No remaining design blocker for these bounded slices after the region-layout condition. Full Ready requires integrated prerequisite review, actual cost/slow-fsync/cancellation/crash tests, related writer progress, and native Windows evidence. No Cargo, source/wiki/model/Git writes or live operations; only this scratch report. No new memory candidate before implementation evidence.

