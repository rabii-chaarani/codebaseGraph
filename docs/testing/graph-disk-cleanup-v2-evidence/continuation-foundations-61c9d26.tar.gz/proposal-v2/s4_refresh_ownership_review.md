# S4 explicit refresh ownership — focused clearance

Proceed with the lifecycle-only slice after coordinator Scryer/file-ownership handoff. No collector dependency, new user decision, daemon, routing or public response change is required. This does not qualify the separate scheduler v6 implementation or full S4 integration.

Input /private/tmp/dc-s4-refresh-owned-join-proposal-20261021.md, independently verified SHA-256 5ea3b3280a0282262c4a1dce30ea4658ebc01f8aba134d79bff7d27be64c07fe. Reviewer GPT-6.1 Sol / Max, read-only, 2026-10-21. Source checked only in accepted frozen B/C baseline /private/tmp/cleanup-s2-bc-foundation-final-vvbfeega/repo.

The unique RefreshRuntime returned alongside cloneable CodebaseGraphApi is a sound ownership boundary. ApiCore retains status only; the worker captures state/cancellation, never Runtime. A cancellation token created before server spawn closes the early-stop race. Moving server/monitor handles out of their mutexes before join resolves the previous join-under-lock condition. Explicit cancellation makes retained State/Core clones irrelevant to refresh liveness and avoids the Arc-count join deadlock.

Selected implementation conditions:

1. Return an internal explicit lifecycle disposition, e.g. StoppedAfterDrain versus LegacyDisabled, from run_refresh_service. A cancellation flag racing the legacy return must not overwrite disabled with stopped. Genuine failure/panic must not become stopped merely because stop was also requested. Remove the premature inner mark_stopped; publish stopped only after leader/watcher/runtime/worker scopes unwind. Inspect JoinHandle::join failure too, preserving failed status if a panic escapes the outer service wrapper.
2. For monitor final-self-drop, check the Weak/termination tail AFTER releasing the iteration's strong Arc, before another sleep or route operation. A pre-drop strong_count==1 test alone is racy. An external drain takes its handle out, unlocks, joins, then snapshots/drains the owner outside the route mutex. Runtime cannot be captured by its own worker, so self-join is structurally excluded there.
3. Spawn is fallible. An optional refresh spawn failure returns failed status plus a Runtime with no handle; otherwise committed API reads remain available. Startup/executor failure after refresh creation must cancel and join that Runtime before dropping coordinator state/lease. Stop and Drop are idempotent.
4. Preserve all current supervisor policy/config retry, dirty-epoch, disabled, native/poll wait and actual worker-cancellable paths. The token replaces Arc-count cancellation; it does not create a new supervision or transaction-error policy. Owned join waits for actual completion, with no new shutdown deadline. Existing foreground watch APIs remain under their existing caller-owned lifetime unless separately transferred.

Clear writable scope: refresh.rs, facade.rs, coordinator.rs and coordinator/tests.rs as proposed, one writer per file. Core requires no Runtime field. If coordinator is still owned by scheduler fix review, serialize its handoff; refresh/facade work need not wait on unrelated collector design. Update every private tuple-return/start-service caller so a temporary Runtime is not accidentally dropped immediately after extracting state().

Required focused evidence: retained Core/State clones during stop; cancellation before startup; actual paused worker/destructor teardown with join pending and no early stopped status; legacy-disable/cancel and failure/cancel races; optional spawn failure plus valid graph read; server/executor startup failure cleanup; no mutex held during joins; monitor final-self-drop exits without another iteration; and existing refresh/coordinator regressions. Fixture thread counts and completed joins establish local ownership; native-platform qualification remains separate.

No confirmed remaining plan blocker for this lifecycle slice after the selected conditions. No Cargo, source/model/wiki/Git writes or live operations. No new repository memory candidate: this is implementation clearance, not executed completion evidence.

