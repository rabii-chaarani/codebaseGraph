# S4 Managed addendum verification

Proceed under the recorded selected table. The addendum resolves the focused conditions from review2a991; no new material conflict was found.

GPT-6.1 Sol / Max, read-only, 2026-10-21. Exact input `/private/tmp/dc-s4-managed-primary-result-addendum-20261021.md`, verified SHA-256 `84e6c1f6f5a3e70bb1d0d3db721efe9de2cd46cca80562439328153ed038ab0c`. Prior report SHA-256 `2a991ae1d2bea8fa8327566ab8b54d5553457e62c4fe834d0585a3dff8d6712c`; immutable source checked at a8b1c5bea66b04ee4afe3e7086bf08bfc0a7f89a.

- M1 resolved: lazy Absent/Valid/Invalid probes preserve normal staged-only/published-only/same-active seams and protect present-invalid required evidence.
- M2 resolved: ambiguous pointer errors retain Publishing evidence and do not mark the candidate retired. Same-active recovery completes sync_parent_dir(published.root()) and managed-root sync before ResolvedCommitted, without regenerating timestamps/READY/identity. The actual helper1274–1280 syncs both generation root and generations parent. atomic.rs writes and fsyncs the temporary file BEFORE rename, then syncs its parent; thus a readable newly renamed pointer after that boundary does not bypass an earlier unperformed file-sync step in this protocol. The addendum also preserves any other outstanding mandatory step if implementation exposes one. Repeated required sync errors stay primary.
- M3 resolved: generation-only preflight/enumeration faults are janitor issues and cannot prevent the required run enumeration/replay; later required errors remain primary.
- Identity/drop conditions resolved: actual post-reconcile active check; all validation snapshots drop while writer remains held, including error paths; finish_without_cleanup does not trigger another sweep.
- Reporting clarified: one original issue per report is moved, not cloned; issue history and actual extant-run counts are separate. The selected cases distinguish retained run1 from successfully removed run0 and do not derive remaining-work pending solely from issue count.

These are implementation starting conditions, not executed acceptance or full S4/controller qualification. Existing sync_dir Windows behavior validates metadata without flushing a directory handle; this review does not expand that platform guarantee. Independent exact-diff review, fault/caller/drop/compatibility regressions and supported-platform evidence remain required.

No source, Cargo, Git, model/wiki/Linear writes or live operations. Only this scratch artifact was written. No new memory candidate; coordinator owns reconciliation.
