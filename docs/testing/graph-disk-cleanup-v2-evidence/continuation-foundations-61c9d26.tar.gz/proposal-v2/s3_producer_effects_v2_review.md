# S3 actual producer/leaf effects v2 — bounded clearance

Proceed with the narrow producer-origin lane below after S2 capability acceptance and explicit artifact_store ownership handoff. The proposed whole-directory move of an unknown-containing canonical cache entry is NOT cleared. No new user decision is needed; select preservation within the approved unknown/foreign-data contract.

Input /private/tmp/dc-s3-producer-leaf-effects-gate-20261021-v2.md, independently verified SHA-256 44391219454b4265529f8d766f40603f9aee71a2b34548d6449549c92a4d4231. GPT-6.1 Sol / Max, read-only, 2026-10-21. Source observations use accepted frozen B/C checkout, not current unreviewed S3/S4 work.

## Selected publication lanes

1. Canonical absent: genuine exclusive temp creation, CreationBound before data writes, OriginOnly completion, then actual no-replace canonical publication and completed receipt. The native publish primitive must not replace an empty foreign destination directory that appeared after an absence check; plain POSIX directory rename can do that. Use the selected platform no-replace operation or fail safely.
2. Existing canonical payload exactly equals freshly produced bytes: reuse those actual bytes through retained FDs and final fixed identity/stamp checks under namespace exclusion. This may associate THAT payload leaf. It does not own its directory or unknown siblings. Do not overwrite an unrecognized receipt/control collision to attest the leaf; leave origin untracked/pending if optional attestation cannot safely commit.
3. Different existing canonical with unproven content/inventory: fail BEFORE any public move. Preserve old canonical/foreign addresses and the last committed graph; clean only exact fresh entries actually created by this attempt, then atomic-empty rmdir. Do not rename the unknown-containing whole key directory to a backup merely because baseline code did so.
4. A completely proved owned old inventory may use its separately verified bounded replacement/rollback protocol. Per-leaf replacement while unknown siblings remain public is an additional exact-intent extension, not an implicit permission from this gate.

This selects the minimum safe first implementation, rather than silently weakening origin. Tests must retain the former repair/reuse intent where actual ownership is proven and explicitly exercise ambiguous collision preservation/prepublication error. No ignored regression or fabricated success is acceptable.

The withdrawn NotCached fallback was correctly withdrawn: execution/run.rs inserts compact entries at117, then reloads from ArtifactStore at137–147. Successful cache-write/reuse outcomes must leave actual canonical bytes for that real reload. The primary materialization still performs normal load/validation; real reload errors remain errors. A cache receipt is not a claim that the graph publication committed.

## Cleared producer pieces and interface conditions

Clear actual exclusive temp-dir/payload/receipt creation observations, bound Creation/CompleteStaged OriginOnly records, digesting current envelope writes, exact fresh-byte reuse, and the safe canonical-absent publication lane. These can be implemented independently of the large legacy join performance gate: they do not mint LoaderUsable.

S2 must first provide actual root/scope and namespace-publication capability, using the qualified nonce/cohort correction and fresh/controlled initialization. Initialize the stable namespace control under factory exclusion BEFORE shared producer scopes; ordinary acquisition does not recreate missing controls, upgrade legacy actors or upgrade its own Shared root guard. tracked() and a root name are insufficient. Root use/reference participation spans creation through publication/error cleanup.

Use borrowed effect context/prepared frames for namespace callbacks, with bulk GraphPartition, byte buffers, paths and destructor owners outside the callback. Scope only fixed namespace/receipt operations. Payload serialization, equality and hashing remain outside namespace exclusion; final current FD/path/stamp checks occur inside. All cooperating publishers must use the same stable control/policy.

Hash only bytes successfully accepted by the wrapped writer; interrupted/short writes and flush/fsync errors cannot yield CompleteStaged. Check final length/stamp, and do not reserialize another envelope to infer its digest. Initial unbound birth windows remain unknown and are not called fully convergent. Optional postpublication attestation/janitor failure does not retroactively undo an actual successful cache publication; prepublication and actual validation errors retain their existing primary meaning.

Untracked means no origin/GC authority. Specify its primary-producer behavior before activating the call site: no unsafe old recursive replacement, fake NotCached success, or read failure solely to manufacture origin tracking. A reviewed actual no-replace/equality publication lane may remain origin-untracked; a differing ambiguous collision uses the prepublication failure above. Caller-owned roots remain outside automatic collection.

## Leaf effects and consumers

Callback-only leaf transition code may be implemented against accepted S2 Canonical/Workspace/PrivateJournal capabilities and branded origin/source/reference proofs. Do not enable controller GC callers until those prerequisites are reviewed. One payload's physical source ID must equal its private payload ID; a new private directory does not inherit it. Unknown siblings stay public; native operations anchor exact physical parents and never recursively remove an unproved tree.

Persist actual journal intent before public move; match the actual private inode before DetachedLeaf; separately account receipt/metadata leaves and partial seams. Recreated canonical data between payload and receipt steps cannot be touched by an old intent. Private replay never falls back to public names. All epoch, intent, receipt, cursor, rename, fsync, unlink and empty-rmdir costs use the same fresh grant and correct pre-reservation; bulk preparation/drop stays outside the dispatcher permit.

The required noncreating cache consumer guard is a lifetime/exclusion contract, not origin minting. It must cover actual load/validation, and existing whole-operation reference participation must protect future manifest publication. Missing optional origin metadata cannot become an unintended committed graph-read prerequisite. Preserve exact registered/legacy/caller-owned distinctions until S2 exposes the agreed APIs.

## Usability, legacy and remaining scope

The Root runtime's actual BTreeMap metadata policy and pinned scalar roundtrip oracle are required for LoaderUsable; OriginOnly does not bypass them. The adapter uses its own physically bound candidate FD; Windows seek_read must not share a cursor with a user/producer handle. Referenced backup restoration requires the full usable + exact expected-entry + current-reference/recovery composition.

The full default-memory millions-row join qualification remains open. Pure164 correctness evidence is not throughput or whole-collector acceptance.

Default Direct legacy coherence remains a concrete future mechanism, not a dropped category. Revision0.2 prohibits preparation holding database-family EXCLUSIVE authority; it does not categorically prohibit a Shared GuardedDatabase lifetime. A proposed native adapter still needs measured bounded allocation behavior and actual related writer/read progress while validation is paused; do not assume a native query is fast or that its pool parameter proves an OS/RSS ceiling. Genuine closed publication/history evidence or a bounded byte/coherence path may avoid native validation. This review chooses none without its concrete proof.

Required fresh review: actual syscall receipt/rollback seams, foreign existing key directory and control collisions, ordinary cache reload, new public incarnation during old replay, zero/entry101/time cuts, unknown siblings at original addresses, stageG progress without E-per-frame invalidation, and graph/cache result preservation. Run/phase/generation/legacy/Direct lanes and full S4 integration remain mandatory.

No Cargo, probes, source/model/wiki/Git writes or live cleanup. No new memory candidate before executed implementation evidence.

