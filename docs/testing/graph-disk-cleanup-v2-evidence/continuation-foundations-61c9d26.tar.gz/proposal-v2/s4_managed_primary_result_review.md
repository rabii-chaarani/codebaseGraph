# S4 Managed transaction/janitor split: selected starting conditions

Proceed with this bounded slice after recording the concrete correction table below in Scryer and transferring the three requested files. Types and the evidence-preserving retain helper can proceed independently. The role-typed split is the correct mechanism for the approved primary-result contract; no new product decision is needed. The original sketch alone does not resolve the specific recovery branches identified below.

Reviewer: GPT-6.1 Sol / Max, read-only adversarial-proposal-review-engineer, 2026-10-21. Input `/private/tmp/dc-s4-managed-primary-result-proposal-20261021.md`, verified SHA-256 `6753f5d586f719ec39e894c1cbdcdacd19c273cfad3503b5a8f77c3d335de085`. Source inspected by immutable Git reads at accepted `a8b1c5bea66b04ee4afe3e7086bf08bfc0a7f89a`; current working overlays were not used as qualified evidence. No Cargo or implementation execution.

Approved authority: existing canonical DC revision0.2, DC-S3-R8 / DC-S4-R7 / A4; Scryer chg-6vx5tj, node-hxxbg1, existing Graph Store resp-108/109/232/233 and Materialization resp-238. Required transaction/publication/validation failure remains Err; only resolved postcommit janitor failure may become pending after actual API verification.

## Findings and exact selected corrections

### S4-M1 — Distinguish absent alternatives from required invalid evidence

Established source branch distinction; material starting condition for the transaction helper.

managed.rs687–784 currently probes BOTH published and staged bundles as booleans. Replacing both with unconditional fallible validation would reject normal recovery before generation rename (published absent/staged valid) or after it (published valid/staged absent). Conversely, keeping the booleans would still erase corrupt/I/O-unknown required state.

Use an explicit Absent / Valid / Invalid(error) probe of the actual candidate/published addresses. Only an established namespace absence is Absent; symlink/foreign/non-directory, corrupt present evidence and I/O errors are not an absent alternative. Select the required branch before validating its full evidence:

- active==candidate: published bundle is required; its failure retains recovery evidence.
- active/base match, published absent: staged bundle is required; successful promotion/activation supplies the committed outcome.
- active/base match, published present: validate that exact published bundle; do not overwrite it or silently prefer staged after a present-evidence failure.
- neither required incarnation exists, or associations conflict: recovery Err/Unknown, retaining the journal.
- base no longer matches: return an explicit obsolete/rejected disposition only from the existing validated stale-base branch. Ordinary publication still returns its stale-base primary error; recovery may perform its separately resolved optional cleanup. A failed read/validation is not that disposition.

The per-run decision stays private and consumed under the same actual writer/state ownership. It is not a transferable authority, serializable receipt or S2 terminal seal.

### S4-M2 — Recovery must finish mandatory durability, not reproduce the old fallback

Established interaction between existing source branches, blocking an implementation that only removes publication_is_committed while retaining the old active-candidate shortcut.

activate_published_generation_locked823–837 can return Err after a pointer becomes readable, including required atomic-write/managed-root sync failure. The old publication fallback1000–1012 checks pointer/READY readability. The existing recovery active==candidate branch715–721 also checks readability and proceeds directly to retirement/removal. Thus removing only the outer fallback leaves a later recovery route that can call the same uncertain boundary committed without completing it.

Selected rule: an ambiguous publication error preserves the exact Publishing journal/candidate/published evidence and remains the original primary Err. Remove the candidate-retired marker write from the ambiguous pointer-write error branch as well as moving previous-generation retirement out of the transaction helper. A candidate is not disposable merely because its pointer operation returned an uncertain error.

An explicit active==candidate recovery branch must validate the actual required bundle/pointer and complete the existing required publication durability steps before yielding ResolvedCommitted. Resume/repeat the necessary existing file/parent/root sync and atomic publication protocol under actual ownership; do not invent a boolean readback success certificate or silently change semantic timestamps/identities. Any repeated mandatory write/sync failure remains Err and keeps evidence. A successful normal transaction path may produce the same typed disposition directly.

This does not require a new durability protocol; it requires the selected recovery branch to complete the existing one. A test where atomic pointer publication returns an error despite readable valid bytes must fail first, retain byte-identical recovery evidence, then recover only when the mandatory fault is removed. No workspace finish/abort/Drop may destroy or rewrite the ambiguous Publishing evidence in between.

RunWorkspace::retain_for_recovery(self) may mark only its in-memory destructor state finished, release its actual run lease and ReferenceMutation normally, and leave the durable bytes untouched. It is not mem::forget and must not label the root terminal/aborted. Coordinate S2's future lifecycle hooks: finished=true alone cannot become a terminal-cleanup proof. Failure to journal Publishing BEFORE any transaction effect may keep the existing prepublication abort path; retained ambiguity begins once a transaction may actually have affected publication.

### S4-M3 — Generation-only scans are janitor work, not run-recovery errors

Established mixed preflight in managed.rs500–532 and optional scan862–900; material condition for truthful typed outcomes.

has_reference_cleanup_work currently scans run references AND generations before required recovery. collect_retired_generations_locked also propagates iterator/file-type errors. In the typed path, an error solely inspecting/removing unrelated retired generations must not escape through transaction Err or prevent later required run recovery. Classify it as a generation janitor issue and retain incomplete observation.

Required run enumeration/journal/association/selected-bundle/publication errors remain recovery Err. After the first optional issue, stop/defer additional optional work as appropriate but continue every required transaction decision for remaining runs. A later real recovery error wins as the primary error. Do not report a completed pass after abandoning unvisited transaction evidence. This correction can be implemented by reordering/folding the existing single run enumeration and role-tagging optional generation preflight; no extra full sweep, unbounded retained list or new recursive collector is selected.

## Caller, lifetime and compatibility conditions

The proposed ManagedPublication / ManagedReconciliation / ManagedJanitorReport and typed session/store entry points are suitable. NativeError classification comes from the operation's role, not text/errno. Keep bounded counters/flags and one original issue per report; the later cached-summary adapter must reserve copied diagnostics through the shared account. An absent attempt/partial observation never becomes a successful measured sweep or zero bytes.

Keep cleanup and recover_and_gc strict compatibility wrappers flattening a nested issue to the original error. The private owned-writer helper is used only by the same store/session's actually acquired writer and is not an arbitrary-lease or public controller admission API. Publication compatibility may move its nested report into session storage without cloning NativeError; audit its consumers before removing it. Existing context.rs resolver behavior remains strict in this slice. That compatibility choice means this slice does not close all committed-reader/controller availability work.

The API keeps full actual candidate validation before publication and actual published-generation readback/native count/digest/search/artifact verification afterward. No pending conversion occurs before those succeed. After reconcile_typed, re-read/check the actual active generation AGAIN before setting success fields; the pre-reconciliation identity check alone cannot detect an activation performed by reconciliation. An identity change remains a primary error.

Drop the verification ManagedReadSnapshot while this session still holds writer ownership, THEN call finish_without_cleanup to release the writer. Otherwise GenerationLease::drop can acquire the released writer and start an unreported best-effort attempt. Do not remove the established last-reader cleanup policy for other callers. Release all outer reference/run/read/writer resources before any later scheduler completion hook. No hidden session.finish mixed cleanup occurs in the migrated path; unmigrated finish behavior remains separately audited.

Legacy pending_runs counts actual known pending/locked runs once. A generation problem does not fabricate a pending run. Preserve lower-bound counters with observation_complete=false and a concrete bounded deferral/issue reason when full counting is unavailable. If an optional journal error is followed by successful actual run disposal, do not claim an extant failed run; either defer that disposal after the first issue or reconcile its remaining-work/count facts. Strict wrappers and existing JSON/block fields retain their contract.

## Clear scope and remaining gates

Source ownership: S4 exclusive managed.rs and api/materialization.rs; narrow run_workspace.rs retain helper/inline regression. S2's future run/launcher edits must serialize with this ownership. direct.rs, context.rs and core.rs remain read-only; test_harness.rs stays coordinator/S5-owned. No refresh-lifecycle files, manifests, module exports, native API, GUI or routing changes.

Clear starting work after the table is recorded: private result/decision types; tri-state ready probe; transaction-versus-janitor helper split; strict adapters; no-write recovery retention; and postverification report application with explicit identity/drop order. No blanket collect/Ready capability is supplied by a typed report. Existing legacy scans/deletion are not mutation-budget qualified by this refactor; do not wire cleanup_typed or recover_and_gc into the bounded scheduler. Full S2/S3 controller and typed recovery dispatch remain separately reviewed dependencies.

Required meaningful verification: normal staged-only/published-only/active-candidate recovery; present-corrupt and missing required evidence; pointer/rename/metadata/READY/parent/root-sync errors; exact retained journal plus released actual leases and subsequent recovery; optional generation preflight/removal failure followed by later required-run success AND failure; real postcommit-pending native pipeline after unchanged full verification; post-reconciliation active change; snapshot-before-writer drop/no hidden sweep; strict legacy wrapper behavior; original storage/crash/read-lease/last-reader/abort/Direct/convergence regressions. Preserve original primary prefixes when secondary cleanup also fails. Native/public result qualification needs actual graph/search/context evidence, not synthetic storage bytes alone.

Procedure/limits: fresh subsystem memory recall, current canonical wiki clauses, explicit-checkout Scryer orientation, sequential graph discovery and immutable source reads. First orientation's approval review timed out; the single permitted retry succeeded. No safety rejection, user approval request or blocked tool remains. Working-tree drift is not treated as accepted implementation. No code, Cargo, Git/wiki/model/Linear writes, probes or live operations; only this scratch report. No new memory candidate before executed outcome evidence. Coordinator owns Scryer/ownership/evidence reconciliation.
