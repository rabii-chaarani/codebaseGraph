# DC-S3 next effects gate: actual producer receipts and exact leaf retirement — v2

Read-only review input, 2026-10-21. This does not authorize effects. v2 corrects the unreviewed NotCached idea in the prior scratch draft (SHA0b2063587e2322be8b7b1d649dd180bac70620b30b48873c966e5801c0799d17): execution/run.rs retains compact entries and reloads artifacts at lines137–147, so retaining an in-memory partition does not provide an end-to-end fallback. Canonical contract remains the existing wiki revision 0.2; detailed accepted briefs belong in Scryer chg-6vx5tj. Builds155/163/164 and their qualification remain preserved. Pure164 passed78 tests; its source is immutable. Source discovery used the configured graph; its original-checkout index is older than the isolated implementation, so current source was checked after discovering target files. One transient graph-context busy result succeeded on retry.

## Starting interfaces and ownership

S3 retains validation/journal/controller files. Before writing production hooks, assign artifact_store.rs to S3 explicitly. S2 owns maintenance_ownership.rs/locks and actual scope/admission capabilities; S4 owns dispatcher/runtime classification. Staging/generation/Direct hooks need separate serialized transfers. No shared budget API changes are proposed.

```rust
// S2 factories: bound to the actual retained guard and exact root/incarnation.
struct ArtifactProducerScope<'a> { /* private live ReferenceMutation borrow */ }
struct ArtifactPublicationAuthority<'a> { /* private actual namespace exclusion */ }
struct PrivateJournalAuthority<'a> { /* private-only exclusion, SAME MutationGrant */ }

fn artifact_producer_scope<'a>(mutation: &'a ReferenceMutation,
    root: &ValidatedArtifactRoot) -> ProducerScopeOutcome<ArtifactProducerScope<'a>>;
fn with_artifact_publication<T>(scope: &ArtifactProducerScope<'_>,
    frame: &PreparedProducerFrame,
    apply: impl FnOnce(&mut ArtifactPublicationAuthority<'_>) -> Result<T, NativeError>)
    -> PublicationOutcome<T>;

// S3; constructor consumes actual successful exclusive-create observations.
struct CreatedArtifact { /* exact dir/payload/receipt IDs, live FDs, role/key/nonce */ }
struct CompletedArtifact { /* exact bytes digest/length; origin ONLY */ }
struct LoaderUsable { /* private full composition + pinned runtime policy + source stamp */ }
struct PreparedLeafDetach { /* bulk stays outside permit; borrow fixed hot frame */ }
```

`tracked()` or a root pathname is insufficient to make ArtifactProducerScope. It must prove this retained producer guard protects this exact registered root and supported cohort. Unknown/caller-owned roots and unsupported producer cohorts gain no collection authority. A new stable namespace-publication control must be created/bound only by the approved fresh-root/controlled-upgrade procedure; never recreate a missing/replaced coordination inode during ordinary acquisition. Its identity and supported producer policy become scope evidence. Existing mixed producers that do not understand the origin transition protocol cannot be silently called covered. S2 must settle the actual bounded exclusion/upgrade API before hooks run.

Proposed namespace serialization is one stable control per registered artifact root, held only through prepared constant-size namespace/receipt transitions; payload serialization and equality/hash scans occur before acquisition. This avoids one immortal coordination inode per artifact key. Root-use guards retain their established ordering. The new control must not be confused with the reference epoch or used to relabel E. Reusing an existing serial control instead requires an explicit S2 lock-order/meaning review, not a local shortcut.

## Origin format and real producer operations

Extend the pure receipt codec with an actual fixed ArtifactOriginRecord: version, supported producer-policy ID, root/destination/use/publication-control physical identities, typed role, key[32], unique private nonce, directory/payload/record physical identities, publication transition ID, byte length/SHA256 and phase. Fixed FileIdentity encoding must preserve the actual platform fields; a hash of a caller-provided label is not physical identity. There are no unbounded paths/strings. Root/destination policy determines exact derived addresses; public Direct raw spelling remains unchanged in its own later protocol.

Store `.entry-origin` inside the actually created temporary/artifact directory. It moves with that directory and needs no global per-key catalog. Allow only the fixed payload/receipt/preparation names whose actual creation identities are bound. A receipt preparation inode is created_new and bound by an earlier durable record before an atomic update; torn first creation without an earlier binding remains unknown. No record checksum authenticates deliberate valid-record forgery by a local writer.

Producer sequence:

1. Retain existing whole ReferenceMutation/root-use participation. Create the unique temp directory and payload with exclusive creation. Capture actual opened IDs, then persist CreationBound before payload writing. Crashes before binding remain unknown, honestly. In-memory failure cleanup may remove only the exact entries it actually created and then attempt atomic-empty rmdir; never recursively erase unexpected children.
2. Stream the current envelope through a digesting writer using the existing output buffer. Hash bytes actually accepted by the writer, not a second encoded envelope. Mark CompleteStaged only after flush, payload fsync and directory durability. The current raw-row validation already ran, but the receipt is OriginOnly: it does not certify f64/depth/metadata parse-to-serialize usability.
3. Prepare old/current/temp identities and byte equality outside namespace authority. Enter the exact S2 producer namespace callback, check the fixed frame and actual FDs/paths, persist rename intent before moves, then perform the bounded established publication/rollback sequence. Mint Published only after the canonical rename and directory fsync actually completed. Retain transition evidence across every interrupted boundary.
4. Reuse may mint origin only after complete equality with fresh actual produced bytes through FDs and final canonical-directory/payload identity checks. Header/key/schema-only equality is insufficient. Actual reuse is the association event; intent alone is not.
5. The backup retains the OLD payload's origin. An unknown old artifact never gains origin because a new artifact was produced. Unknown old contents are not handed to remove_tree_confined/remove_dir_all. The compatible candidate is to keep the ESTABLISHED normal producer old-canonical→backup rename and new canonical publication, but retain every unproven old backup byte instead of recursively erasing it. The newly published canonical remains available for run.rs's later reload. No NotCached/in-memory fallback is proposed: run.rs discards the built partitions after planning. The Max gate must confirm that retaining the existing normal producer rename of an unknown-containing old cache entry is within the approved existing publication contract; if that rename is prohibited, this lane remains pending rather than silently returning success. Safe prepublication failure with the last committed graph preserved or a separately reviewed exact per-run temporary locator would require an explicit agreed contract. Report retained backup residue through bounded maintenance diagnostics. Actual prepublication I/O errors keep their current semantics; optional postpublication janitor/receipt completion failure never undoes an authoritative successful publication.

ProducerOrigin factories verify exact root/destination ownership separately from entry origin. Completed bytes and genuine publication are distinct from loader usability. Initial implementation need not add a second scalar/depth walk or maintenance memory account under a producer writer: maintenance composes independent LoaderUsable outside all cleanup authority. A later ProducedUsable optimization would need the SAME pinned parser/serializer oracle for EVERY typed f64 and metadata Value number, not finite/depth checks alone.

Ordinary artifact cache consumers need a noncreating shared-use guard across actual disk load/validation; missing roots return missing without metadata creation. Guarded run/base/recovery references must span future manifest publication, so loading an unreferenced old key cannot race collection and later publish a manifest referring to deleted cache. These are required S2 coverage checks before enabling GC, not proof manufactured by the receipt.

## Usability and reference preparation

The approved FD adapter borrows an exclusive Rust handle reference with no path allocation/repair. Actual runtime opens its OWN noncreating, physically bound candidate FD through S2 preparation. Unix read_at does not move the cursor; Windows seek_read does, so it requires a dedicated handle with no cursor-sharing clones. It cannot borrow a user's sequential writer/graph-read FD. Native Windows remains qualification pending until executed.

LoaderUsable composition requires all of: complete lexical/schema/depth facts, exact raw-row join, correct key/partition ID, stable pinned typed/Value numeric forms, exact string/default/field forms, actual runtime metadata Map policy, matching checksum, and unchanged bound source stamps. Current ROOT serde_json1.0.150 is default+std/BTreeMap; preserve_order/indexmap belongs only to tree-sitter BUILD context. Thus current metadata usability requires sorted unique decoded keys. No arbitrary sorting/rewrite of source occurs. Runtime policy/version and the source incarnation are bound into the witness.

Current references are recomputed against SAME initial E, streaming active, retained generation, scoped run and recovery sources. Unknown association or recovery makes completeness false. Missing referenced canonical backup restoration requires LoaderUsable and exact path/content/language comparison across its source and every current reference; a hash is an accelerator, not equality. Conflicting references/multiple ambiguous backups remain protected.

NeedsRecovery for Publishing releases all preparation/authority. Established recovery runs under its own actual admitted execution. Discard old E and reprepare; no recovery result rebadges stale references. The full default-memory large-file join performance gate remains open:164's small join/long-string tests are correctness evidence, not a throughput qualification for millions of rows.

## Leaf-first actual retirement and crash recovery

No whole unknown-containing workspace/key directory is renamed. Select one proven-origin regular payload leaf and its exact metadata leaves; unknown siblings remain at their public addresses. A directory is removed only by atomic-empty rmdir after its own identity check. Stable coordination inodes remain public and are never treated as payload.

Prepare the source FD/stamp, exact current references/lifecycle proof, complete fixed journal bytes and final hot frame outside destination/state/exclusive-root/family/dispatcher authority. S4 retains bulk PreparedWork outside the mutation callback; drop/decode/disposal never runs under the permit.

Actual transition under fresh grant, started before dispatcher/admission:

1. Consume the exact global E for canonical cache GC, or S2's distinct exact workspace-local terminal seal for selected workspace leaves. Neither is a bare-path capability. S2 invalidates the required CURRENT reference domain only after validating the captured version; no global absence claim is made for workspace-local compaction.
2. Persist exact incarnation journal/Detaching record before any public leaf move. Derive a unique same-root private leaf name, reserve the WHOLE bounded transition's conservative touched-entry cost, check time before each effect and use the S2 bound root/parent handles. Source/publication locks remain in agreed writer→state order. No source scan/hash/decoder runs inside the callback.
3. Rename only the selected exact payload into its private leaf address; separately move only its exact receipt metadata if applicable, while the same source exclusion prevents supported replacement. Fsync affected parents. Recheck the actual private incarnation against the recorded source; only that matching observation can yield an opaque DetachedLeaf proof. Do not infer detach from own E increment, intent, source absence, name or successful marker write.
4. All subsequent deletion uses private names and matching private IDs. A recreated public key/Direct ACTIVE bundle cannot be addressed by an old journal. Expected missing private payload advances only its corresponding durable disposal frame. Mismatched private contents are unknown. Permission failure preserves evidence and permits fair work on other leaves; restoration permits retry.
5. If crashing after own E increment but before Detaching/rename, journal remains preparation/recovery state. It cannot yield detached proof without matching actual private incarnation. Mixed/partial namespace transitions recover through their fixed exact intent and actual IDs, never a public fallback. Atomic-empty directory removal is separately budgeted and cannot erase unknown siblings.

Mutation confinement requires anchored physical parent/root handling, not a canonicalized string joined after preparation. If a source/private postmove ID differs, never unlink it; retain/restore only through the exact safe recovery protocol. Supported producer mutations must be excluded by actual capabilities, and current/static foreign substitutions fail fixed checks. The chosen native helper's behavior under uncoordinated concurrent namespace replacement needs an explicit test/qualification statement; an unsigned receipt is not an excuse to claim arbitrary local-writer authentication.

Use conservative budget units for every independently touched source/destination entry and housekeeping operation; no tree is one entry. Include epoch/journal/cursor/receipt writes, renames, unlinks/rmdir and necessary durability steps in the precomputed upper cost. A syscall may overrun100ms cooperatively, but entry101 never starts and zero grant has no effects.

## More than100 frames and all remaining categories

Inert journal segments/cursors stage under private-only authority with the SAME account/grant, no reference mutation and no E increment. Immutable source_epoch and mutable stage_generation stay separate. Each committed fixed segment/frame makes durable monotone progress across fresh processes. Complete coverage/current source validation happens offauthority before final leaf transition. No scan of previous frames occurs under an actual permit. One-payload JournalFacts can describe ONE selected leaf; a fresh multi-leaf private container would require separate genuine container creation plus per-leaf bindings and is not authorized by source-incarnation equality.

After this modern-artifact lane, mandatory run/phase, generation, legacy CSV/snapshot and exact old-default Direct lanes remain. Source mapping shows staging file creation in staging_writer/accumulator.rs and spill.rs; their File::create/remove_dir_all paths need scoped producer leaf hooks and safe known-leaf cleanup after ownership transfer. Caller-owned low-level staging remains excluded. Enclosing parent/run/barrier/Guardian/publication proofs come from S2; nested Empty alone is insufficient. Stable incarnation locks need the reviewed Closed/late-start/RootRemovalIntent protocol before last atomic-empty cleanup.

Direct bundle retirement first persists exact RETIRING, so partial bundles cannot appear committed; S4 returns typed rebuild-required. Explicit normal rebuild creates a new ACTIVE incarnation; old private replay cannot touch its public names. Default repository-local exact raw pair only; custom/external Direct is excluded. Recognized legacy migration without a manifest still uses full historical schema plus root/repository/partition association and cross-file coherence under confirmed exact quiescence—never a new manifest prerequisite.

Remaining concrete proof gap: an old Direct DB lacking genuine closed-publication evidence cannot be opened through GuardedDatabase for a slow native coherence check while pretending preparation has no family authority. Its migration needs a reviewed bounded byte/history/coherence path or genuine closed producer evidence. Unknown state stays protected while that mechanism is resolved; the mandatory category is not declared complete or dropped.

## Required effects tests / gate

Review actual S2 producer/root/private-journal capabilities and complete source ownership assignments first. Then isolate producer receipt hooks from collector effects. Test create/bind/write/fsync/rename/rollback/commit/reuse crashes, unbound windows, control/root replacement, unknown extra files, hardlinks/symlinks, byte corruption, origin-only numeric counterexamples, receipt disk failure and primary result preservation. Native scope/alias/whole-consumer lifetime coverage remains required.

Actual leaf transition tests must exercise zero/entry101/deadline, every crash seam including own E-before-intent, new public incarnation after detach, exact private proof replay, permission restoration, unknown siblings at original names and immutable stable locks. Fresh process/grant beyond100 staged leaves must converge without E-per-frame restart; blocked-first fairness remains. Backups restore only after real expected-reference proof. S5 retains active cache reuse, graph/search/context equality and20 update/failure/no-op clean-control plus native platforms. No overall collection qualification follows from pure codecs or configured CI alone.
