# Full selected visitor: fixed ownership/layout selection for proposal gate

Answers queued Max layout questions for14dc15f+718c64e. No visitor source/Cargo/effects. First implementation checkpoint remains complete current catalog/default/suffix/index trace against genuine187 fixtures, before string DATA/row visitor. Pure189 header/key facts are separate.

## Selected fields and exact cursor counts

One NODE table/group at a time; only these four tables emit witness rows:

| Table | Selected STRING/JSON columns |
|---|---|
| Repository | id,label,kind,path,metadata(canonical_key) |
| SourceRoot | id,label,kind,path,metadata(canonical_key) |
| File | id,kind,path,content_hash,metadata(canonical_key) |
| Contains | id,kind,source_id,target_id,metadata |

Exactly FIVE current selected-column cursors maximum. Contains.kind is inspected on every Contains row to select repository_source_root/source_root_file; other Contains values remain unrelated graph-value data. A cursor can advance a skipped row ordinal without decoding that row's dictionary string. All Repository/SourceRoot/File rows and all selected support Contains rows participate in full extra/missing/multiplicity checks. Metadata is parsed as complete bounded JSON, extracting exact canonical_key; selected support Contains metadata must match genuine producer's empty metadata. Schema/type/default shape is checked for every declared field, not just selected values. Native confidence/ordinary graph-edge values are not usability-certified.

Each selected-column cursor owns ONE bounded metadata-span reader and at most five primitive descriptors for its CURRENT segment: parent-string metadata, optional-null metadata, dictionary-index scalar metadata, dictionary-offset metadata, dictionary-byte-data metadata. Parent row count/type and dictionary children must agree with the exact supported StringChunkData grammar. No vector of segments; each cursor lazily parses the next segment once when cumulative row ordinal reaches its end. There are25 descriptor records maximum across the five columns. Selected compression metadata has no ALP branch; unselected DOUBLE metadata is consumed by fixed grammar scratch (one ALP child, not recursive arbitrary nesting).

Outer reader first frames the current group, records the five selected COLUMN spans plus version span and its resume offset, then runs the zipped column cursors. Version info follows chunk columns in the actual serializer, so its span is known before emitting rows. After the group is exhausted, drop/reinitialize these five cursors and resume outer framing. One outer reader + five column metadata readers + one version reader = SEVEN fixed256-byte metadata buffers simultaneously, with all other scalar state fixed. Catalog scan reuses outer-reader storage before row scanning; it has no eighth persistent stream. No per-row rescan of whole metadata and no retained all-group index.

## Retained locators survive scanner advance without retaining its state

Resolve dictionary index, adjacent offsets, nullness and dictionary-data descriptor while emitting a selected value. A retained NativeLogicalStringLocator is a COPY of the resolved DATA stream descriptor and logical start/length. It does NOT store a borrowed pointer to a current cursor, index/offset page, page-cache bytes or group-local vector. The only scalar stream needed later is the dictionary DATA u8 stream. Proposed exact scalar value layout: source selectoru8,compressionu8,scalarBitsu8/reserved padding to8; startPageu32,pageCountu32; numValuesu64,minu64,maxu64,logicalStartu64,logicalLengthu64. This is56bytes under the selected repr(C) scalar layout (actual sizeof assertion during code). No heap ownership, text prefix or whole dictionary. Null/missing/empty are distinct tagged cases; empty has length0 and requires NO DATA page read, even when dictionary data numValues0/INVALID_PAGE/no pages.

The source identity/stamp is separate from semantic equality. A native locator references the one prepared DB incarnation fixed for that validation job. A cache JSON locator carries the fixed artifact key/address, exact source incarnation/stamp and JSON span; it is not an index into an unbounded registry of files. Retained join-slot layout includes this full fixed locator/stamp and is charged capacity*actual_slot_size before allocation. No Vec<PathBuf> or open-FD inventory. A fixed resolver opens at most TWO comparand sources at once, with the independent native scan source giving a maximum of THREE payload file handles. Reopening a cache locator must noncreate, bind expected incarnation/stamp and fail Stale on mismatch; it never silently updates the locator's epoch/stamp. All fixed resolver/handle wrappers and any bounded path-component construction are charged in the SAME account. Actual S2 stamp/anchor types enter the final sizeof ledger; no lossy timestamp stand-in or unchecked path authority is selected.

Later comparison reads resolved logical u8 bytes directly from copied dictionary-data descriptor; it never needs the old group's metadata or re-scans it. Cache comparisons use the existing complete JSON-decoded cursor. Source stability is validated before/after every scan/replay and reopen; a changed candidate invalidates all facts/locators. These facts still mint no authority.

## Three page buffers and nonreentrant ownership

Exactly THREE4096-byte DATA page buffers: one in RowScanScratch, one in CompareLeftScratch, one in CompareRightScratch. Each comparison side also owns its own256-byte key buffer/carry and12-byte scalar decoding scratch. They share no mutable page cache with the row scanner or each other. RowScanScratch services the five zipped columns serially, returning scalar values/copied locator records only; no reference into its page buffer escapes.

Every page cache tag includes explicit source-slot/incarnation identity and physical page number. Any source reopen, stamp mismatch, profile phase change or reassignment invalidates that context's tag before reuse. No global cache/map. Outer parser's seven metadata buffers are independent of all three DATA page buffers. Reentrant exact comparison during a join callback borrows only CompareLeft/RightScratch; it cannot borrow/reenter RowScanScratch. The callback receives a fixed copied locator/event, not an owned iterator or mutable scan state. This permits collisions/equality checks while current row cursors remain live without aliases or overwritten cache bytes.

There is ONE reusable RowFieldUtf8 scratch (256bytes+4carry+12scalar) for scanning/hash/extraction of a current selected value; comparisons have TWO independent complete decoder contexts (each256+4+12). Hashing a row field uses that reusable row scratch before event emission. Same domain+decoded bytes hash the same across native and JSON encodings; first lexicographic difference never bypasses complete validation.

## Finite reservation composition

Reserve before constructing fixed scan/work buffers. The later Rust structs will have const size_of assertions and a ledger reporting actual layouts; no '<32KiB' ceiling claim:

- DATA page byte storage:3*4096 =12288 bytes.
- Metadata reader byte storage:7*256 =1792 bytes.
- Row/left/right key byte buffers:3*256 =768 bytes; UTF8 carry3*4 =12; scalar scratch3*12 =36.
- Current column descriptors:5*5 =25 `PrimitiveChunkDescriptor` records; exact fields are two pageu32,numValuesu64,min/max16-byteStorageValues,compression/type/flags. Fixed format grammar scratch frames8 maximum, with supported depth proven from primitive/string children and one ALP child. No user-controlled recursive type/expression grammar.
- Current-row selected references:5 tagged fixed logical locators; five column-span/cumulative-row cursors; one version span/vector-state cursor; one outer resume/header/profile state.
- Selected table-ID/column mappings:4 tables*5 selected columns. For the confirmed current schema profile, current property map capacity18 (File18 is maximum, common17/edge10), plus fixed complete expected schema/table membership bitmap generated from reviewed schema assets. Unknown extra properties/types are Unknown, not a request to grow an input-sized map. The profile's known table list is static; runtime table IDs/seen flags use fixed schema-sized arrays, not arbitrary table count.
- ONE existing MaintenanceJsonReader for current metadata canonical-key/empty-object validation, with its actual fixed4096-byte token buffer/frame reservation. It runs on a logical NativeUtf8 ByteSource using row scratch; it has no hidden String/Value or second unaccounted input decoder. Existing reader reservations stay live through disposal.
- TWO fixed comparand source/resolver wrappers plus independent scan-source wrapper and S2 stamps/anchors; actual fixed layouts charged. No worker/process job or source-registry allocation.
- Bounded semantic join table:checked capacity*updated fullslot layout, fullhash-prefix stack/collision cursors and5-field references included. Slot locator enlargement is part of reservation, never charged at the old128-byte slot size. C=0 fails before use; C>=1 exact collision progress remains.

These counts select all simultaneously live owners. Values/layout padding, source stamps and JSON reader must use actual Rust sizeof/owned capacities rather than this list's byte-buffer subtotal. Drop buffers/resolver owners before reservations. Shared controller/PreparedWork account continues covering retained objects outside mutation callbacks; no second ceiling. OS/native RSS is not claimed by requested-layout accounting.

## Source-backed visibility and first differential checkpoint

VersionInfo vectorSize may be SHORTER than ceil(rows/2048). version_info.cpp422–426 returns null for missing trailing vector; isInserted575–584 =>true and isDeleted563–572 =>false. Preserve implicit all-visible trailing row vectors. Explicit hasVectorInfo=true with incomplete bytes is Unknown. NO_INSERTED skip, ALWAYS_INSERTED visible except committed deletions. Add an early-vector deletion plus untouched trailing vector fixture, not a vector-size-equality assertion.

All-empty string dictionary has zero logical DATA numValues; zero-length string resolution compares/hashes an empty byte stream without reading a nonexistent page. Null remains a separate state.

The FIRST implementation checkpoint is catalog/default/suffix/index-only trace. It must reproduce all112 table catalog entries and exact table_info properties/defaults/current index shapes from187 fixtures, reject added macro/custom-index suffix fixtures, and stop on any captured-latest-native/package-source field differential before implementing strings. Actual public native introspection187 probe confirms20 generated pk_<table>_id HASH indexes, not all112 declared tables: expectation follows materialized COPY tables, with empty declared tables having no deferred index. Full cache facts provide the producer table-presence set; do not require an invented index on every empty table. Keep existing supported-profile shape safeguard on all suffix sets, never bless an unexamined suffix.

No causal source/fixture contradiction identified so far; the actual prebuilt native binary identity is captured separately. Field widths, catalog prefix counts, selected schema/default/type forms and generated index names match source/native queries. Exact byte-level suffix/default trace is intentionally the first staged implementation test, not already claimed executed. Historical41 and other native layouts remain separate profile qualification work, not silently covered by43.
