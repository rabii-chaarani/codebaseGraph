# DC-S4 typed Managed recovery and janitor boundary

Read-only implementation proposal, not clearance to edit. Approved DC-S4-R7/A4, revision0.2, Scryer `chg-6vx5tj` / `node-hxxbg1`; existing Graph Store claims resp-108/109/232/233 and Materialization resp-238 apply. The five refresh-ownership v4 files stay frozen. No collector authority, public policy, GUI, daemon, routing or new JSON schema is introduced. Fresh Max proposal review and exact ownership transfers precede implementation.

## Current implementation evidence

Memory recalled; wiki list/search/get canonical cleanup contract and explicit-project Scryer orientation completed. Semantic slim graph search/context located managed.rs, direct.rs, materialization.rs, context.rs, run_workspace.rs and atomic.rs before their source was read. The configured graph is older than the shared checkout; current code facts below were verified at those discovered files. No source edits, Cargo or live state operations for this proposal.

- `prepare_storage_execution` calls `resolve_runtime`, drops runtime read handles, then acquires a destination write session. Managed runtime resolution calls `store.cleanup()` before `resolve_active_read`; this existing strict wrapper must not be silently weakened.
- Managed `publish_with_stats` marks Publishing, calls `publish_candidate_inner`/`finish_run_locked`, and calls `finish_committed_workspace`. That helper discards both Published-journal and run-disposal errors. Generic publish errors are currently retried as success when `publication_is_committed()` reads a valid active pointer. That fallback mixes postcommit retirement faults with genuine transaction/unknown-durability faults.
- `activate_published_generation_locked` writes metadata/READY, atomically writes the active pointer, syncs the managed root, then calls `finalize_previous_retirement`. The last step is janitor work currently returned through the same NativeError channel as pointer publication.
- After publish, the API reopens the active generation, checks identity, reads its manifest and validates graph counts/digest/search/artifact references. Only then it calls `session.recover_and_gc()`. The latter can replay/promote/activate other publishing journals, remove run trees, mark/delete generations, and return one NativeError. Catching that error as cleanup-pending would hide genuine transaction recovery failures.
- `session.finish()` drops the writer and immediately runs another best-effort mixed `store.cleanup()` with discarded errors. GenerationLease::drop has a separate existing best-effort retirement path. These cannot be mistaken for completed controller attempts or measured work.
- Direct has its own strict journal replay and publication phases. Its API already converts only run disposal after publication/readback/full validation to pending. Direct low-level publication also performs journal/shadow/candidate cleanup, but this proposal does not relabel any of its errors.

## Selected private result types

NativeError remains the error source and public error strings retain their existing prefixes. Classification occurs at the statement's role, never by matching an error's text or errno.

```
enum ManagedJanitorStage {
    PreviousRetirementMarker,
    PublishedRunJournal,
    TerminalRunRemoval,
    RetiredGenerationRemoval,
}
struct ManagedJanitorIssue { stage: ManagedJanitorStage, source: NativeError }
struct ManagedJanitorReport {
    legacy: ManagedCleanupReport,
    pending: bool,
    observation_complete: bool,
    first_issue: Option<ManagedJanitorIssue>,
}
struct ManagedReconciliation {
    recovery: ManagedRecoveryReport,
    janitor: ManagedJanitorReport,
}
struct ManagedRecoveryReport {
    publishing_recovered: usize,
    skipped_locked: usize,
    observation_complete: bool,
}
struct ManagedPublication {
    generation_id: String,
    janitor: ManagedJanitorReport,
}
```

Keep at most one original error plus fixed counters/flags, not a Vec of paths/errors or a new retained reference union. No report is an authority, epoch seal, deletion permit, or reusable proof after locks release. The later S3 adapter must reserve its retained diagnostic encoding from the one CleanupMemory account before copying it into a cached summary. It must not format an unbounded error while holding mutation authority.

Exact proposed entry points:

```
ManagedWriteSession::publish_with_stats_typed<S: GenerationStats>(&mut self, &S)
    -> Result<ManagedPublication, NativeError>;
ManagedWriteSession::reconcile_typed(&self)
    -> Result<ManagedReconciliation, NativeError>;
ManagedStore::cleanup_typed(&self)
    -> Result<ManagedReconciliation, NativeError>;
ManagedStore::cleanup_with_owned_writer_typed(&self, writer: &WriterLease)
    -> Result<ManagedReconciliation, NativeError>;
```

`cleanup_with_owned_writer_typed` remains a private ManagedStore helper, called only by the same store/session's internally acquired writer path. It must not become an exported method that accepts an arbitrary lease as destination proof. The actual controller later uses S2's accepted destination-bound capability, not this legacy helper.

All `Err` values from these typed operations are transaction/recovery/required-validation failures. Janitor failure is represented ONLY in the successful result's nested janitor report after the corresponding transaction disposition is established. Existing `publish_with_stats -> Result<String, NativeError>`, `cleanup -> Result<ManagedCleanupReport, NativeError>` and `recover_and_gc -> Result<ManagedCleanupReport, NativeError>` remain strict compatibility wrappers until their individual callers are deliberately migrated. `cleanup`/`recover_and_gc` flatten a nested janitor issue back to its original NativeError, preserving current reader/low-level error behavior; they never become catch-all best-effort calls.

The publication compatibility wrapper stores its nested janitor report in the session for audited callers to take after verification. The public materialization path migrates to the typed publication result directly. Unmigrated low-level callers keep their existing behavior and do not acquire the new public-result guarantee merely by ignoring that stored report; audit them before removing the compatibility wrapper. These are temporary migration boundaries, not alternative authority or a way to bypass the new controller.

## Exact internal split and error roles

Refactor `finish_run_locked` into a transaction decision helper and an optional cleanup helper. Their tiny per-run decision value is private to the owning writer/state-lock scope. It is consumed immediately, cannot escape or be serialized, and cannot replace S2's required seal/grant or S3 origin proof.

`finish_run_transaction_locked` may validate journal identities, compare the active/base/candidate generations, validate a required READY bundle, promote a valid staged bundle and publish/sync the active pointer. It performs no run unlink, generation deletion, retirement marker or postcommit Published-journal write. Its result distinguishes committed-active, newly activated and explicitly obsolete/rejected run state. Uncertain state is Err, not a terminal decision. In particular, the current `is_ready_generation_valid(...).is_ok()` style must not turn I/O/corrupt required publishing evidence into permission to collect it: required Publishing/Published evidence uses fallible validation and preserves errors. Missing/ambiguous required candidates remain recovery errors and retain their journal/evidence.

`finish_run_janitor_locked` receives only that immediate resolved decision under the same actual writer/state ownership and performs the already-supported retirement marker and confined cleanup steps. Each failure is recorded by its JanitorStage. It cannot promote/activate a generation, decode a recovery journal to infer authority from its phase name, or repair an unknown publication.

A single run enumeration folds transaction results and the first janitor issue. A janitor failure does NOT terminate required recovery discovery: continue the transaction-only parts for remaining runs, deferring further optional cleanup if necessary. Any later journal/validation/publication error still returns Err as the primary recovery failure. Do not return a successful whole-store janitor report after abandoning unvisited transaction evidence. If enumeration itself fails, it is a recovery observation failure. No unbounded list or second full tree retention is introduced.

Preserve the existing benign NotFound disappearance transitions only at their current established observation points. Busy live run leases and optional epoch/control failures retain their existing conservative deferred behavior and explicit incompleteness. They do not manufacture `recovery_complete`, successful pass metrics or zero measurements. An actually attempted required replay error remains Err. The typed report makes deferred/no-attempt distinct from a completed recovery pass.

Specific classification:

| Operation/failure | Result |
| --- | --- |
| Scope/binding/writer/required state lock failure | Err; no janitor conversion |
| Invalid/corrupt required run journal or required candidate/active evidence | Err; retain evidence |
| Generation promotion, metadata/READY publication, active-pointer atomic write or required sync | Err; retain ambiguous publication evidence |
| Already committed pointer is readable but the actual transaction write/sync returned Err | Err/unknown transaction; a readback boolean alone does not reclassify it |
| Retirement marker after successful transaction boundary | nested pending issue |
| Published-run journal finalization after committed transaction | nested pending issue |
| Confined terminal-run or retired-generation disposal after resolved transaction | nested pending issue |
| Later required replay fails after an earlier janitor issue | replay Err stays primary; janitor issue may be appended as a secondary diagnostic |

`activate_published_generation_locked` returns after mandatory pointer/root synchronization; move previous-generation retirement to the janitor helper. Remove the generic `publication_is_committed().unwrap_or(false)` success fallback. A typed committed outcome must be produced by the actual successful transaction path, or by an explicit validated recovery branch, never by suppressing an arbitrary error. This preserves the approved distinction between an already committed graph and uncertain publication; it does not add a new durability protocol.

For an ambiguous error after Publishing, session/run Drop must retain the recovery evidence rather than relabel/delete it as an ordinary aborted build. Add the narrowly scoped production operation `RunWorkspace::retain_for_recovery(self)` that marks the in-memory owner finished and releases its actual run lease/reference-use guard without a journal rewrite or recursive deletion. Normal reference/use-guard release protocols still execute and must be verified with S2; no guard or worker is forgotten. This is not `mem::forget` and leaves no worker/lease escape. It preserves the exact durable journal that recovery must interpret. Prepublication failures retain existing abort/secondary-cleanup behavior.

## API application boundary

`finalize_materialization` keeps this order:

1. Call typed publication; propagate every transaction error with the current `failed to publish managed graph generation` prefix.
2. Reopen actual active generation, compare to the requested generation, read manifest, execute the current complete `validate_candidate_bundle` checks. Any failure remains the primary operation error; do not set success fields or convert it to maintenance pending.
3. Only after that succeeds, consume the publication janitor report and the typed reconciliation outcome. If reconciliation observed a real required transaction error, preserve the current `failed to reconcile managed storage cleanup` primary-error prefix. If it changed active identity, fail the existing generation-identity check rather than returning the old generation as current.
4. Nested janitor issues become `cleanup_pending=true`, additive maintenance pending/reasons/errors, and `cleanup pending:` diagnostics. Set `storage_format`, active generation and all existing native response fields as before. Unknown observation/attempt values remain unknown; no fake enqueue or measurement.
5. Release all session/writer/run/read guards before the future scheduler completion hook. Do not run a hidden second mixed cleanup from `session.finish()` in the migrated path. A private `finish_without_cleanup(self)` only releases actual producer ownership; the controller owns subsequent opportunities. Existing strict finish behavior remains for unmigrated low-level callers until they are audited and transferred.

Legacy `pending_runs` remains the count of proven pending/locked runs, never a fabricated 1 for a generation problem. A known failed run disposal contributes that exact run once. When a partial observation cannot produce the complete count, preserve known lower-bound counters and mark observation incomplete with a concrete reason in the additive maintenance summary; do not claim a coherent exact inventory. Byte buckets and unknown attempt counts remain null. This is an additive explanation of a newly successful postcommit-pending outcome, not a schema/type change to the legacy usize field.

Direct publication, journal replay and committed-read errors stay strict. Reuse the existing Direct postvalidation workspace-disposal pending test as a compatibility oracle. Do not expand Direct error suppression while implementing the Managed split. A later Direct transaction/janitor refactor needs its own source-backed scope.

## Integration boundary and scheduling dependency

This slice defines truthful results and separates effects by role; it does not qualify existing unbounded legacy cleanup as mutation-budget compliant. Do not connect the scheduler to `cleanup_typed`/`recover_and_gc` as if they were bounded callbacks. S3 must consume only prepared fixed mutation frames under accepted S2 admission and fresh MutationGrant. Long recovery preparation, validation and diagnostics disposal remain outside authority; required recovery is requested through the existing real admitted execution path and re-prepared afterward. Until the exact S2/S3 controller contract is accepted, no new full-controller effect path is wired or fake health outcome emitted.

The independent deliverable can land the typed internal split, strict wrappers, evidence-preserving error branch and the narrow native postverification report application once Max approves it. Keep one enumeration and the existing transaction/cleanup protocols, and run all old storage/recovery/convergence tests. The intentional ordering change is continuation of required transaction decisions after the first optional janitor issue, while deferring further optional work; no extra sweep, new recursive collector or retry loop is authorized. Full RAB-9/DC-S4 still requires actual startup/completion/noop/failure/cancel triggers, fresh mutation admission, confirmation consumption, cached health, transient drain/fairness and real reporting integration after controller readiness.

## Exact ownership requests before any edits

- Request S4 exclusive writer transfer: `src/storage/managed.rs` (typed results, internal split, session lifecycle) and `src/api/materialization.rs` (strict verification/report mapping and inline real-pipeline tests).
- Request narrow `src/storage/run_workspace.rs` ownership for `retain_for_recovery` plus its inline regression only. Coordinate with S2's reference-lifetime work and S3's origin/journal ownership; do not change formats or ownership claims.
- `src/storage/direct.rs`: read-only for this slice. Request no write ownership; preserve existing behavior and execute its current regressions.
- `src/api/core.rs`: read-only. No change is needed to forward the existing native materialization response; cached health/controller wiring is a separate later owned slice.
- `src/api/context.rs`: read-only for this slice. Its strict cleanup wrapper/error semantics remain unchanged until the resolver/controller handoff is separately reviewed.
- `src/storage/test_harness.rs` remains root/S5-owned; existing tests are executed unchanged. New focused store tests belong inline in managed.rs/run_workspace.rs, and native behavior tests inline in materialization.rs. No manifests, module exports, lifecycle v4 files, wiki/Scryer/Git/Linear writes.

## Required verification

- Before-control: injected real postcommit retirement/run-removal error makes the current Managed pipeline fail; after split, exact same committed/readable graph succeeds with truthful pending diagnostics only after full manifest/count/search/artifact verification.
- Negative controls: publish/pointer/sync error, invalid journal, unresolved containment/required replay, generation mismatch, malformed manifest, missing artifact, wrong counts and search checksum failure remain primary errors. Preserve the original primary message when secondary abort/cleanup also fails. Include an atomic write that reports failure despite a readable pointer; it must not become a janitor success.
- Mixed loop: first run's janitor fails, later run's required replay fails; returned primary error is the replay failure. No successful `recovery_complete` is reported after early enumeration failure. Busy/deferred is distinct from attempted failure.
- Ambiguous Publishing failure: byte-identical durable run journal/candidate/active evidence survives session Drop; actual leases are released, replay succeeds after the injected fault is removed, and unrelated PID/foreign/symlink evidence is preserved.
- Postverification: partial counts remain explicitly incomplete; legacy cleanup_pending/pending_runs and existing JSON/block output stay compatible; old serialized responses still parse; Direct committed-run cleanup behavior is unchanged.
- Execute all existing managed publishing-crash boundaries, stale-base, reader lease/retirement, last-reader Drop, prepublication abort, Direct replay and managed ten-update/convergence tests. Actual native graph/search/context equivalence is required for public result claims; synthetic storage bytes establish only storage behavior.
- Record exact baseline + bounded owned overlays, immutable before/after inputs, visible root compilation, actual binaries/test inventory and JUnit. Fresh separate Max implementation review and focused fix verification remain completion gates. Supported-platform qualification stays distinct.

No new durable memory candidate: this is proposed, unverified work and a compatibility-sensitive technical boundary. The coordinator owns canonical evidence, stable work IDs, Scryer claims and closure.
