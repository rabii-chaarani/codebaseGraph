# Factual qualification — S3 serializer feature context

2026-10-21, GPT-6.1 Sol / Max, read-only follow-up. This addendum qualifies the prior review without modifying it. Original /private/tmp/cleanup-v2-proposal-review-Ox0SyW/s3_mechanism_review.md remains SHA-256 58e5d1a207da3164e68355d1c0389a9f8a2356e9cee02a23bbff1f9ae0f18ea5.

**Correction:** the previous workspace-level preserve_order/indexmap premise does not describe the actual root runtime. The executed Darwin dependency tree separates two resolver contexts: tree-sitter's BUILD dependency has preserve_order/indexmap; codebase-graph plus lbug RUNTIME has serde_json1.0.150 default+std only. Current runtime serde_json::Value metadata maps therefore use BTreeMap and emit sorted keys. Do not reuse the earlier insertion-order assumption.

Evidence read:
- /private/tmp/dc-s3-validation-163-52v4h92k/serde-json-features.txt, SHA-256 1a13ef988bcd11e7d2a03445ead6e884f0ac00886547afd967ea905d2ff31bdf.
- Its executed JUnit f92627f13254dbeb3b026662c68d01f8fb61bbafca84594a6e5b9fb5288b71a0 reports the preserved-order assertion failing with both serializations emitting metadata a,z. The initial selected run has76 passes and1 failure; it is not a passing qualification.
- nextest-run.log, SHA-256 de62dd3696c5955bb7ca787b47aca6ad12b670046c7fc59afdcb6d1b94d5c2b9, records the passing pinned numeric oracle producing0.9966544878724392, bits3fefe497f3da5c33. The previously labelled source model is now corroborated by actual Rust execution in that captured build.

**Corrected selected condition:** future LoaderUsable/ProducedUsable must use the actual compiled runtime map mode and pinned scalar oracle. Under the current default BTreeMap mode, strict producer-form usability requires exact decoded metadata-key uniqueness and sorted-key facts; under a separately verified preserve_order runtime policy, emitted insertion order may be retained. Bind the witness policy to that runtime behavior. Cargo.lock or whole-workspace metadata is insufficient. Do not change dependency features, sort/rewrite source bytes or silently generalize unsupported historical forms.

The independent metadata_keys_sorted fact is appropriate. This qualification does not independently review its implementation or claim its corrected tests passed. The original pure facts/join/codec/reducer clearance remains; no production receipt, LoaderUsable constructor, restoration, staged write or deletion authority is added.

No Cargo or source/model/wiki/Git/ticket changes. Only this separate scratch addendum was written. Memory assessment: no false feature premise was recorded in repository memory; no quarantine is needed. The resolver-context lesson is suitable for coordinator reconciliation after the accepted execution evidence is linked; this read-only review does not create memory or delivery records.

