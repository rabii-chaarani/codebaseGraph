#[path="/private/tmp/cleanup-s4-v5-uaqomoyh/src/storage/maintenance_budget.rs"] mod maintenance_budget;
#[path="/private/tmp/cleanup-s4-v5-uaqomoyh/src/storage/maintenance_scheduler.rs"] mod maintenance_scheduler;
use std::alloc::{GlobalAlloc,Layout,System};
use std::cell::UnsafeCell;
use std::sync::atomic::{AtomicBool,AtomicUsize,Ordering};
use maintenance_budget::{CleanupMemory,MutationGrant};
use maintenance_scheduler::*;
#[derive(Copy,Clone)] struct Entry { ptr:usize, size:usize, align:usize, live:bool }
const EMPTY:Entry=Entry{ptr:0,size:0,align:0,live:false};
struct Record(UnsafeCell<[Entry;128]>);
unsafe impl Sync for Record {}
static RECORD:Record=Record(UnsafeCell::new([EMPTY;128]));
static LOCK:AtomicBool=AtomicBool::new(false);
static TRACK:AtomicBool=AtomicBool::new(false);
static LIVE:AtomicUsize=AtomicUsize::new(0);
static PEAK:AtomicUsize=AtomicUsize::new(0);
static COUNT:AtomicUsize=AtomicUsize::new(0);
static PREPARED:AtomicBool=AtomicBool::new(false);
fn lock(){while LOCK.compare_exchange(false,true,Ordering::Acquire,Ordering::Relaxed).is_err(){std::hint::spin_loop();}}
unsafe fn note_alloc(p:*mut u8,l:Layout){
 if p.is_null()||!TRACK.load(Ordering::Relaxed){return}
 lock(); let i=COUNT.fetch_add(1,Ordering::Relaxed);
 if i<128 {(*RECORD.0.get())[i]=Entry{ptr:p as usize,size:l.size(),align:l.align(),live:true};}
 let live=LIVE.fetch_add(l.size(),Ordering::Relaxed)+l.size(); PEAK.fetch_max(live,Ordering::Relaxed);
 LOCK.store(false,Ordering::Release);
}
unsafe fn note_dealloc(p:*mut u8){
 lock();for e in (*RECORD.0.get()).iter_mut(){if e.live&&e.ptr==p as usize {e.live=false;LIVE.fetch_sub(e.size,Ordering::Relaxed);break;}}
 LOCK.store(false,Ordering::Release);
}
struct Allocator;
unsafe impl GlobalAlloc for Allocator {
 unsafe fn alloc(&self,l:Layout)->*mut u8{let p=System.alloc(l);note_alloc(p,l);p}
 unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8{let p=System.alloc_zeroed(l);note_alloc(p,l);p}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){note_dealloc(p);System.dealloc(p,l);}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {let q=System.realloc(p,l,n);if !q.is_null(){note_dealloc(p);note_alloc(q,Layout::from_size_align_unchecked(n,l.align()));}q}
}
#[global_allocator] static ALLOC:Allocator=Allocator;
struct Admission;
impl MaintenanceAdmission for Admission {type Permit=();fn try_acquire(&self)->Option<()>{Some(())}fn stop_admission(&self){}}
struct Driver;
impl MaintenanceDriver for Driver {
 type Work=();
 fn prepare(&mut self,_:TargetBinding,_:&Cancellation<'_>,_:&CleanupMemory)->Result<Option<()>,DriverError>{PREPARED.store(true,Ordering::Release);Ok(None)}
 fn mutate(&mut self,_:&(),_:&mut MutationGrant,_:bool)->Result<AttemptOutcome,DriverError>{unreachable!()}
}

fn reset() {
 assert_eq!(LIVE.load(Ordering::Relaxed), 0);
 lock(); unsafe { *RECORD.0.get() = [EMPTY;128]; } LOCK.store(false,Ordering::Release);
 COUNT.store(0,Ordering::Relaxed); PEAK.store(0,Ordering::Relaxed);
 PREPARED.store(false,Ordering::Release);
}
fn measure<F>(limit:usize, factory:F)->(usize,usize,usize)
where F:Copy+FnOnce(&CleanupMemory)->Result<Driver,DriverError>+Send+'static {
 reset();
 let memory=CleanupMemory::new(limit).unwrap(); let floor=memory.used();
 TRACK.store(true,Ordering::Relaxed);
 let mut runtime=MaintenanceRuntime::start(memory.clone(),TargetBinding([1;32]),Admission,factory).unwrap();
 while !PREPARED.load(Ordering::Acquire){std::thread::yield_now();}
 let charge=memory.used()-floor;
 runtime.stop_and_join(); drop(runtime);
 TRACK.store(false,Ordering::Relaxed);
 let peak=PEAK.load(Ordering::Relaxed);
 assert!(COUNT.load(Ordering::Relaxed)<128,"allocation recorder overflow");
 assert_eq!(LIVE.load(Ordering::Relaxed),0);
 assert!(peak+262144<=charge,"unreserved requested allocation: heap={peak}, stack=262144, charge={charge}");
 (floor,charge,peak)
}
fn check<F>(factory:F)
where F:Copy+FnOnce(&CleanupMemory)->Result<Driver,DriverError>+Send+'static {
 let (floor,charge,peak)=measure(1024*1024,factory);
 let (_,tight,tight_peak)=measure(floor+charge,factory);
 assert_eq!(tight,charge);
 reset(); let memory=CleanupMemory::new(floor+charge-1).unwrap();
 TRACK.store(true,Ordering::Relaxed);
 let rejected=MaintenanceRuntime::start(memory.clone(),TargetBinding([1;32]),Admission,factory);
 TRACK.store(false,Ordering::Relaxed);
 assert!(matches!(rejected,Err(StartError::ResourceLimit(_))));
 assert_eq!(COUNT.load(Ordering::Relaxed),0,"tight rejection allocated before reserve");
 assert_eq!(memory.used(),floor);
 println!("charge={charge} heap_peak={peak} tight_peak={tight_peak} stack=262144; exact ceiling passed, one-byte-under rejected before allocation");
}
#[derive(Clone,Copy)]
#[repr(align(4096))]
struct Aligned([u8;1]);
impl Aligned { fn value(self)->u8 { self.0[0] } }
fn main(){
 let _caller_thread=std::thread::current();
 check(|_|Ok(Driver));
 let captured=Aligned([7]);
 check(move |_| {assert_eq!(captured.value(),7);Ok(Driver)});
}
