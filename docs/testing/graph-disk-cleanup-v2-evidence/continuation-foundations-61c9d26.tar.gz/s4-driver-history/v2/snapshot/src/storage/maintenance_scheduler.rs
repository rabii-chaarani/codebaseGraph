//! Joined advisory-driver foundation. This module performs no storage collection.
//! Drivers must reserve every dynamic allocation from the supplied lifetime account.
use super::maintenance_budget::{CleanupMemory, MemoryReservation, MutationGrant, ResourceLimit};
use std::alloc::Layout;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::{Arc, Condvar, Mutex};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

const DEFAULT_INTERVAL: Duration = Duration::from_secs(60);
const THREAD_STACK: usize = 256 * 1024;

/// Validated opaque target identity; paths/proofs belong to the accounted driver.
/// Equality must include the installation and physical destination incarnation.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct TargetBinding(pub(crate) [u8; 32]);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum DriverError {
    ResourceLimit,
    Preparation,
    Mutation,
    Panicked,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum AttemptOutcome {
    Complete,
    Pending,
    Deferred,
    Cancelled,
    Failed(DriverError),
}

/// Fixed-size control evidence, deliberately distinct from measured storage health.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct DriverSnapshot {
    pub(crate) binding: TargetBinding,
    pub(crate) generation: u64,
    pub(crate) requested: bool,
    pub(crate) pending: bool,
    pub(crate) running: bool,
    pub(crate) liveness: DriverLiveness,
    pub(crate) last_attempt: Option<AttemptRecord>,
    pub(crate) failure: Option<DriverError>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct AttemptRecord {
    pub(crate) binding: TargetBinding,
    pub(crate) generation: u64,
    pub(crate) request_sequence: u64,
    pub(crate) triggers: u8,
    pub(crate) outcome: AttemptOutcome,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum DriverLiveness {
    Running,
    Stopping,
    Stopped,
    Failed,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum RequestDisposition {
    Enqueued,
    UnboundConfirmation,
    Stopped,
    Failed,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Trigger {
    Startup = 1,
    Completion = 2,
    Health = 4,
    Continuation = 8,
}

/// Only this interface may acquire the existing actual dispatcher slot. Its permit
/// must release admission on Drop and cannot contain any advisory/bulk work.
pub(crate) trait MaintenanceAdmission: Send + Sync + 'static {
    type Permit;
    fn try_acquire(&self) -> Option<Self::Permit>;
    fn stop_admission(&self);
}

/// Constructed on the dedicated thread; neither Driver nor Work need Send/Sync.
/// Work must own no storage authority, and Drop must perform no filesystem effects.
/// mutate only immutably borrows bulk Work; no bulk ownership may be moved into
/// the callback or destroyed there (including driver-held buffers).
/// Storage admission and all authority stay within
/// mutate, and only fixed, bounded hot frames may be consumed by inner callbacks.
pub(crate) trait MaintenanceDriver {
    type Work;
    fn prepare(
        &mut self,
        binding: TargetBinding,
        cancellation: &Cancellation<'_>,
        memory: &CleanupMemory,
    ) -> Result<Option<Self::Work>, DriverError>;
    fn mutate(
        &mut self,
        work: &Self::Work,
        grant: &mut MutationGrant,
        confirmation: bool,
    ) -> Result<AttemptOutcome, DriverError>;
}

/// Pure coalescing clock state. New requests never slide an existing due time.
struct MaintenanceScheduler {
    interval: Duration,
    next_due: Duration,
    pending: u8,
    sequence: u64,
}
impl MaintenanceScheduler {
    fn new(interval: Duration) -> Self {
        Self {
            interval,
            next_due: Duration::ZERO,
            pending: Trigger::Startup as u8,
            sequence: 0,
        }
    }
    fn request(&mut self, trigger: Trigger) {
        self.pending |= trigger as u8;
        self.sequence = self.sequence.saturating_add(1);
    }
    fn begin(&mut self, now: Duration) -> Option<(u8, u64)> {
        if now < self.next_due {
            return None;
        }
        let triggers = std::mem::take(&mut self.pending);
        self.next_due = now.saturating_add(self.interval);
        Some((triggers, self.sequence))
    }
    fn complete(&mut self, now: Duration, outcome: AttemptOutcome) {
        // Cooldown starts after actual work/disposal, not after preparation start.
        self.next_due = now.saturating_add(self.interval);
        if outcome != AttemptOutcome::Complete {
            self.pending |= Trigger::Continuation as u8;
        }
    }
}

struct Control {
    binding: TargetBinding,
    generation: u64,
    confirmation: bool,
    stopping: bool,
    scheduler: MaintenanceScheduler,
    snapshot: DriverSnapshot,
}

struct Shared<A> {
    control: Mutex<Control>,
    wake: Condvar,
    admission: A,
    memory: CleanupMemory,
    // Retains runtime/control/closure/explicit stack layout charge through join
    // and all driver/work disposal. This is requested-layout accounting, not RSS.
    _reservation: MemoryReservation,
}

pub(crate) struct Cancellation<'a> {
    check: &'a dyn Fn() -> bool,
}
impl Cancellation<'_> {
    pub(crate) fn is_cancelled(&self) -> bool {
        (self.check)()
    }
}

/// Clone owns only bounded control state. It never owns Runtime, API or refresh.
pub(crate) struct MaintenanceHandle<A> {
    shared: Arc<Shared<A>>,
}
impl<A> Clone for MaintenanceHandle<A> {
    fn clone(&self) -> Self {
        Self {
            shared: Arc::clone(&self.shared),
        }
    }
}
impl<A> MaintenanceHandle<A> {
    pub(crate) fn snapshot(&self) -> DriverSnapshot {
        self.shared
            .control
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .snapshot
    }
    /// Confirmation: busy/preparation-error retains the exact current demand;
    /// the post-permit gate takes it once, including callback error/panic or an
    /// expired grant. Rebind/stop/failure discard it. A new in-flight demand stays
    /// pending for a later gate. False never creates or clears confirmation.
    pub(crate) fn request(
        &self,
        trigger: Trigger,
        confirmation: Option<TargetBinding>,
    ) -> RequestDisposition {
        let mut control = self
            .shared
            .control
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        if control.snapshot.liveness == DriverLiveness::Failed {
            return RequestDisposition::Failed;
        }
        if control.stopping {
            return RequestDisposition::Stopped;
        }
        if confirmation.is_some_and(|binding| binding != control.binding) {
            return RequestDisposition::UnboundConfirmation;
        }
        control.confirmation |= confirmation.is_some();
        control.scheduler.request(trigger);
        control.snapshot.requested = true;
        control.snapshot.pending = true;
        self.shared.wake.notify_one();
        RequestDisposition::Enqueued
    }
    pub(crate) fn rebind(&self, binding: TargetBinding) -> RequestDisposition {
        let mut control = self
            .shared
            .control
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        if control.snapshot.liveness == DriverLiveness::Failed {
            return RequestDisposition::Failed;
        }
        if control.stopping {
            return RequestDisposition::Stopped;
        }
        if binding != control.binding {
            let Some(generation) = control.generation.checked_add(1) else {
                control.stopping = true;
                control.snapshot.liveness = DriverLiveness::Failed;
                self.shared.wake.notify_one();
                return RequestDisposition::Failed;
            };
            control.binding = binding;
            control.generation = generation;
            control.confirmation = false;
            control.snapshot.binding = binding;
            control.snapshot.generation = generation;
            // Old evidence keeps its old binding/generation; never relabel it.
            control.scheduler.request(Trigger::Startup);
            control.snapshot.pending = true;
        }
        self.shared.wake.notify_one();
        RequestDisposition::Enqueued
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum StartError {
    ResourceLimit(ResourceLimit),
    SpawnFailed,
}

/// Unique owner of the join handle. Never cloned or captured by its own worker.
pub(crate) struct MaintenanceRuntime<A: MaintenanceAdmission> {
    handle: MaintenanceHandle<A>,
    thread: Option<JoinHandle<()>>,
}
impl<A: MaintenanceAdmission> MaintenanceRuntime<A> {
    /// The caller creates ONE account before any dynamic binding/factory data.
    /// Captured owned buffers must already retain reservations on this account;
    /// external infrastructure (dispatcher/fixture channels) is not cleanup data.
    /// Driver allocations must use this same account; it is never replaced.
    pub(crate) fn start<D, F>(
        memory: CleanupMemory,
        binding: TargetBinding,
        admission: A,
        factory: F,
    ) -> Result<Self, StartError>
    where
        D: MaintenanceDriver,
        F: FnOnce(&CleanupMemory) -> Result<D, DriverError> + Send + 'static,
    {
        Self::start_with_interval(memory, binding, admission, factory, DEFAULT_INTERVAL)
    }

    fn start_with_interval<D, F>(
        memory: CleanupMemory,
        binding: TargetBinding,
        admission: A,
        factory: F,
        interval: Duration,
    ) -> Result<Self, StartError>
    where
        D: MaintenanceDriver,
        F: FnOnce(&CleanupMemory) -> Result<D, DriverError> + Send + 'static,
    {
        // The account predates every control allocation. Fixed copy snapshots
        // avoid an uncharged protocol DTO clone on health's request thread.
        let arc_layout = Layout::new::<[usize; 2]>()
            .extend(Layout::new::<Shared<A>>())
            .map_err(|_| StartError::ResourceLimit(ResourceLimit::ArithmeticOverflow))?
            .0
            .pad_to_align();
        let charge = arc_layout
            .size()
            .checked_add(THREAD_STACK)
            .and_then(|n| n.checked_add(std::mem::size_of::<F>()))
            .and_then(|n| n.checked_add(std::mem::size_of::<D>()))
            .and_then(|n| n.checked_add(std::mem::size_of::<Arc<Shared<A>>>()))
            .and_then(|n| n.checked_add(std::mem::size_of::<Self>()))
            .ok_or(StartError::ResourceLimit(ResourceLimit::ArithmeticOverflow))?;
        let reservation = memory.reserve(charge).map_err(StartError::ResourceLimit)?;
        let shared = Arc::new(Shared {
            control: Mutex::new(Control {
                binding,
                generation: 0,
                confirmation: false,
                stopping: false,
                scheduler: MaintenanceScheduler::new(interval),
                snapshot: DriverSnapshot {
                    binding,
                    generation: 0,
                    requested: false,
                    pending: true,
                    running: false,
                    liveness: DriverLiveness::Running,
                    last_attempt: None,
                    failure: None,
                },
            }),
            wake: Condvar::new(),
            admission,
            memory,
            _reservation: reservation,
        });
        let worker = Arc::clone(&shared);
        let thread = thread::Builder::new()
            .name("graph-maintenance".into())
            .stack_size(THREAD_STACK)
            .spawn(move || {
                let result = catch_unwind(AssertUnwindSafe(|| match factory(&worker.memory) {
                    Ok(mut driver) => run_driver(&worker, &mut driver),
                    Err(error) => fail_worker(&worker, error),
                }));
                if result.is_err() {
                    fail_worker(&worker, DriverError::Panicked);
                }
            })
            .map_err(|_| StartError::SpawnFailed)?;
        Ok(Self {
            handle: MaintenanceHandle { shared },
            thread: Some(thread),
        })
    }

    pub(crate) fn handle(&self) -> MaintenanceHandle<A> {
        self.handle.clone()
    }

    pub(crate) fn request_stop(&self) {
        // Dispatcher lock order never overlaps the mailbox. Stop winning either
        // actual admission or the later mailbox gate prevents new storage work.
        self.handle.shared.admission.stop_admission();
        let mut control = self
            .handle
            .shared
            .control
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        control.stopping = true;
        control.confirmation = false;
        if control.snapshot.liveness != DriverLiveness::Failed {
            control.snapshot.liveness = DriverLiveness::Stopping;
        }
        self.handle.shared.wake.notify_all();
    }

    pub(crate) fn stop_and_join(&mut self) {
        self.request_stop();
        // No shared mutex (including a join-handle mutex) is held while joining.
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}
impl<A: MaintenanceAdmission> Drop for MaintenanceRuntime<A> {
    fn drop(&mut self) {
        self.stop_and_join();
    }
}

fn fail_worker<A>(shared: &Shared<A>, error: DriverError) {
    let mut control = shared.control.lock().unwrap_or_else(|e| e.into_inner());
    control.stopping = true;
    control.confirmation = false;
    control.snapshot.running = false;
    control.snapshot.pending = true;
    control.snapshot.liveness = DriverLiveness::Failed;
    control.snapshot.failure = Some(error);
    if let Some(attempt) = control.snapshot.last_attempt.as_mut() {
        attempt.outcome = AttemptOutcome::Failed(error);
    }
    shared.wake.notify_all();
}

fn run_driver<A: MaintenanceAdmission, D: MaintenanceDriver>(shared: &Shared<A>, driver: &mut D) {
    let origin = Instant::now();
    loop {
        let (binding, generation, triggers, sequence) = {
            let mut control = shared.control.lock().unwrap_or_else(|e| e.into_inner());
            loop {
                if control.stopping {
                    control.snapshot.running = false;
                    if control.snapshot.liveness != DriverLiveness::Failed {
                        control.snapshot.liveness = DriverLiveness::Stopped;
                    }
                    return;
                }
                let now = origin.elapsed();
                if let Some((triggers, sequence)) = control.scheduler.begin(now) {
                    control.snapshot.running = true;
                    break (control.binding, control.generation, triggers, sequence);
                }
                let wait = control.scheduler.next_due.saturating_sub(now);
                control = shared
                    .wake
                    .wait_timeout(control, wait)
                    .unwrap_or_else(|e| e.into_inner())
                    .0;
            }
        };
        let is_cancelled = || {
            let control = shared.control.lock().unwrap_or_else(|e| e.into_inner());
            control.stopping || control.generation != generation
        };
        let cancellation = Cancellation {
            check: &is_cancelled,
        };
        let prepared = driver.prepare(binding, &cancellation, &shared.memory);
        let mut panicked = false;
        let outcome = match prepared {
            Err(_) if cancellation.is_cancelled() => AttemptOutcome::Cancelled,
            Err(error) => AttemptOutcome::Failed(error),
            Ok(None) if cancellation.is_cancelled() => AttemptOutcome::Cancelled,
            Ok(None) => AttemptOutcome::Complete,
            Ok(Some(work)) => {
                // Bulk work lives OUTSIDE this scope and the caught callback.
                // Every success/error/unwind drops permit before work disposal.
                let result = {
                    let mut grant = MutationGrant::start();
                    match shared.admission.try_acquire() {
                        None => Ok(Ok(AttemptOutcome::Deferred)),
                        Some(_permit) => {
                            let confirmation = {
                                let mut control =
                                    shared.control.lock().unwrap_or_else(|e| e.into_inner());
                                if control.stopping
                                    || control.generation != generation
                                    || control.binding != binding
                                {
                                    None
                                } else {
                                    Some(std::mem::take(&mut control.confirmation))
                                }
                            };
                            match confirmation {
                                None => Ok(Ok(AttemptOutcome::Deferred)),
                                Some(confirmation) if grant.check().is_ok() => {
                                    catch_unwind(AssertUnwindSafe(|| {
                                        driver.mutate(&work, &mut grant, confirmation)
                                    }))
                                }
                                Some(_) => Ok(Ok(AttemptOutcome::Deferred)),
                            }
                        }
                    }
                };
                // No permit or S2 authority is live here, even on panic/Err.
                drop(work);
                match result {
                    Ok(Ok(outcome)) => outcome,
                    Ok(Err(error)) => AttemptOutcome::Failed(error),
                    Err(_) => {
                        panicked = true;
                        AttemptOutcome::Failed(DriverError::Panicked)
                    }
                }
            }
        };
        {
            let mut control = shared.control.lock().unwrap_or_else(|e| e.into_inner());
            control.snapshot.running = false;
            if control.generation == generation {
                control.snapshot.last_attempt = Some(AttemptRecord {
                    binding,
                    generation,
                    request_sequence: sequence,
                    triggers,
                    outcome,
                });
            }
            control.scheduler.complete(origin.elapsed(), outcome);
            control.snapshot.pending = control.scheduler.pending != 0;
        }
        if panicked {
            fail_worker(shared, DriverError::Panicked);
            return;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dc_scheduler_sustained_requests_do_not_slide_due_or_lose_inflight_demand() {
        let mut scheduler = MaintenanceScheduler::new(DEFAULT_INTERVAL);
        assert_eq!(scheduler.begin(Duration::ZERO), Some((1, 0)));
        for second in 1..=60 {
            scheduler.request(Trigger::Health);
            if second < 60 {
                assert!(scheduler.begin(Duration::from_secs(second)).is_none());
            }
        }
        let (bits, sequence) = scheduler.begin(Duration::from_secs(60)).unwrap();
        assert_eq!(bits, Trigger::Health as u8);
        assert_eq!(sequence, 60);
        // A request during preparation survives completion of this attempt.
        scheduler.request(Trigger::Completion);
        scheduler.complete(Duration::from_secs(61), AttemptOutcome::Complete);
        assert!(scheduler.begin(Duration::from_secs(120)).is_none());
        assert_eq!(scheduler.begin(Duration::from_secs(121)), Some((2, 61)));
    }

    #[test]
    fn dc_scheduler_idle_busy_error_and_continuation_are_paced() {
        let mut scheduler = MaintenanceScheduler::new(DEFAULT_INTERVAL);
        for (step, outcome) in [
            AttemptOutcome::Complete,
            AttemptOutcome::Deferred,
            AttemptOutcome::Failed(DriverError::Preparation),
            AttemptOutcome::Pending,
        ]
        .into_iter()
        .enumerate()
        {
            let now = Duration::from_secs(step as u64 * 60);
            assert!(scheduler.begin(now).is_some());
            scheduler.complete(now, outcome);
            assert!(scheduler.begin(now + Duration::from_secs(59)).is_none());
        }
        assert_eq!(
            scheduler.begin(Duration::from_secs(240)).unwrap().0,
            Trigger::Continuation as u8
        );
    }

    struct NoAdmission;
    impl MaintenanceAdmission for NoAdmission {
        type Permit = ();
        fn try_acquire(&self) -> Option<()> {
            Some(())
        }
        fn stop_admission(&self) {}
    }
    struct PausedDriver {
        entered: std::sync::mpsc::Sender<()>,
        release: std::sync::mpsc::Receiver<()>,
        _retained: MemoryReservation,
    }
    impl MaintenanceDriver for PausedDriver {
        type Work = ();
        fn prepare(
            &mut self,
            _: TargetBinding,
            cancellation: &Cancellation<'_>,
            _: &CleanupMemory,
        ) -> Result<Option<()>, DriverError> {
            self.entered.send(()).unwrap();
            self.release.recv().unwrap();
            assert!(cancellation.is_cancelled());
            Ok(None)
        }
        fn mutate(
            &mut self,
            _: &(),
            _: &mut MutationGrant,
            _: bool,
        ) -> Result<AttemptOutcome, DriverError> {
            unreachable!()
        }
    }

    #[test]
    fn dc_driver_one_account_covers_rebind_snapshots_and_retained_handle_lifetime() {
        let memory = CleanupMemory::new(1024 * 1024).unwrap();
        let floor = memory.used();
        let (entered, enter_rx) = std::sync::mpsc::channel();
        let (release_tx, release) = std::sync::mpsc::channel();
        let mut runtime = MaintenanceRuntime::start(
            memory.clone(),
            TargetBinding([1; 32]),
            NoAdmission,
            move |memory| {
                Ok(PausedDriver {
                    entered,
                    release,
                    _retained: memory.reserve(512).unwrap(),
                })
            },
        )
        .unwrap();
        enter_rx.recv_timeout(Duration::from_secs(5)).unwrap();
        let handle = runtime.handle();
        let used = memory.used();
        for value in 2..=100 {
            let clone = handle.clone();
            clone.rebind(TargetBinding([value; 32]));
            clone.request(Trigger::Health, None);
            assert_eq!(clone.snapshot().binding, TargetBinding([value; 32]));
            assert_eq!(memory.used(), used); // fixed-copy control, no DTO allocations
        }
        runtime.request_stop();
        release_tx.send(()).unwrap();
        runtime.stop_and_join();
        assert_eq!(memory.used(), used - 512); // driver disposed, mailbox still alive
        drop(runtime);
        assert!(memory.used() > floor); // a handle does not escape its account
        drop(handle);
        assert_eq!(memory.used(), floor);
        assert!(memory.peak() <= memory.limit());
    }

    struct ConfirmDriver {
        prepared: std::sync::mpsc::Sender<()>,
        prepare_release: std::sync::mpsc::Receiver<()>,
        mutated: std::sync::mpsc::Sender<bool>,
        mutate_release: std::sync::mpsc::Receiver<()>,
    }
    impl MaintenanceDriver for ConfirmDriver {
        type Work = ();
        fn prepare(
            &mut self,
            _: TargetBinding,
            _: &Cancellation<'_>,
            _: &CleanupMemory,
        ) -> Result<Option<()>, DriverError> {
            self.prepared.send(()).unwrap();
            self.prepare_release.recv().unwrap();
            Ok(Some(()))
        }
        fn mutate(
            &mut self,
            _: &(),
            _: &mut MutationGrant,
            confirmation: bool,
        ) -> Result<AttemptOutcome, DriverError> {
            self.mutated.send(confirmation).unwrap();
            self.mutate_release.recv().unwrap();
            Ok(AttemptOutcome::Complete)
        }
    }

    #[test]
    fn dc_driver_confirmation_arriving_inflight_survives_prior_completion() {
        let (prepared, prepare_rx) = std::sync::mpsc::channel();
        let (prepare_tx, prepare_release) = std::sync::mpsc::channel();
        let (mutated, mutate_rx) = std::sync::mpsc::channel();
        let (mutate_tx, mutate_release) = std::sync::mpsc::channel();
        let mut runtime = MaintenanceRuntime::start_with_interval(
            CleanupMemory::new(1024 * 1024).unwrap(),
            TargetBinding([1; 32]),
            NoAdmission,
            move |_| {
                Ok(ConfirmDriver {
                    prepared,
                    prepare_release,
                    mutated,
                    mutate_release,
                })
            },
            Duration::from_millis(1),
        )
        .unwrap();
        let handle = runtime.handle();
        prepare_rx.recv_timeout(Duration::from_secs(5)).unwrap();
        handle.request(Trigger::Health, Some(TargetBinding([1; 32])));
        prepare_tx.send(()).unwrap();
        assert!(mutate_rx.recv_timeout(Duration::from_secs(5)).unwrap());
        // Gate already took the first demand. New true belongs to the next gate.
        handle.request(Trigger::Health, Some(TargetBinding([1; 32])));
        handle.request(Trigger::Health, None);
        mutate_tx.send(()).unwrap();
        prepare_rx.recv_timeout(Duration::from_secs(5)).unwrap();
        assert!(handle.snapshot().pending);
        prepare_tx.send(()).unwrap();
        assert!(mutate_rx.recv_timeout(Duration::from_secs(5)).unwrap());
        runtime.request_stop();
        mutate_tx.send(()).unwrap();
        runtime.stop_and_join();
        assert_eq!(
            handle.request(Trigger::Health, Some(TargetBinding([1; 32]))),
            RequestDisposition::Stopped
        );
    }
}
