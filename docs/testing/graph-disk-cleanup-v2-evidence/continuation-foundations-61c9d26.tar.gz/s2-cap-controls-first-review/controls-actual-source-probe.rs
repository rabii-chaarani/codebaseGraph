mod storage {
 #[path = "/private/tmp/cleanup-s2-cap-controls-review-v1be53fm/repo/src/storage/maintenance_budget.rs"] pub(crate) mod maintenance_budget;
 #[path = "/private/tmp/cleanup-s2-cap-controls-review-v1be53fm/repo/src/storage/maintenance_controls.rs"] pub(crate) mod maintenance_controls;
}
