
#[cfg(test)]
mod panic_payload_probe {
    use super::*;
    struct Admission;
    impl MaintenanceAdmission for Admission {
        type Permit = ();
        fn try_acquire(&self)->Option<()> {Some(())}
        fn stop_admission(&self) {}
    }
    struct Driver;
    impl MaintenanceDriver for Driver {
        type Work=();
        fn prepare(&mut self,_:TargetBinding,_:&Cancellation<'_>,_:&CleanupMemory)->Result<Option<()>,DriverError> {unreachable!()}
        fn mutate(&mut self,_:&(),_:&mut MutationGrant,_:bool)->Result<AttemptOutcome,DriverError> {unreachable!()}
    }
    struct Payload;
    impl Drop for Payload {fn drop(&mut self){panic!("independent payload destructor panic");}}
    #[test]
    fn independent_panicking_factory_payload_publishes_terminal_failure() {
        let mut runtime=MaintenanceRuntime::start::<Driver,_>(CleanupMemory::new(1024*1024).unwrap(),TargetBinding([1;32]),Admission,|_| std::panic::panic_any(Payload)).unwrap();
        let handle=runtime.handle();
        let deadline=Instant::now()+Duration::from_secs(5);
        while !runtime.thread.as_ref().unwrap().is_finished() {assert!(Instant::now()<deadline);thread::yield_now();}
        runtime.stop_and_join();
        let observed=handle.snapshot();
        println!("after_joined_panicking_panic_payload={observed:?}");
        assert_eq!(observed.failure,Some(DriverError::Panicked));
        assert_eq!(observed.liveness,DriverLiveness::Failed);
    }
}
