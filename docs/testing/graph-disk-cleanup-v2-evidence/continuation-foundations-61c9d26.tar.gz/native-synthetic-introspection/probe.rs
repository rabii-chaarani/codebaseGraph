use codebase_graph::db_writer::{open_ladybug_database_with_limits,connect_ladybug_database};
use std::path::Path;
fn main()->Result<(),Box<dyn std::error::Error>>{
 for arg in std::env::args().skip(1){
  let db=open_ladybug_database_with_limits(Path::new(&arg),true,32*1024*1024,1)?;
  let conn=connect_ladybug_database(&db)?;
  println!("DATABASE {arg}");
  for q in ["CALL show_indexes() RETURN *","CALL table_info('Repository') RETURN *","CALL table_info('SourceRoot') RETURN *","CALL table_info('File') RETURN *","CALL table_info('Contains') RETURN *"]{
   println!("QUERY {q}");match conn.query(q){Ok(rows)=>{for row in rows{println!("{row:?}")}},Err(e)=>println!("QUERY_ERROR {e}")}
  }
 }
 Ok(())
}
