# DC-S3 concrete mechanism for the next proposal gate

Design only, 2026-10-21. Accepted facts foundation: commit 9836234. Authority: approved contract revision 0.2 and Scryer chg-6vx5tj/node-eje4rb. This is a successor to the nine-part proposal, not collector clearance. S3 owns maintenance.rs/maintenance_json.rs and the shared budget implementation; artifact_store producer hooks and any new modules need coordinator ownership assignment before implementation. No source edits, Cargo, Git/model/wiki writes or cleanup accompany this document.

## 1. Opaque proof types and shared boundaries

```rust
// All preparations own the SAME CleanupMemory account's reservations.
struct EnvelopeFacts { file: FileStamp, payload: Span, key: Key32, /* fixed spans/counts */ }
struct ProducerOrigin { /* private: actual completed creation/publication + exact stamps/hash */ }
struct LoaderUsable { /* private: schema, numeric/depth, raw-row and checksum witness */ }
struct ExpectedEntry { /* exact source stamp + path/content/language spans, no copied strings */ }
struct PreparedArtifact { origin: ProducerOrigin, usable: LoaderUsable, /* SAME E, action */ }

fn inspect_envelope(reader: &mut BudgetedSeekReader) -> Result<EnvelopeFacts, InspectionIssue>;
fn verify_raw_rows(facts: &EnvelopeFacts, source: &mut BudgetedSeekReader,
    memory: &CleanupMemory) -> Result<LoaderUsable, InspectionIssue>;
fn verify_origin(record: &OriginRecord, file: &mut BudgetedSeekReader,
    scope: &PreparedScope) -> Result<ProducerOrigin, InspectionIssue>;
fn prepare_artifact(/* target, same initial E, candidate, same account */)
    -> Preparation<PreparedArtifact>;
```

Span is a checked file offset/length plus its bound source identity; IDs/paths can exceed the memory ceiling and are compared by chunked decoded UTF8, never copied whole. Hashes accelerate association, partitioning and integrity; equality in the raw-row join and expected-entry checks uses exact decoded bytes. Bulk PreparedWork stays owned by the maintenance thread outside S2's mutation callback. Admission borrows only a fixed hot frame. No bulk object, decoder, disposal or reference traversal drops under the real dispatcher permit. The callback returns fixed outcomes; queued results never contain authority.

Preparation::NeedsRecovery identifies a genuine Publishing/replay requirement. Drop all read/preparation state and authority, request established recovery under its own real admitted execution, then discard the old E and start preparation anew. It is neither a janitor error suppression path nor a way to relabel the old reference proof.

## 2. Origin is separate from loader usability

OriginOnly means actual producer-created/published bytes bound to exact installation/root/control/directory/payload incarnations and a full byte digest. It does not establish that those bytes load. GraphEdgeRow confidence NaN/Inf can serialize as null although validate_raw_rows passes; arbitrary deep metadata can also exceed the current loader. Neither is certified usable by an origin receipt.

A distinct ProducedUsable witness may be recorded only when the producer has checked existing raw-row equality, key/partition/path consistency, every typed confidence finite, typed integer representability, and exact envelope-relative container depth against the pinned ordinary loader. It also checks that serialized metadata numbers are representable by the active serde_json feature set. The record binds the check policy/version and exact serialized digest. An origin-only or unsupported witness requires the independent bounded usable validator; it is never silently upgraded. Invalid/ambiguous complete canonical payloads remain protected. A backup restoration always requires LoaderUsable plus exact expected entry and current reference/recovery authority.

For old unreceipted artifacts, controlled quiescence alone is insufficient. Establish the exact root/destination association and historical producer schema plus source/key/partition association and cross-file coherence. A historical manifest/recovery entry supplies that association where available. Recognized historical native CSV/snapshots without a manifest may instead use complete historical schema and repository/partition association plus cross-file coherence; lack of a manifest is not an invented exclusion. Each concrete historical format needs actual source/fixture evidence before its validator ships. Merely well-formed unassociated data stays unknown. The same rule applies per leaf in run/phase/generation/Direct bundles; names or a parent journal do not own arbitrary children.

Private receipts are unsigned application evidence. They cover supported producers, ordinary foreign insertion, corruption and substituted incarnations, not a local adversary who forges every private record and recomputes its checksums.

## 3. Exact historical producer-form validation

Pinned serde_json 1.0.150 has preserve_order/indexmap in the resolved feature graph. Metadata Value object order is therefore the preserved insertion order, not arbitrary sorted order. No general canonical-Serde replacement is proposed.

Recognize the actual producer's typed field order, required fields, default omission and exact token forms. Strip only formatting whitespace outside strings while hashing the partition span. This equals the existing compact partition checksum only after those producer forms are checked. A semantically equivalent but nonproducer JSON spelling remains unknown to this migration recognizer; ordinary reads are unchanged. This is not a total-size limit.

String oracle: raw valid UTF8 is emitted directly; quote/backslash escape; slash does not; control bytes use b/f/n/r/t where applicable and lowercase u00xx for the other control values. Verify every control value 0..31, Unicode/surrogate variants, U+2028/U+2029 and boundary-chunk splits against the actual pinned serializer. Existing producer_escapes is only a conservative lexical fact and currently flags even legitimate control Unicode escapes false; it must not be reused as complete producer recognition.

Typed numeric oracle: integer fields parse checked i64/u64/usize with exact field constraints. Confidence parses finite f64, then pinned serialization into a fixed caller-reserved scalar buffer must reproduce the producer token. Value numbers use their actual pinned numeric kind and equivalent parser/serializer oracle. NaN/Inf -> null fails typed confidence usability. Very long/nonproducer numeric spellings do not allocate token-sized strings. Recognized serializer scalar lengths are established by exhaustive integer-boundary and property tests, not guessed. Lexically valid 1e999999 remains a tokenizer fact but fails usability. Container depth is measured from the full envelope and tested through the actual typed artifact loader, not merely Value parsing. Current default decrement-to-zero boundary is 127 containers; never disable the loader's recursion limit to manufacture compatibility.

Metadata objects retain their emitted order but require exact decoded key uniqueness to be producer-shaped. BTreeMap entry type maps require their real serializer order. Missing optional/default values follow the typed serializer; duplicate top-level/typed fields are nonproducer/unknown. Manifest reference projection separately preserves the existing null/object/array and path-fallback semantics, including last path wins in arrays; it is not incorrectly restricted to the artifact producer grammar.

## 4. Bounded exact raw-row join, with measurable large-file cost

No GraphPartition, Value, ID Vec or BTreeMap is decoded. Reserve a fixed table from the remaining account before allocation. Each slot is a checked fixed layout containing SHA256(ID), source ID span, raw multiplicity, declared-array multiplicity, last raw ordinal, last raw type span, declared map-value span and seen flags. All scratch, probe frames and comparisons share the same account. A separate fixed 256-bit-prefix work stack tracks adaptive binary/radix replay; it never stores IDs as strings.

For each selected hash prefix, stream the node rows, entry.node_ids and entry.node_types; perform the analogous independent edge join. Hash is only a bucket selector and lookup hint. For every occupied hash match, compare the complete decoded ID span exactly. Distinct strings with identical hashes occupy distinct slots. Count raw and declared-array occurrences with checked u64 arithmetic. Raw duplicate IDs are allowed: sorted ID vectors include their multiplicity, while type maps use the final raw row ordinal's table/edge_type. The declared arrays must be globally lexicographically sorted and every matched type-map value must equal that last raw type exactly. Verify total row counts, map membership/cardinality and partition_id(path). This reproduces validate_raw_rows, rather than replacing it with probabilistic fingerprints or requiring ID uniqueness the current code does not require.

On table overflow, discard that incomplete bucket's aggregates and split its hash prefix. Replays read immutable bound source spans; no scratch disk or external spill is introduced. Completed sibling buckets do not restart. Prefix traversal uses a fixed bitset/stack, bounded by 256; active table capacity is fixed and reuse does not retain growth. For a full-256-bit collision bucket exceeding capacity, use deterministic exact-key batches: first stream to retain the C lexicographically smallest distinct remaining IDs in the charged table, then stream once to aggregate those exact keys; advance the exact source-span lower bound to their maximum and repeat. This handles injected collisions without false equality or rejecting the whole valid payload. It costs O(N * ceil(U/C)) scans for that exceptional bucket, not one full seek scan per row. All comparisons are chunked and collision tests force this fallback.

Normal adaptive replay also has real read amplification: it is not claimed O(N) for unbounded U/C. Counters report passes, bytes read, comparisons and elapsed time. Large-payload acceptance must measure this implementation at the configured default ceiling with millions of tiny IDs, long strings, skewed prefixes, duplicate IDs and adversarial injected collisions. It must demonstrate practical validation against the ordinary decoder baseline and storage throughput; no days-long run may be labeled qualified. If measured normal replay is impractical, propose a separately origin/crash/budget-reviewed spill mechanism before full migration; do not quietly add unbudgeted scratch I/O. This explicit performance gate is preferable to claiming quadratic per-row rescans are production-ready.

## 5. Receipt crash-state table and bounded producer hooks

Record uses a fixed versioned header plus checksummed fixed frames; fields are typed role/key/nonce, exact scope/control/parent/dir/payload identities, producer phase, length/hash, check-policy and optional usable witness. Atomic record updates use create_new preparation + fsync + rename + parent fsync. A transition lists only its fixed source/backup/destination addresses, never arbitrary paths. One current receipt per live artifact incarnation and one bounded transition per in-flight write; reuse/no-op/failure does not append permanent history. Receipt cleanup is budgeted collector housekeeping. Metadata directories themselves need genuine creation binding; an unknown preexisting control directory is never adopted by name.

| Durable state / crash point | Permitted interpretation and recovery |
| --- | --- |
| Intent before create | Advisory only; does not prove a dir/file was created. Existing collisions/foreign children protected. |
| Actual temp dir/payload created, before identity binding | Unbound window remains unknown; no name/age/PID inference and no full-convergence claim for it. |
| CreationBound before first payload write | Proves exact private temp dir/payload creation and Writing phase. No usable/complete-data claim. Partial temp disposition requires exact known creation+phase, strict permitted child inventory and current complete references; malformed/ambiguous partial evidence remains protected. |
| Writing interrupted | Never canonical/backup usability. Keep live/recovery-referenced temp; collector may dispose only the genuinely bound incomplete temp after phase emptiness. Advisory hash/stamps bind its observed partial bytes at final seal; this hash is not presented as a completed expected-payload checksum. |
| Payload fsynced, before CompleteStaged | Creation origin remains; completion/usable flag not inferred from file length. Bounded independent validation may recover completion only through the actual bound producer transition. |
| CompleteStaged | Exact staged bytes/digest; usable witness separate. Not a completed canonical-publication receipt. |
| RenameIntent fsynced, old canonical still public | Records exact old/temp/backup identities before effects. No deletion yet. Recheck old canonical through FD; unknown old payload can be moved only by existing replacement protocol and is retained, not handed to recursive cleanup as owned. |
| Old canonical renamed to backup, before new canonical | Recorded old inode remains recovery evidence. Restore the exact valid referenced missing canonical first; keep invalid/ambiguous backup. |
| New canonical rename happened, before directory fsync/commit receipt | Transition recovery reconciles exact identities and fsyncs the actual publication before Published; never mint Published from intent alone. Reference/recovery proof is discarded and reprepared after recovery. |
| Rollback of failed new rename | Recorded old inode restored only to an absent expected canonical target. Rebind receipt to actual restored location; keep unresolved transition on failure. Never overwrite a substituted public name. |
| Published and parent fsynced | Mint completed publication receipt with actual canonical directory+payload identity and full digest. Old backup retains its original proof; absent proof leaves it unknown. |
| Reused current canonical | Fresh valid candidate bytes compared through FDs; current canonical path/FD identity rechecked. Receipt bound to existing incarnation only after complete equality and durability. No bool-only upgrade. |
| Receipt/stage torn | Recover only from an earlier durable record binding the preparation inode and exact expected prefix. An unbound torn receipt remains unknown. |
| Published success, later janitor failure | Primary publication remains authoritative; typed pending diagnostic. Actual transaction/replay failure remains error/NeedsRecovery, coordinated with S4. |

Producer hooks must carry the existing whole ReferenceMutation/use guard across all these transitions. They return tokens bound to actual successful create/publication syscalls, not a public constructor accepting caller-provided identities. No collector code or caller-owned staging receipt is enabled before review. Producer backup cleanup must stop recursively deleting unproven old contents; known postpublication residue passes to the bounded collector or existing proven-owned error cleanup. Stable lock inodes are outside every movable/deletable payload set.

## 6. More-than-100-leaf journal staging without starvation

```rust
struct JournalBuild { /* exact source incarnation/E, own journal inode, logical leaf cursor */ }
struct PreparedLeafFrame { /* fixed origin/stamp/address bytes; no bulk proof object */ }
struct JournalStageLease<'a> { /* opaque private-journal authority, owns SAME grant */ }
struct PreparedDetachFrame { /* fixed complete-journal stamp/root digest + source seal */ }
enum JournalStep { Staged, NeedPreparation, SourceChanged, Complete(PreparedDetachFrame) }
```

First prepare one leaf outside all authority. Under a fresh grant/private journal lease, persist its fixed frame and durable cursor; each touched create/write/rename/fsync-related entry is charged consistently with MutationGrant. Staging frames are inert advisory observations, not deletion authority. Staging touches only an explicitly separate private control namespace and does not change source references or increment the global reference epoch. It never calls canonical S2 admission just to append a frame; doing so would increment E and restart the build indefinitely. S2 must agree this private-journal-only capability before implementation. Ordinary producers still invalidate the captured source E as usual.

Immutable segment files contain a bounded number of fixed frames plus a checksum. Create_new segment and its preparation inode are durably bound in the build header before segment publication; durable monotone logical cursor identifies the last committed segment/frame. On crash, validate the bound segment and exact completed prefix, then resume. A partial unbound segment is unknown, not reclaimed by a filename guess. More than 100 leaves spans multiple fresh grants/processes. No scan of all previous frames under authority and no full rewrite per leaf. Frame/schema sizes, maximum entries per append and cursor publication cost are fixed before the first effect; too-small grants yield with no effects.

Before final detach, scan/hash the entire staged frame stream outside authority, re-enumerate exact source leaves, compare every bound origin/stamp, verify complete coverage/no unknown children and the SAME initial source E. Record complete journal stamp/root digest in one fixed prepared hot frame. Final actual destination/workspace admission verifies its opaque lifecycle/global proof plus fixed source/journal/control stamps, invalidates E only for the actual transition, durably marks Detaching and renames to a same-root private tombstone under the short state section. No frame-stream traversal happens there.

Replay reconstructs a detached proof only from matching durable journal/private incarnation. Prepare one private leaf outside authority, then consume only its exact private leaf proof/stamp in the callback and unlink under a fresh grant. Cursor/progress is durable and idempotent; expected NotFound advances only the matching prior frame. Foreign/substituted private contents protect the tombstone; no original public name fallback exists. Stable locks remain at public names. Permission failures yield without losing evidence and cursor/category rotation prevents a blocked first job from starving later work. Source mutation during build invalidates staged eligibility and triggers fair restart; it never blesses old frames with a new E. Obsolete own journal segments themselves require bounded exact-origin disposal.

## Acceptance and implementation starting slices

1. Pure facts extension: exact control-character/numeric producer-token oracles and schema span/count extraction; no origin/usability constructor. Requires coordinator scope clearance first. All actual typed loader depth/nonfinite/default/duplicate cases differential-tested.
2. Exact bounded join: differential against validate_raw_rows across random graphs, duplicate IDs/last type wins, missing/extra IDs/maps, ordering and injected digest collisions; low ceiling, huge strings and millions of IDs; measured peak requested layouts/read amplification/time. No spill files. Review independent before granting usable proof.
3. Receipt codec and state reducer: pure fixed codecs/reducer/crash-table tests first; actual producer create/rename/receipt hooks only after source ownership transfer and fresh gate. Verify every crash transition, substitution, collision, reuse and no-op-history boundedness.
4. Journal segment/cursor codec and pure restart reducer first; actual staged writes/private capability and final detach only after S2/S4 handoff review. Fresh process per grant over >100 leaves, torn own/foreign metadata, zero grant, real touched-entry counts, permission restore, stable locks, sameE invalidation and primary-error behavior.

No overall collection/migration qualification is asserted by these independent slices. Remaining prerequisites are concrete private proofs/API ownership and executed performance/crash evidence, not new user product decisions. No repository memory recorded: this proposal is unverified design input.
