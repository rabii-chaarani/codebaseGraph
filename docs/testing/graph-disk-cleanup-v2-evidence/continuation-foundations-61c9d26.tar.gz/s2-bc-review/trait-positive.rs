#[path = "/private/tmp/cleanup-s2-bc-review-rm5ezv2w/repo/src/error.rs"] mod error;
mod storage {
    #[path = "/private/tmp/cleanup-s2-bc-review-rm5ezv2w/repo/src/storage/maintenance_budget.rs"] pub(crate) mod maintenance_budget;
    #[path = "/private/tmp/cleanup-s2-bc-review-rm5ezv2w/repo/src/storage/locks.rs"] pub(crate) mod locks;
    fn requires_send_sync<T: Send + Sync>() {}
    fn assertion() {requires_send_sync::<locks::FixedFileStamp>();requires_send_sync::<locks::FixedControlScratch>();}
}
