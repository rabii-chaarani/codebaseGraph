pub struct Café { pub value: i64 }
