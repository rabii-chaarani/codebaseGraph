pub fn alpha(v: i64) -> i64 { v + 1 }
