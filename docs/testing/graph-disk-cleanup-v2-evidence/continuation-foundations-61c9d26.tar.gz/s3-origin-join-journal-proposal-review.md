# DC-S3 concrete mechanism review

Decision: PROCEED with the requested narrow pure foundations after incorporating the three selected corrections below into the execution brief. No product decision remains open. No collector, producer receipt publication, staged journal write, backup restoration, LoaderUsable constructor or deletion authority is cleared.

Reviewer: GPT-6.1 Sol / Max, read-only adversarial-proposal-review-engineer continuation, 2026-10-21. Exact proposal /private/tmp/dc-s3-origin-join-journal-mechanism-20261021.md, independently verified SHA-256 e63875a0acc346c3231411b0a1bf68ed59679e1d9f9dcc884844d3570705514b. Source scope: accepted facts9836234 plus committed wrapper7b0ad57; wrapper changes are not re-reviewed here.

## Starting clearance

Cleared: exact producer-token/schema/span/count facts, the bounded exact hash-prefix join engine, fixed receipt/transition codecs and pure state reducers, and journal segment/cursor codecs plus pure restart reducers. Keep all outputs factual/private. The raw-row engine returns RawRowsMatch, not a stand-alone LoaderUsable. Actual source ownership remains with the coordinator's assignments; no artifact_store producer hook is included.

The join is causally coherent: every bucket shares one fixed reserved table; incomplete bucket aggregates are discarded on overflow; prefix splitting makes progress up to256 bits; exact decoded ID comparison prevents digest equality becoming semantic equality. The full-hash collision fallback processes at least one new distinct exact key per completed batch when C>=1. Sorted declared ID multisets, row counts, map membership/cardinality and final raw ordinal reproduce the current validator's duplicates and last-row-wins behavior. No spill/catalog or arbitrary total-payload cutoff is needed for this foundation. Read amplification and default-ceiling large-file qualification remain real executed gates, not claims established by this review.

## S3-M1 — Apply the scalar roundtrip oracle to ProducedUsable too

Established source-level premise gap in proposal section2; minimum correction is to reuse section3's chosen oracle.

Pinned serde_json1.0.150 with float_roundtrip disabled converts a significand to f64 then multiplies/divides by POW10 (local de.rs:638–671). Finiteness, integer bounds and depth do not by themselves establish that producer bytes survive the ordinary loader's parse/re-serialize checksum. This applies to typed confidence and floating metadata Value numbers.

For ProducedUsable, run the pinned parse -> serialize -> exact-token equality oracle for every serialized numeric scalar, as already selected for independent validation. An unstable scalar leaves the receipt origin-only; do not enable float_roundtrip, alter existing payloads or upgrade an origin-only record by assertion. LoaderUsable composes schema, numeric roundtrip, depth, checksum, raw-row equality and the exact bound source stamp; a join result alone is insufficient. Restoration additionally requires the exact expected entry and current reference/recovery proof.

Concrete future Rust regression seed: f64::from_bits(0x3fefe497f3da5c34), producer candidate token0.9966544878724393. A deterministic Python model of the pinned non-roundtrip branch yielded bits0x3fefe497f3da5c33 and reserialization value0.9966544878724392. This was source-model arithmetic, NOT an executed serde_json/Rust probe; execute the pinned native differential when the Cargo lease is available.

The scalar buffer need not be guessed from property tests: pinned serde_json calls zmij1.0.21's finite formatter, whose Buffer is a24-byte array (zmij lib.rs:90, :1147–1148; ser.rs:1716–1723). Check integer output bounds from the typed widths and reserve the fixed serializer/output workspace. Tests supplement that source bound, including negative zero, extrema, subnormals, nonfinite values, overflow exponent and long nonproducer spellings.

## S3-M2 — Make all-stream coverage and source binding explicit in the pure join contract

Clarification selected for implementation, not a rejection of the algorithm.

Both normal prefix replay and full256-bit collision batching must cover raw IDs, declared-array IDs and declared map keys, or enforce equivalent total/cardinality plus per-key membership checks. No orphan declared key may disappear because selection visited raw rows only. Preserve declared duplicate multiplicities, map-key uniqueness and the final raw type for duplicate IDs. Check global lexical array/map ordering separately from hash-bucket order.

Retain the same exact source identity/stamps across every replay and span comparison. Source change invalidates the result. C=0 is ResourceLimit before a table is allocated/used; C=1 is supported. On overflow, discard only the unfinished bucket's aggregates; never double-count earlier partial passes or restart completed siblings. Use a prefix-length representation that can represent256 and test bit255 -> full-hash fallback. The fallback lower bound is an exact decoded-key span, not a digest, string prefix or truncated ID.

Required tests are finite and concrete: duplicate IDs with changing final type; duplicate multiplicities; orphan/missing declared keys; global order; all IDs under one forced prefix; full forced digest collision beyondC; empty/huge decoded strings; capacity1; source stamp change; and differential equality with validate_raw_rows. Measure actual reserved peak, passes, bytes and time before granting large-file usable/migration qualification. The proposal correctly avoids calling its normal replay O(N).

## S3-M3 — Keep source E separate from private journal progress

Clear the pure journal model with two distinct identities: immutable source epoch/incarnation E and mutable private journal generation/segment/cursor state. Stage events update only the latter. They cannot call canonical admission, increment E, refresh source eligibility or restart already committed frames merely because another metadata frame was appended.

Add reducer crash states for own epoch advancement before Detaching is durable, Detaching durable before rename, and rename before final durable commit. No state yields Detached proof without the actual matching private tombstone incarnation. If E advanced without a provable exact own transition, require re-preparation rather than relabeling the old reference proof. A durable own E->E+1 transition may be resumed only through its explicitly verified reference-preserving recovery contract.

Before actual stage writes, S2 still must accept the separate private-journal capability, namespace placement and lock. That namespace must be outside source leaf coverage and must not invalidate the source/root/absence stamps on every append. Final detach must retain the SAME private journal coordination while checking its completed stamp/seal and publishing Detaching, so an independent stage appender cannot extend it between check and transition. These are future authority integration conditions, not blockers for codecs/reducers.

Final large-tree authority must also preserve the existing unknown-child rule. The opaque workspace/local proof must cover supported source changes between complete advisory enumeration and detachment; a plain top-directory mtime is not a recursive foreign-insertion proof. If such whole-tree proof is unavailable, the later implementation must use an accepted bounded per-entry transition, leaving unknown descendants public/protected. This review does not authorize moving an unknown tree because its prior scan was complete.

## Pinned source checks and resolved earlier concerns

Inspected local primary serde_json1.0.150 and zmij1.0.21 source after locating their exact registry paths. The captured real metadata at /private/tmp/cleanup-s5-v2-qualification-kt_hoggu/capture-attempt-1/cargo-metadata.stdout resolves serde_json features default,indexmap,preserve_order,raw_value,std and excludes float_roundtrip,arbitrary_precision,unbounded_depth. This is whole-workspace metadata; final usable policy must be checked against the actual linked root unit, not inferred from an unrelated cached variant.

Pinned map.rs selects IndexMap under preserve_order. Metadata objects preserve their emitted insertion order; typed BTreeMap maps retain lexical order. Strict producer recognition requires exact decoded key uniqueness; duplicate typed/envelope fields remain nonproducer/unknown. Manifest references keep their separate null/object/array and last-path-wins rules.

Pinned ser.rs emits lowercase u00xx for non-short control escapes and the standard short escapes; raw UTF8 and ordinary slash are emitted directly. The existing producer_escapes flag explicitly treats Unicode escape forms conservatively and is not a complete producer-form proof. The proposed new exact oracle resolves that earlier limitation.

Pinned de.rs initializes128 and decrements before testing zero (:63, :1375–1377). The127-container boundary must count the full typed envelope, as proposed, and be differentially checked through the actual artifact loader. Existing raw-row source checks sorted ID arrays, maps/counts and partition_id(path); it does not reject raw duplicate IDs or validate confidence. The distinct origin-versus-usability witness now correctly separates those concerns, subject to M1.

The receipt crash table resolves the previous broad state-machine gap for pure reducer implementation: CreationBound precedes payload writes; complete/usable/publication states are distinct; old unknown backups retain unknown status; actual public FD/incarnation equality gates reuse; torn own prefixes need earlier durable inode binding; unbound creation/segment windows stay unknown and are not called fully convergent. Stable locks remain outside payload moves. Actual on-disk hooks and their syscall-cost/primary-error integration remain separate reviewed slices.

## Limits

Repository procedure renewed: memory recall, wiki bundle/search/get, explicit-checkout Scryer orientation, graph search/schema/read-only query before source reads. Configured graph has no Cargo File nodes; pinned dependency verification used the exact captured metadata supplied by the coordinator and located primary registry sources. k-wiki reader still returns the documented stale v0.1 snapshot; current approved v0.2 intent is taken from explicit approval, previously hash-verified authored contract and refreshed Scryer.

No Cargo, Rust execution, probes, benchmarks, source/model/wiki/Git/ticket mutation or live cleanup. Only scratch review output and the labelled arithmetic model were produced. No new memory candidate: the reviewed mechanisms still need implementation evidence.

