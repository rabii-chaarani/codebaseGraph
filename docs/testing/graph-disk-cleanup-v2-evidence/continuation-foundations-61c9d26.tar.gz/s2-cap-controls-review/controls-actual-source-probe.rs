mod storage {
 #[path = "/private/tmp/cleanup-s2-cap-controls-fix-review-kh0ry6yd/repo/src/storage/maintenance_budget.rs"] pub(crate) mod maintenance_budget;
 #[path = "/private/tmp/cleanup-s2-cap-controls-fix-review-kh0ry6yd/repo/src/storage/maintenance_controls.rs"] pub(crate) mod maintenance_controls;
}
