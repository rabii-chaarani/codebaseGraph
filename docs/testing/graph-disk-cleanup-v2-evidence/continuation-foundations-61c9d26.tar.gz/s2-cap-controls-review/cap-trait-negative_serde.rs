#[path = "/private/tmp/cleanup-s2-cap-controls-fix-review-kh0ry6yd/repo/src/error.rs"] mod error;
mod storage {
 #[path = "/private/tmp/cleanup-s2-cap-controls-fix-review-kh0ry6yd/repo/src/storage/maintenance_budget.rs"] pub(crate) mod maintenance_budget;
 #[path = "/private/tmp/cleanup-s2-cap-controls-fix-review-kh0ry6yd/repo/src/storage/locks.rs"] pub(crate) mod locks;
}
use std::path::Path;
use storage::locks::{FileIdentity, LockedFile};
#[derive(Debug, Clone, Copy)]
struct ArtifactRootProducerBinding {
    root: FileIdentity,
    coordination: FileIdentity,
    incarnation: [u8; 32],
    cohort: FileIdentity,
}
#[derive(Debug)]
pub(crate) struct ArtifactRootProducerCapability<'a> {
    root: &'a Path,
    root_use: &'a LockedFile,
    activity: &'a LockedFile,
    binding: ArtifactRootProducerBinding,
    _not_send_sync: std::marker::PhantomData<std::rc::Rc<()>>,
}
fn requires_debug<T: std::fmt::Debug>() {}
fn requires_send_sync<T: Send + Sync>() {}
fn requires_clone<T: Clone>() {}
fn requires_serde<T: serde::Serialize + for<'de> serde::Deserialize<'de>>() {}
fn assertion() {requires_serde::<ArtifactRootProducerCapability<'static>>();}
