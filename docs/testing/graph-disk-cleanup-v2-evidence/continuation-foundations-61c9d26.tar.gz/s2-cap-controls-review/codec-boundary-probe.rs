#[path = "/private/tmp/cleanup-s2-cap-controls-fix-review-kh0ry6yd/repo/src/storage/maintenance_controls.rs"] mod controls;
use controls::*;
fn main() {
 let nonce = [31; 32];
 for len in 0..=SELECTOR_BYTES+1 {
  let bytes=vec![0;len];
  assert!(decode_slot(&bytes,&nonce).is_err());
  assert!(decode_commit(&bytes,&nonce).is_err());
  assert!(decode_intent(&bytes,&nonce).is_err());
 }
 let badc=CommitFact{generation:1,active:usize::MAX,slot_digest:[0;32]};
 let badi=IntentFact{before:u64::MAX,after:0,target:usize::MAX,slot_digest:[0;32]};
 assert_eq!(recovery_step(Some(badc),Some(badi),[None,None]),RecoveryStep::Unknown);
 let mut old=[0;SLOT_BYTES]; let mut next=[0;SLOT_BYTES]; let mut inactive=[0;SLOT_BYTES];
 let of=encode_slot(&mut old,&nonce,3,b"current").unwrap();
 let nf=encode_slot(&mut next,&nonce,4,b"next complete payload").unwrap();
 encode_slot(&mut inactive,&nonce,2,b"prior valid inactive").unwrap();
 let c=CommitFact{generation:3,active:0,slot_digest:of.digest};
 let mut cb=[0;COMMIT_BYTES];encode_commit(&mut cb,&nonce,c).unwrap();
 let mut ib=[0;INTENT_BYTES];let i=encode_intent(&mut ib,&nonce,c,&next).unwrap();
 assert_eq!(decode_commit(&cb,&[30;32]),Err(ControlFailure::Incarnation));
 assert_eq!(decode_intent(&ib,&[30;32]),Err(ControlFailure::Incarnation));
 for cut in 0..=SLOT_BYTES {
  let mut partial=inactive;partial[..cut].copy_from_slice(&next[..cut]);
  let fact=decode_slot(&partial,&nonce).ok();
  assert_eq!(recovery_step(Some(c),Some(i),[Some(of),fact]),if fact==Some(nf){RecoveryStep::CommitIntendedSlot(i)}else{RecoveryStep::RewriteIntendedSlot(i)});
 }
 let mut unchanged=[0xa5;SLOT_BYTES];let before=unchanged;
 assert_eq!(encode_slot(&mut unchanged,&nonce,5,&vec![0;PAYLOAD_BYTES+1]),Err(ControlFailure::Size));assert_eq!(unchanged,before);
 println!("boundary_lengths_checked={}; prior_valid_inactive_partial_cuts={}; wrong_commit_intent_nonce_rejected=true; invalid_facts_unknown=true; rejected_encode_preserves_bytes=true",SELECTOR_BYTES+2,SLOT_BYTES+1);
}
