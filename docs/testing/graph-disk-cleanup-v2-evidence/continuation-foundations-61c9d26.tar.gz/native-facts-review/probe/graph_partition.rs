#[derive(Debug, Clone, PartialEq, serde::Deserialize, serde::Serialize)]
pub(crate) struct GraphPartition {
    pub(crate) entry: ManifestEntry,
    pub(crate) nodes: Vec<GraphNodeRow>,
    pub(crate) edges: Vec<GraphEdgeRow>,
}

impl GraphPartition {
    pub(crate) fn set_artifact_key(&mut self, artifact_key: impl Into<String>) {
        self.entry.artifact_key = Some(artifact_key.into());
    }

    pub(crate) fn validate_raw_rows(&self) -> Result<(), String> {
        if self.entry.partition_id != hash::partition_id(&self.entry.path) {
            return Err(format!(
                "partition {} does not match path {}",
                self.entry.partition_id, self.entry.path
            ));
        }

        let mut expected_node_ids = Vec::with_capacity(self.nodes.len());
        let mut expected_edge_ids = Vec::with_capacity(self.edges.len());
        let mut expected_node_types = BTreeMap::new();
        let mut expected_edge_types = BTreeMap::new();

        for node in &self.nodes {
            expected_node_ids.push(node.id.clone());
            expected_node_types.insert(node.id.clone(), node.table.clone());
        }

        for edge in &self.edges {
            expected_edge_ids.push(edge.id.clone());
            expected_edge_types.insert(edge.id.clone(), edge.edge_type.clone());
        }

        expected_node_ids.sort();
        expected_edge_ids.sort();

        if self.entry.node_ids != expected_node_ids {
            return Err("entry node_ids do not match raw node rows".to_string());
        }
        if self.entry.edge_ids != expected_edge_ids {
            return Err("entry edge_ids do not match raw edge rows".to_string());
        }
        if self.entry.node_types != expected_node_types {
            return Err("entry node_types do not match raw node rows".to_string());
        }
        if self.entry.edge_types != expected_edge_types {
            return Err("entry edge_types do not match raw edge rows".to_string());
        }
        if self.entry.node_count != self.nodes.len() {
            return Err("entry node_count does not match raw node rows".to_string());
        }
        if self.entry.edge_count != self.edges.len() {
            return Err("entry edge_count does not match raw edge rows".to_string());
        }

        Ok(())
    }
}

