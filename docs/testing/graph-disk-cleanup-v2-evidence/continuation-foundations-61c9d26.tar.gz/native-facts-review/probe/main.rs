#![allow(dead_code)]
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_budget.rs"] mod maintenance_budget;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_json.rs"] mod maintenance_json;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_validation.rs"] mod maintenance_validation;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_native_projection.rs"] mod maintenance_native_projection;
use maintenance_budget::CleanupMemory;
use maintenance_validation::*;
use maintenance_native_projection::*;
use sha2::{Sha256,Digest};
use std::cell::Cell;
use std::cmp::Ordering;

struct Source<'a>{bytes:&'a[u8],length:u64,chunk:usize,stop:usize,error:bool,calls:Cell<usize>}
impl ByteSource for Source<'_>{
    fn len(&self)->u64{self.length}
    fn read_at(&self,offset:u64,out:&mut[u8])->Result<usize,ValidationIssue>{
        self.calls.set(self.calls.get()+1);
        if self.error&&offset>=256{return Err(ValidationIssue::Io(std::io::ErrorKind::PermissionDenied));}
        let at=usize::try_from(offset).map_err(|_|ValidationIssue::InvalidSpan)?;
        if at>=self.stop||at>=self.bytes.len(){return Ok(0);}
        let n=out.len().min(self.chunk).min(self.stop-at).min(self.bytes.len()-at);
        out[..n].copy_from_slice(&self.bytes[at..at+n]);Ok(n)
    }
}
fn source(bytes:&[u8],chunk:usize)->Source<'_>{Source{bytes,length:bytes.len()as u64,chunk,stop:bytes.len(),error:false,calls:Cell::new(0)}}
fn header(pages:u64)->[u8;49]{let mut bytes=[0;49];bytes[..4].copy_from_slice(b"LBUG");bytes[4..12].copy_from_slice(&43u64.to_le_bytes());for(at,n)in[(12,1u32),(16,1),(20,2),(24,1),(45,pages as u32)]{bytes[at..at+4].copy_from_slice(&n.to_le_bytes());}bytes[44]=2;bytes}
fn header_checks()->usize{
    let memory=CleanupMemory::new(4096).unwrap();let floor=memory.used();let mut checks=0;
    let valid=header(3);
    for chunk in 1..=49 {let input=Source{length:12288,..source(&valid,chunk)};let f=scan_native_header43(&input,&memory).unwrap();assert_eq!(f.catalog.start,1);assert_eq!(f.metadata.start,2);assert_eq!(f.available_pages,3);assert_eq!(memory.used(),floor);checks+=1;}
    for stop in 0..49 {let input=Source{length:12288,stop,..source(&valid,3)};assert_eq!(scan_native_header43(&input,&memory),Err(NativeUnknown::Truncated));assert_eq!(memory.used(),floor);checks+=1;}
    for pages in [1,3,8,u32::MAX as u64,(u64::MAX/4096)] {
        for start in [0,1,2,3,u32::MAX-1,u32::MAX] {for count in [0,1,2,3,u32::MAX] {for at in [12,20] {
            let mut b=header(pages);b[12..16].copy_from_slice(&u32::MAX.to_le_bytes());b[16..20].fill(0);b[20..24].copy_from_slice(&u32::MAX.to_le_bytes());b[24..28].fill(0);b[45..49].fill(0);b[at..at+4].copy_from_slice(&start.to_le_bytes());b[at+4..at+8].copy_from_slice(&count.to_le_bytes());
            let input=Source{length:pages*4096,..source(&b,2)};let expected=if start==u32::MAX{count==0}else{count>0&&u64::from(start)<pages&&u64::from(count)<=pages-u64::from(start)};
            assert_eq!(scan_native_header43(&input,&memory).is_ok(),expected,"pages={pages},start={start},count={count},at={at}");assert_eq!(memory.used(),floor);checks+=1;
        }}}
    }
    for at in [0,4,44] {let mut b=valid;b[at]^=1;let input=Source{length:12288,..source(&b,7)};assert_eq!(scan_native_header43(&input,&memory),Err(NativeUnknown::UnsupportedLayout));checks+=1;}
    let input=Source{length:u64::MAX,..source(&valid,7)};assert_eq!(scan_native_header43(&input,&memory),Err(NativeUnknown::UnsupportedLayout));checks+=1;
    let small=CleanupMemory::new(64).unwrap();let used=small.used();let input=Source{length:12288,..source(&valid,7)};assert!(matches!(scan_native_header43(&input,&small),Err(NativeUnknown::Source(ValidationIssue::Resource(_)))));assert_eq!(input.calls.get(),0);assert_eq!(small.used(),used);checks+=1;
    checks
}
fn key_checks()->usize{
    let memory=CleanupMemory::new(8192).unwrap();let floor=memory.used();let mut checks=0;
    let mut texts=vec![String::new(),"\0\u{7f}é😀\"\\\n".into(),"é".into(),"e\u{301}".into(),"\u{10ffff}".into()];
    for n in [1,254,255,256,257,4095,4096]{texts.push(format!("{}é😀\0","x".repeat(n)));}
    for text in &texts {let json=serde_json::to_vec(text).unwrap();for chunk in [1,2,3,7,256] {
        let native=source(text.as_bytes(),chunk);let quoted=source(&json,chunk);let a=Span{start:0,end:text.len()as u64};let b=Span{start:0,end:json.len()as u64};
        assert_eq!(compare_native_json(&native,a,&quoted,b,&memory),Ok(Ordering::Equal));
        for domain in [0,1,7,u64::MAX]{let hash=key_stream_hash(&native,a,KeyEncoding::NativeUtf8,domain,&memory).unwrap();assert_eq!(hash,key_stream_hash(&quoted,b,KeyEncoding::JsonDecoded,domain,&memory).unwrap());let mut expected=Sha256::new();expected.update(domain.to_le_bytes());expected.update(text.as_bytes());assert_eq!(hash,<[u8;32]>::from(expected.finalize()));checks+=1;}
        assert_ne!(key_stream_hash(&native,a,KeyEncoding::NativeUtf8,7,&memory).unwrap(),key_stream_hash(&native,a,KeyEncoding::NativeUtf8,8,&memory).unwrap());assert_eq!(memory.used(),floor);checks+=2;
    }}
    for left in ["","a","z","é","😀","\0"] {for right in ["","a","zz","é","😀","\0"]{let quoted=serde_json::to_vec(right).unwrap();assert_eq!(compare_native_json(left.as_bytes(),Span{start:0,end:left.len()as u64},quoted.as_slice(),Span{start:0,end:quoted.len()as u64},&memory).unwrap(),left.as_bytes().cmp(right.as_bytes()));checks+=1;}}
    for native in [b"a\xff".as_slice(),b"a\xc0\x80",b"a\xed\xa0\x80",b"a\xf4\x90\x80\x80",b"a\xe2\x82",b"\x80",b"\xc2"] {let span=Span{start:0,end:native.len()as u64};for json in [br#""b""#.as_slice(),br#""""#]{assert!(compare_native_json(native,span,json,Span{start:0,end:json.len()as u64},&memory).is_err());checks+=1;}assert!(key_stream_hash(native,span,KeyEncoding::NativeUtf8,7,&memory).is_err());assert_eq!(memory.used(),floor);checks+=1;}
    for json in [b"\"b\xff\"".as_slice(),b"\"b",b"\"b\"tail",br#""b\q""#,br#""b\uD800""#] {assert!(compare_native_json(b"a".as_slice(),Span{start:0,end:1},json,Span{start:0,end:json.len()as u64},&memory).is_err());assert!(key_stream_hash(json,Span{start:0,end:json.len()as u64},KeyEncoding::JsonDecoded,7,&memory).is_err());assert_eq!(memory.used(),floor);checks+=2;}
    let native_bytes=format!("a{}","x".repeat(600));let input=Source{error:true,..source(native_bytes.as_bytes(),256)};let json=br#""b""#;assert!(matches!(compare_native_json(&input,Span{start:0,end:native_bytes.len()as u64},json.as_slice(),Span{start:0,end:3},&memory),Err(ValidationIssue::Io(_))));assert!(matches!(key_stream_hash(&input,Span{start:0,end:native_bytes.len()as u64},KeyEncoding::NativeUtf8,0,&memory),Err(ValidationIssue::Io(_))));checks+=2;
    let quoted=serde_json::to_vec(&native_bytes).unwrap();let input=Source{error:true,..source(&quoted,256)};assert!(matches!(compare_native_json(b"b".as_slice(),Span{start:0,end:1},&input,Span{start:0,end:quoted.len()as u64},&memory),Err(ValidationIssue::Io(_))));checks+=1;
    let small=CleanupMemory::new(64).unwrap();assert!(matches!(key_stream_hash(b"a".as_slice(),Span{start:0,end:1},KeyEncoding::NativeUtf8,0,&small),Err(ValidationIssue::Resource(_))));assert_eq!(small.used(),32);checks+=1;
    let a=b"XXkey\0\xff";let b=br#"XXX"key\u0000"YY"#;assert_eq!(compare_native_json(a.as_slice(),Span{start:2,end:6},b.as_slice(),Span{start:3,end:b.len()as u64-2},&memory),Ok(Ordering::Equal));checks+=1;
    assert!(compare_native_json(a.as_slice(),Span{start:2,end:a.len()as u64+1},b.as_slice(),Span{start:3,end:b.len()as u64-2},&memory).is_err());assert_eq!(memory.used(),floor);checks+=1;
    checks
}
fn main(){let header=header_checks();let keys=key_checks();println!("{{\"header_boundary_cases\":{header},\"logical_key_cases\":{keys}}}");}
