#![allow(dead_code)]
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_budget.rs"] mod maintenance_budget;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_json.rs"] mod maintenance_json;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_validation.rs"] mod maintenance_validation;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_native_projection.rs"] mod maintenance_native_projection;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/syntax_materializer/rows.rs"] mod syntax_materializer;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/hash.rs"] mod hash;
mod protocol {use serde::{Deserialize,Serialize};use std::collections::BTreeMap;include!("probe/manifest_entry.rs");}
mod partition_builder {use super::protocol::ManifestEntry;use super::syntax_materializer::{GraphNodeRow,GraphEdgeRow};use super::hash;use std::collections::BTreeMap;include!("probe/graph_partition.rs");}
