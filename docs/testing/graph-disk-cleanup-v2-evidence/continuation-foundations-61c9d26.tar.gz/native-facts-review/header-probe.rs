#![allow(dead_code)]
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_budget.rs"] mod maintenance_budget;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_json.rs"] mod maintenance_json;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_validation.rs"] mod maintenance_validation;
#[path="/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo/src/storage/maintenance_native_projection.rs"] mod maintenance_native_projection;
use maintenance_budget::CleanupMemory;use maintenance_native_projection::*;
fn header()->Vec<u8>{let mut bytes=vec![0;3*4096];bytes[..4].copy_from_slice(b"LBUG");bytes[4..12].copy_from_slice(&43u64.to_le_bytes());for(at,n)in[(12,1u32),(16,1),(20,2),(24,1),(45,3)]{bytes[at..at+4].copy_from_slice(&n.to_le_bytes());}bytes[44]=2;bytes}
fn main(){let memory=CleanupMemory::new(4096).unwrap();for(name,at,value)in[("catalog/metadata overlap",20,1u32),("catalog covers header page",12,0),("checkpoint pages below ranges",45,1)]{let mut bytes=header();bytes[at..at+4].copy_from_slice(&value.to_le_bytes());println!("{name}: {:?}",scan_native_header43(bytes.as_slice(),&memory));}}
