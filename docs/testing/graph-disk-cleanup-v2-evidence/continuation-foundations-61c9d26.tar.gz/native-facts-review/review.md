# S3 native header and logical key foundation — independent review

**No confirmed P0–P3 defects were found in the reviewed delta.** The pure header and key foundation may proceed to central integration within its existing narrow clearance. It establishes no full native visitor, producer profile, association/origin, LoaderUsable, Ready, publication or retirement authority.

Reviewer: **GPT-6.1 Sol / Max**, continuation of the independent S3 reviewer, separate from the author. Applied the adversarial-review-engineer skill. All source inspection and probes were read-only or isolated. No shared Cargo, author/shared source, Git, model, wiki or tracking writes were performed.

## Exact scope and identity

- Baseline: `73eaf71c3c487ef3b52d19d48808d10bd400b939`.
- Author freeze: `/private/tmp/cleanup-s3-native-header-189/repo`.
- Independent copy: `/private/tmp/cleanup-s3-native-header-review-yb6v6y2e/repo`.
- Source manifest SHA-256: `68691435956b13c3c26219b1f1afbb0e88159636fbcfc0debc649ff6cd4f12ad`.
- Overlay: new `src/storage/maintenance_native_projection.rs` SHA-256 `e68a73ff5de9d074a9db34038532b4aad83a1ac1554f49c5c9d616934c486759`; narrow validation/key changes SHA-256 `330a8a21ee37bcc78f5ef0245c4b18eff3b06708ee8fd45eb37957542b492cdf`; module registration in `mod.rs`.
- Archive comparison confirmed exactly those three overlays and no missing baseline files. All **469** inventoried inputs matched the supplied hashes before and after verification. The generated exact delta is `native-foundation.diff`.

Recalled memory for native format/key/streaming requirements; consulted configured wiki bundle/search/get and approved revision-0.2 contract. Read/oriented the explicit Scryer project `/private/tmp/codebasegraph-disk-cleanup-7t9af0a6/repo`, `chg-6vx5tj` / `node-eje4rb`, including the native narrow starting brief. Required graph search and dependency context preceded source inspection. The index has no new native-module entry; explicit frozen/Scryer mappings supplied the new-file anchors. No unrelated project state was used. The fresh Max starting clearance `s3_native_header_key_foundation_review.md`, SHA-256 `96a464e17aec15c882c549591efc0bc371e9f045581f542a303a55d14c75d13c`, was read and followed.

## Confirmed findings

None. The prior comparator P2 remains fixed: comparison records its first ordering difference and validates both complete streams before returning success. New NativeUtf8 inputs use that same complete-stream path.

## Header checks against pinned primary SDK source

Inspected the mapped local lbug 0.19.0 primary C++ source, including `common/types/types.h`, `storage/page_range.h`, `storage/storage_version_info.h`, `storage/database_header.h`, `storage/database_header.cpp`, `storage/checkpointer.cpp`, serializer and CMake definitions. Source identities are retained in `sdk-primary-source.json`. The package checksum file is absent at this mapped source path, so no registry-package checksum verification is claimed. Remote docs.rs source fetches were unavailable; conclusions use the explicitly pinned local source, not a guessed online release.

The selected no-debug little-endian profile has the actual **49-byte** prefix:

| Field | Offset | Width |
| --- | ---: | ---: |
| LBUG magic | 0 | 4 |
| storage version | 4 | u64 |
| catalog start/count | 12 / 16 | u32 / u32 |
| metadata start/count | 20 / 24 | u32 / u32 |
| UUID bytes | 28 | 16 |
| header format | 44 | u8 |
| format-2 data-file page count | 45 | u32 |

`page_idx_t` is uint32_t; DatabaseHeader uses it for both ranges and dataFileNumPages. Serializer writes the actual scalar width. The SDK's stale nine-byte-tail comment does not change those declarations or emitted five-byte format-2 tail. The Rust parser uses the correct offsets and widths and rejects unsupported magic/version/tail cases.

The parser reserves fixed header/result/scratch allowance before reading, reads only the fixed prefix, handles short reads, rejects zero/over-reported reads, and returns explicit Unknown variants rather than constructing a larger witness. File size is checked for the selected 4096-byte page alignment. Individual ranges mirror Checkpointer's physical-file sentinel/bounds predicate: INVALID_PAGE requires count zero; other ranges require nonzero count, start below physical pages and count within pages minus start. Offsets/end checks use widened checked u64 arithmetic. Header page count above physical availability is rejected. Fixed slices/unwraps have statically verified lengths and offsets.

**Profile boundary clarified during review:** the starting gate covers decoded fields and each range's physical bounds, not overall database validity. Consequently these crafted cases currently return truthful raw facts and are not confirmed defects:

- catalog and metadata both describe page 1;
- catalog includes reserved page 0;
- nonzero data_file_pages is smaller than the catalog/metadata range ends while both ranges fit the physical file.

The coordinator confirmed that the assignment's “disjoint bounds” wording exceeded this accepted narrow guarantee, and the author confirmed these non-guarantees without changing the frozen source. The module/type documentation explicitly disclaims producer profile, origin and usability authority; no overall-validity boolean or proof is exposed. Mutual/reserved-page disjointness and checkpoint-logical containment remain downstream profile/writer-audit conditions to settle before full visitor or origin composition. Do not infer them from these facts or add speculative rejection rules.

## Logical key stream checks

NativeUtf8 represents an already decoded **logical** UTF-8 view. It neither decodes native physical dictionaries/compression nor makes native offsets interchangeable with JSON string spans. Native and JSON sources/spans remain independent and explicit.

Both readers stream through fixed buffers/carry. Native UTF-8 validates multibyte scalar boundaries and rejects invalid leads/continuations, overlong encodings, surrogate encodings, out-of-range scalars and truncated tails. Embedded NUL and valid maximum scalars are retained. JSON uses the existing strict escape/surrogate/string decoder. No normalization, truncation or digest-only equality is introduced.

The generic complete comparator preserves first lexicographic ordering but continues through both EOFs, including malformed tails and late source errors. Hashing consumes the same full decoded byte stream and prefixes the same u64 little-endian domain for both encodings. Equal logical native/JSON keys therefore share the same hash input; exact comparison remains required. Changed domain values change the input prefix. Memory for both readers/hash state is charged to the passed CleanupMemory before construction, and reservations release on success/error.

RawRowsMatch table/slot representation and join inputs are unchanged. This review does not claim that native source locators are integrated into a complete native join or full visitor. Retained caller inputs/results, source identity/stability and whole-pipeline accounting remain the existing consumer obligations.

## Executed evidence

Host: Darwin arm64, rustc **1.96.0**. Shared Cargo was reserved for Windows work and was not used. Exact runtime dependencies were copied from the previously audited root fingerprint DAG; the selected author-189 root serde/serde_json/sha2 fingerprints match those artifacts.

Independent direct-rustc execution:

- **34 isolated module tests passed**, zero failures/skips. This includes all three new native-header cases, the new native/JSON key case, the previous strict comparator regressions and affected baseline key/reader/join regressions. Build/result logs and exact command are retained. Supporting types/validator are verbatim frozen excerpts and the row/hash source modules are the actual frozen files; this is an isolated module build, not a full repository link.
- **403 header boundary cases passed:** chunk sizes 1–49, every early prefix stop, sentinel/count combinations in both ranges, physical-page boundaries including large virtual lengths, unsupported marker/layout inputs, widened arithmetic, and resource exhaustion before source reads.
- **433 logical key cases passed:** independent chunk sizes and spans, UTF-8 crossings around 256/4096 bytes, empty/NUL/quote/control/max-scalar strings, Unicode byte ordering without normalization, same-domain cross-encoding hash identity against an independent SHA256 input oracle, distinct domains, invalid UTF-8 and JSON suffixes, late I/O errors in either side, low ceilings, and independent source-span bounds. Reservations returned to the initial floor.
- All three changed Rust files passed rustfmt check. Direct builds emitted no warnings. All 469 frozen inputs remained unchanged.

Author evidence was independently checked for artifact/source identity, rather than relabeled as an independent root execution:

- Actual author root compile codegen 189: visible 18.43 s, no libtest warnings.
- **124 passed, 507 unselected, retries 0**, with 631 total tests. The count includes newly accepted ownership/control/scheduler baseline cases; it is not 124 new header/key tests.
- Author JUnit SHA-256 `f10e09b8bae87a011475174b6651e249d02aaa15d9abd0606439c20b4b3d1325`.
- Preserved binary SHA-256 `f49b3a62b66b362650961264cf6b6e4c068fc08b76c919e0f5b07b8519f62645`, dependency-file SHA-256 `312da069ae86ea1339fc1f39f21020cac5f9116f46d5e543314a14f9eb2c65dd`; source/binary before/after identities match.
- Evidence-summary SHA-256 `91b6810ccda20f53a8e26d671dc19ad90aaa21e8eb8a0e4b103e4791bc36d9b8`.

The header/key tests do not execute the native SDK. Author attribution to four archives matching the separate native-oracle capture is retained separately; it is not evidence that this Rust parser implements a complete historical profile. No live graph file was read or copied.

## Limits and handoff

No full catalog/tag/chunk/version/dictionary visitor, native physical-string decoder, legacy association or complete native join is cleared. No source/stamp stability, origin, LoaderUsable, Ready, publication or retirement capability is added. The selected raw header facts do not identify the actual writer/build profile; native source/build overrides and page/debug configuration remain relevant. Additional profile invariants identified above require the planned actual-writer audit before composition.

No independent full root/workspace build, native Windows/Linux execution, full native-profile differential, RSS/allocator-slack measurement, universal throughput, actual collector, deployment or live cleanup was performed. Central integration retains its normal full-check and warning gates. The approved later distinction also remains: eligible origin-and-integrity-proven absent data may be collectible; restoration additionally requires LoaderUsable.

Reusable-knowledge assessment: the exact pinned header widths and profile distinction are already captured in the authoritative Scryer brief and starting review. The current results are revision-specific evidence; no additional filler memory was warranted. Read-only review created no external records.

Evidence: `/private/tmp/cleanup-s3-native-header-review-yb6v6y2e`; machine-readable result `verification.json`; artifact identities `review-artifact-sha256.json`.
